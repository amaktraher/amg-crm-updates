/* Профиль: личные данные, пароль, оформление. */
import {
  ROLE_LABELS, api, avatar, applyTheme, esc, fmtDateTime, icon, state, toast,
} from '../lib.js'

export default {
  subtitle: () => 'Личные данные и безопасность',
  async render(ctx) {
    const user = state.user
    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Профиль</h2><div class="hint">Данные вашей учётной записи</div></div>
      </div>

      <div class="grid-2">
        <div style="display:flex;flex-direction:column;gap:16px">
          <div class="card">
            <div class="card-head"><h3>Личные данные</h3></div>
            <div class="card-pad">
              <form class="form-grid" id="profile-form">
                <div class="field span-2">
                  <label for="p-name">Имя</label>
                  <input class="input" id="p-name" name="name" value="${esc(user.name)}" required />
                </div>
                <div class="field span-2">
                  <label for="p-phone">Телефон</label>
                  <input class="input" id="p-phone" name="phone" value="${esc(user.phone ?? '')}" placeholder="+7 900 000-00-00" />
                </div>
                <div class="field span-2">
                  <label>E-mail</label>
                  <input class="input" value="${esc(user.email)}" disabled />
                  <span class="hint">E-mail меняет администратор</span>
                </div>
                <div class="field span-2" id="profile-error" style="display:none"><span class="error"></span></div>
                <div class="field span-2" style="flex-direction:row;justify-content:flex-end">
                  <button class="btn btn-primary" type="submit">Сохранить</button>
                </div>
              </form>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h3>Смена пароля</h3></div>
            <div class="card-pad">
              <form class="form-grid" id="password-form">
                <div class="field span-2">
                  <label for="p-current">Текущий пароль</label>
                  <input class="input" id="p-current" name="currentPassword" type="password" autocomplete="current-password" required />
                </div>
                <div class="field">
                  <label for="p-new">Новый пароль</label>
                  <input class="input" id="p-new" name="newPassword" type="password" autocomplete="new-password" required />
                </div>
                <div class="field">
                  <label for="p-repeat">Повтор</label>
                  <input class="input" id="p-repeat" name="repeat" type="password" autocomplete="new-password" required />
                </div>
                <div class="field span-2" id="password-error" style="display:none"><span class="error"></span></div>
                <div class="field span-2" style="flex-direction:row;justify-content:flex-end">
                  <button class="btn" type="submit">Обновить пароль</button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:16px">
          <div class="card card-pad" style="display:flex;gap:14px;align-items:center">
            ${avatar(user.name, { size: 'xl' })}
            <div style="min-width:0">
              <div style="font-size:17px;font-weight:650">${esc(user.name)}</div>
              <div class="small muted">${esc(user.email)}</div>
              <div style="margin-top:6px"><span class="pill ${user.role === 'admin' ? 'vip' : user.role === 'manager' ? 'info' : 'archived'}">${esc(ROLE_LABELS[user.role])}</span></div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h3>Учётная запись</h3></div>
            <div class="card-pad">
              <div class="info-list">
                <div class="info-row">${icon('calendar', 16)}<div><div class="k">В системе с</div>
                  <div class="v">${fmtDateTime(user.createdAt)}</div></div></div>
                <div class="info-row">${icon('clock', 16)}<div><div class="k">Последний вход</div>
                  <div class="v">${user.lastLoginAt ? fmtDateTime(user.lastLoginAt) : '—'}</div></div></div>
                <div class="info-row">${icon('shield', 16)}<div><div class="k">Права</div>
                  <div class="v">${user.role === 'admin' ? 'Полный доступ, управление командой и журналом'
    : user.role === 'manager' ? 'Просмотр и редактирование клиентов и задач'
      : 'Только просмотр'}</div></div></div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h3>Оформление</h3></div>
            <div class="card-pad">
              <div class="segmented" id="theme">
                <button data-theme="light" class="${state.theme === 'light' ? 'active' : ''}">${icon('sun', 14)} Светлая</button>
                <button data-theme="dark" class="${state.theme === 'dark' ? 'active' : ''}">${icon('moon', 14)} Тёмная</button>
              </div>
              <p class="hint" style="margin-top:10px">Тема сохраняется в этом браузере.</p>
            </div>
          </div>
        </div>
      </div>`

    const profileForm = ctx.root.querySelector('#profile-form')
    profileForm.addEventListener('submit', async (event) => {
      event.preventDefault()
      const errorBox = ctx.root.querySelector('#profile-error')
      errorBox.style.display = 'none'
      try {
        const result = await api('/api/auth/me', {
          method: 'PATCH',
          body: { name: profileForm.name.value, phone: profileForm.phone.value },
        })
        state.user = result.user
        toast('Данные сохранены')
        ctx.refresh()
      } catch (error) {
        errorBox.style.display = ''
        errorBox.querySelector('.error').textContent = error.message
      }
    })

    const passwordForm = ctx.root.querySelector('#password-form')
    passwordForm.addEventListener('submit', async (event) => {
      event.preventDefault()
      const errorBox = ctx.root.querySelector('#password-error')
      errorBox.style.display = 'none'
      if (passwordForm.newPassword.value !== passwordForm.repeat.value) {
        errorBox.style.display = ''
        errorBox.querySelector('.error').textContent = 'Пароли не совпадают'
        return
      }
      try {
        await api('/api/auth/me', {
          method: 'PATCH',
          body: {
            currentPassword: passwordForm.currentPassword.value,
            newPassword: passwordForm.newPassword.value,
          },
        })
        passwordForm.reset()
        toast('Пароль обновлён')
      } catch (error) {
        errorBox.style.display = ''
        errorBox.querySelector('.error').textContent = error.message
      }
    })

    ctx.root.querySelectorAll('#theme button').forEach((button) => {
      button.addEventListener('click', () => {
        applyTheme(button.dataset.theme)
        ctx.root.querySelectorAll('#theme button').forEach((item) => item.classList.toggle('active', item === button))
        document.getElementById('theme-toggle').innerHTML = icon(state.theme === 'dark' ? 'sun' : 'moon', 17)
      })
    })

    if (state.permissions?.manageUsers) {
      mountUpdateCard(ctx)
    }
  },
}

/** Карточка «Обновления»: источник, проверка и установка (только администратор). */
function mountUpdateCard(ctx) {
  const column = ctx.root.querySelector('.grid-2 > div')
  if (!column) return
  const card = document.createElement('div')
  card.className = 'card'
  card.innerHTML = `
    <div class="card-head">
      <h3>Обновления</h3>
      <span class="small muted" style="margin-left:auto">версия <b id="upd-version">…</b></span>
    </div>
    <div class="card-pad">
      <div class="field">
        <label for="upd-url">Ссылка на manifest.json или путь к файлу</label>
        <input class="input" id="upd-url" placeholder="https://example.ru/amg/manifest.json" />
        <span class="hint">Можно указать ссылку http(s) или сетевой путь, например \\\\server\\share\\manifest.json</span>
      </div>
      <div class="row wrap" style="gap:8px;margin-top:12px">
        <button class="btn" id="upd-save" type="button">Сохранить</button>
        <button class="btn" id="upd-check" type="button">Проверить обновление</button>
        <span class="spacer"></span>
        <button class="btn btn-primary" id="upd-apply" type="button" style="display:none">Установить</button>
      </div>
      <div class="small" id="upd-status" style="margin-top:10px;color:var(--muted)"></div>
    </div>`
  column.appendChild(card)

  const urlInput = card.querySelector('#upd-url')
  const versionLabel = card.querySelector('#upd-version')
  const statusBox = card.querySelector('#upd-status')
  const applyButton = card.querySelector('#upd-apply')

  api('/api/system/settings').then((data) => {
    versionLabel.textContent = data.version
    urlInput.value = data.manifestUrl ?? ''
  }).catch((error) => {
    statusBox.textContent = error.message
  })

  card.querySelector('#upd-save').addEventListener('click', async () => {
    try {
      await api('/api/system/settings', { method: 'PUT', body: { manifestUrl: urlInput.value.trim() } })
      toast('Источник обновлений сохранён')
    } catch (error) {
      toast(error.message, 'error')
    }
  })

  card.querySelector('#upd-check').addEventListener('click', async () => {
    statusBox.textContent = 'Проверяем…'
    applyButton.style.display = 'none'
    try {
      const data = await api('/api/system/update')
      if (!data.configured) {
        statusBox.textContent = 'Источник обновлений не задан.'
        return
      }
      if (data.error) {
        statusBox.textContent = 'Ошибка: ' + data.error
        return
      }
      if (data.available) {
        statusBox.textContent = `Доступна версия ${data.latest} (установлена ${data.current}).`
          + (data.notes ? ' ' + data.notes : '')
        applyButton.style.display = ''
      } else {
        statusBox.textContent = `Установлена актуальная версия ${data.current}.`
      }
    } catch (error) {
      statusBox.textContent = error.message
    }
  })

  applyButton.addEventListener('click', async () => {
    applyButton.disabled = true
    statusBox.textContent = 'Скачиваем обновление…'
    try {
      await api('/api/system/update/apply', { method: 'POST' })
      statusBox.textContent = 'Обновление устанавливается — программа перезапустится.'
    } catch (error) {
      statusBox.textContent = error.message
      applyButton.disabled = false
    }
  })
}
