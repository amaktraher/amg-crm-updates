/* Авито — все чаты: обращения из чатов Авито. */
import {
  api, esc, fmtDateTime, icon, openModal, relTime, state, toast, formModal, confirmDialog,
} from '../lib.js'

const STATUSES = [
  ['in_work', 'В работе'],
  ['done', 'Выполнен'],
  ['postponed', 'Отложил покупку'],
  ['no_answer', 'Без ответа 14 дней'],
  ['refused', 'Отказ'],
  ['not_target', 'Не целевой'],
  ['opt', 'Передали в ОПТ'],
]

const STORES = [
  ['pargolovo', 'Парголово'],
  ['dunaysky-27k1', 'Дунайский 27к1'],
  ['pushkino', 'Пушкино'],
  ['krasnodar', 'Краснодар'],
  ['kaliningrad-1', 'Калининград 1'],
  ['kaliningrad-2', 'Калининград 2'],
]

const STATUS_LABELS = Object.fromEntries(STATUSES)
const STORE_LABELS = Object.fromEntries(STORES)

const money = (value) => `${Number(value ?? 0).toLocaleString('ru-RU')} ₽`

export default {
  subtitle: () => 'Все обращения из чатов Авито',
  async render(ctx) {
    const canManage = Boolean(state.permissions?.manageUsers)
    const query = ctx.query
    const status = query.get('status') ?? ''
    const store = query.get('store') ?? ''
    const search = query.get('q') ?? ''

    ctx.root.innerHTML = `
      <div class="page-head">
        <div>
          <h2>Авито — все чаты</h2>
          <p class="sub" id="avito-sub">Загрузка…</p>
        </div>
        <div class="row" style="gap:8px">
          ${canManage ? `<button class="btn" id="avito-connect">${icon('link', 16)} Подключение Авито</button>` : ''}
          ${canManage ? `<button class="btn btn-primary" id="avito-new">${icon('plus', 16)} Добавить чат</button>` : ''}
        </div>
      </div>

      <div class="row wrap" id="avito-stats" style="gap:8px;margin-bottom:12px"></div>

      <div class="toolbar">
        <label class="search-input">${icon('search', 16)}
          <input id="avito-q" placeholder="Имя, объявление, заказ 1С…" value="${esc(search)}" />
        </label>
        <select class="select" id="avito-status">
          <option value="">Все статусы</option>
          ${STATUSES.map(([value, label]) => `<option value="${value}" ${status === value ? 'selected' : ''}>${label}</option>`).join('')}
        </select>
        <select class="select" id="avito-store">
          <option value="">Все магазины</option>
          ${STORES.map(([value, label]) => `<option value="${value}" ${store === value ? 'selected' : ''}>${label}</option>`).join('')}
        </select>
      </div>

      <div class="card" style="overflow:hidden">
        <div id="avito-list"><div class="card-pad"><div class="skeleton sk-line" style="width:40%"></div></div></div>
      </div>`

    let data = { items: [], stats: {} }

    const reload = async () => {
      const params = new URLSearchParams()
      if (status) params.set('status', status)
      if (store) params.set('store', store)
      if (search) params.set('q', search)
      data = await api(`/api/avito-chats?${params.toString()}`)
      renderStats()
      renderList()
    }

    const renderStats = () => {
      const s = data.stats ?? {}
      ctx.root.querySelector('#avito-stats').innerHTML = `
        <span class="pill plain">всего: <b class="mono">${s.total ?? 0}</b></span>
        <span class="pill warning plain">новые: <b class="mono">${s.newChats ?? 0}</b></span>
        <span class="pill info plain">в работе: <b class="mono">${s.inWork ?? 0}</b></span>
        <span class="pill active plain">выполнено: <b class="mono">${s.done ?? 0}</b></span>
        <span class="pill danger plain">отказ: <b class="mono">${s.refused ?? 0}</b></span>
        <span class="pill plain">сумма: <b class="mono">${money(s.revenue)}</b></span>`
      ctx.root.querySelector('#avito-sub').textContent = `Чатов: ${s.total ?? 0} · новые без магазина: ${s.newChats ?? 0}`
    }

    const renderList = () => {
      if (data.items.length === 0) {
        ctx.root.querySelector('#avito-list').innerHTML = `<div class="empty" style="padding:34px 16px">
          <div class="icon">${icon('chat', 22)}</div>
          <h4>Чатов пока нет</h4>
          <p>Новые чаты Авито появятся здесь автоматически, как только подключим синхронизацию.</p>
        </div>`
        return
      }
      ctx.root.querySelector('#avito-list').innerHTML = `
        <table class="table">
          <thead><tr>
            <th>Дата начала</th><th>Чат</th><th>Собеседник</th><th>Магазин</th>
            <th>Объявление</th><th>Цена</th><th>Заказ 1С</th><th>Сумма</th>
            <th>Статус</th><th>Последняя активность</th><th></th>
          </tr></thead>
          <tbody>${data.items.map((item) => `
            <tr class="row-avito-${item.status}" data-id="${item.id}">
              <td class="small nowrap">${fmtDateTime(item.started_at)}</td>
              <td>${item.chat_url
    ? `<a class="link" href="${esc(item.chat_url)}" target="_blank" rel="noopener">${icon('message', 14)} Чат</a>`
    : '—'}</td>
              <td>${esc(item.buyer_name ?? '—')}</td>
              <td>
                <select class="select select-sm" data-store="${item.id}">
                  <option value="">— выберите —</option>
                  ${STORES.map(([value, label]) => `<option value="${value}" ${item.store === value ? 'selected' : ''}>${label}</option>`).join('')}
                </select>
              </td>
              <td class="small">${esc(item.listing_title ?? '—')}</td>
              <td class="small nowrap">${money(item.listing_price)}</td>
              <td class="small">${esc(item.order_1c ?? '—')}</td>
              <td class="small nowrap">${money(item.order_price)}</td>
              <td>
                <select class="select select-sm" data-status="${item.id}">
                  ${STATUSES.map(([value, label]) => `<option value="${value}" ${item.status === value ? 'selected' : ''}>${label}</option>`).join('')}
                </select>
              </td>
              <td class="small nowrap">${relTime(item.last_activity_at)}</td>
              <td class="nowrap">
                <button class="icon-btn" data-edit="${item.id}" title="Открыть">${icon('edit', 14)}</button>
                <button class="icon-btn" data-del="${item.id}" title="Удалить">${icon('trash', 14)}</button>
              </td>
            </tr>`).join('')}</tbody>
        </table>`

      ctx.root.querySelectorAll('[data-status]').forEach((select) => {
        select.addEventListener('change', async () => {
          try {
            await api(`/api/avito-chats/${select.dataset.status}`, { method: 'PATCH', body: { status: select.value } })
            toast('Статус обновлён')
            ctx.refresh()
          } catch (error) {
            toast(error.message, 'error')
          }
        })
      })
      ctx.root.querySelectorAll('[data-store]').forEach((select) => {
        select.addEventListener('change', async () => {
          try {
            await api(`/api/avito-chats/${select.dataset.store}`, { method: 'PATCH', body: { store: select.value } })
            toast(select.value ? 'Магазин назначен' : 'Магазин снят')
            ctx.refresh()
          } catch (error) {
            toast(error.message, 'error')
          }
        })
      })
      ctx.root.querySelectorAll('[data-edit]').forEach((button) => {
        button.addEventListener('click', () => {
          const item = data.items.find((row) => String(row.id) === button.dataset.edit)
          if (item) openForm(item, ctx.refresh)
        })
      })
      ctx.root.querySelectorAll('[data-del]').forEach((button) => {
        button.addEventListener('click', async () => {
          const item = data.items.find((row) => String(row.id) === button.dataset.del)
          if (!item) return
          if (!await confirmDialog({ title: 'Удалить чат?', message: `Чат с ${item.buyer_name ?? 'собеседником'} будет удалён.` })) return
          try {
            await api(`/api/avito-chats/${item.id}`, { method: 'DELETE' })
            toast('Чат удалён')
            ctx.refresh()
          } catch (error) {
            toast(error.message, 'error')
          }
        })
      })
    }

    const openForm = (item, done) => {
      const isEdit = Boolean(item)
      formModal({
        title: isEdit ? 'Чат Авито' : 'Новый чат Авито',
        sub: isEdit ? (item.buyer_name ?? '') : 'Заполните данные чата',
        wide: true,
        submitLabel: isEdit ? 'Сохранить' : 'Добавить',
        fields: [
          { name: 'chatUrl', label: 'Ссылка на чат', span: 2, placeholder: 'https://www.avito.ru/…', value: item?.chat_url ?? '' },
          { name: 'buyerName', label: 'Имя собеседника', value: item?.buyer_name ?? '' },
          { name: 'startedAt', label: 'Дата начала чата', type: 'datetime-local',
            value: toLocal(item?.started_at) },
          { name: 'store', label: 'Магазин', type: 'select', options: STORES.map(([value, label]) => ({ value, label })), value: item?.store ?? '' },
          { name: 'status', label: 'Статус', type: 'select', options: STATUSES.map(([value, label]) => ({ value, label })), value: item?.status ?? 'in_work' },
          { name: 'listingTitle', label: 'Название объявления', span: 2, value: item?.listing_title ?? '' },
          { name: 'listingPrice', label: 'Цена из объявления', type: 'number', value: item?.listing_price ?? '' },
          { name: 'orderPrice', label: 'Стоимость заказа 1С', type: 'number', value: item?.order_price ?? '' },
          { name: 'order1c', label: 'Номер заказа 1С', value: item?.order_1c ?? '' },
          { name: 'refuseReason', label: 'Причина отказа', value: item?.refuse_reason ?? '' },
          { name: 'comment', label: 'Комментарий', type: 'textarea', rows: 3, span: 2, value: item?.comment ?? '' },
        ],
        submit: async (values) => {
          const payload = {
            chatUrl: values.chatUrl,
            buyerName: values.buyerName,
            startedAt: values.startedAt ? new Date(values.startedAt).toISOString() : undefined,
            store: values.store || null,
            status: values.status,
            listingTitle: values.listingTitle,
            listingPrice: values.listingPrice ? Number(values.listingPrice) : 0,
            orderPrice: values.orderPrice ? Number(values.orderPrice) : 0,
            order1c: values.order1c,
            refuseReason: values.refuseReason,
            comment: values.comment,
          }
          if (isEdit) await api(`/api/avito-chats/${item.id}`, { method: 'PATCH', body: payload })
          else await api('/api/avito-chats', { method: 'POST', body: payload })
          toast(isEdit ? 'Чат сохранён' : 'Чат добавлен')
          done?.()
        },
      })
    }

    ctx.root.querySelector('#avito-new')?.addEventListener('click', () => openForm(null, ctx.refresh))
    ctx.root.querySelector('#avito-connect')?.addEventListener('click', () => openConnect())
    ctx.root.querySelector('#avito-q')?.addEventListener('input', (event) => {
      const value = event.target.value
      clearTimeout(ctx.root._timer)
      ctx.root._timer = setTimeout(() => ctx.navigate(`/avito-chats?q=${encodeURIComponent(value)}`), 350)
    })
    ctx.root.querySelector('#avito-status')?.addEventListener('change', (event) => {
      const params = new URLSearchParams()
      if (event.target.value) params.set('status', event.target.value)
      if (store) params.set('store', store)
      ctx.navigate(`/avito-chats?${params.toString()}`)
    })
    ctx.root.querySelector('#avito-store')?.addEventListener('change', (event) => {
      const params = new URLSearchParams()
      if (status) params.set('status', status)
      if (event.target.value) params.set('store', event.target.value)
      ctx.navigate(`/avito-chats?${params.toString()}`)
    })

    await reload()

    // Новые чаты появляются строкой сразу: обновляем список по событию и раз в 10 секунд
    const onNewChat = () => { reload().catch(() => {}) }
    document.addEventListener('crm:avito-chat', onNewChat)
    const timer = setInterval(() => {
      if (!document.hidden) reload().catch(() => {})
    }, 10000)
    window.__viewCleanup = () => {
      clearInterval(timer)
      document.removeEventListener('crm:avito-chat', onNewChat)
    }
  },
}

function toLocal(value) {
  if (!value) return ''
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  const pad = (n) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
}

async function openConnect() {
  const info = await api('/api/avito-chats/connection').catch(() => ({ configured: false }))
  const { el, close } = openModal({
    title: 'Подключение Авито',
    sub: 'Ключи хранятся только на этом компьютере',
    body: `
      <div style="display:flex;flex-direction:column;gap:10px">
        <div class="small muted">Статус: <b>${info.configured ? 'подключено' : 'не подключено'}</b></div>
        <div class="field"><label for="avito-cid">client_id</label>
          <input class="input" id="avito-cid" placeholder="ключ из личного кабинета Авито" /></div>
        <div class="field"><label for="avito-secret">client_secret</label>
          <input class="input" id="avito-secret" type="password" placeholder="секретный ключ" /></div>
        <div class="small" id="avito-probe" style="color:var(--muted)"></div>
      </div>`,
    footer: `${info.configured ? '<button class="btn btn-danger" data-drop type="button">Удалить ключи</button>' : ''}
      <button class="btn" data-close type="button">Закрыть</button>
      <button class="btn btn-primary" data-save type="button">Проверить и сохранить</button>`,
  })

  const box = el.querySelector('#avito-probe')
  el.querySelector('[data-close]').addEventListener('click', close)
  el.querySelector('[data-drop]')?.addEventListener('click', async () => {
    try {
      await api('/api/avito-chats/connection', { method: 'DELETE' })
      toast('Ключи Авито удалены')
      close()
    } catch (error) {
      toast(error.message, 'error')
    }
  })
  el.querySelector('[data-save]').addEventListener('click', async () => {
    const clientId = el.querySelector('#avito-cid').value.trim()
    const clientSecret = el.querySelector('#avito-secret').value.trim()
    if (!clientId || !clientSecret) {
      toast('Заполните оба поля', 'error')
      return
    }
    box.textContent = 'Проверяем ключи и читаем список чатов…'
    try {
      const data = await api('/api/avito-chats/connection', { method: 'PUT', body: { clientId, clientSecret } })
      const probe = data.probe ?? {}
      const parts = []
      parts.push(probe.accountId ? 'аккаунт: ' + probe.accountId : 'аккаунт: не определён')
      parts.push('чатов в API: ' + (probe.chatsCount ?? 0))
      if (probe.earliestChatAt) parts.push('самый ранний: ' + new Date(probe.earliestChatAt).toLocaleDateString('ru-RU'))
      if (probe.latestChatAt) parts.push('самый свежий: ' + new Date(probe.latestChatAt).toLocaleDateString('ru-RU'))
      if (probe.messageDepth !== null && probe.messageDepth !== undefined) parts.push('сообщений в чате: ' + probe.messageDepth)
      box.textContent = parts.join(' · ')
      if (probe.error) box.textContent += ' · ' + probe.error
      toast('Ключи проверены и сохранены')
    } catch (error) {
      box.textContent = error.message
      toast(error.message, 'error')
    }
  })
}