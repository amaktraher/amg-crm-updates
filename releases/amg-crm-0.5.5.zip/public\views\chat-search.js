/* Поиск чата Авито по ссылке, id, имени, объявлению, заказу 1С (Ctrl+F). */
import { api, esc, fmtDateTime, openModal, state, toast } from '../lib.js'

const STORE_NAMES = {
  pargolovo: 'Парголово',
  'dunaysky-27k1': 'Дунайский 27к1',
  pushkino: 'Пушкино',
  krasnodar: 'Краснодар',
  'kaliningrad-1': 'Калининград 1',
  'kaliningrad-2': 'Калининград 2',
}

const STATUS_NAMES = {
  in_work: 'В работе',
  done: 'Выполнен',
  postponed: 'Отложил покупку',
  no_answer: 'Без ответа 14 дней',
  refused: 'Отказ',
  not_target: 'Не целевой',
  opt: 'Передали в ОПТ',
}

export function openChatSearch() {
  if (!state.permissions?.manageUsers) {
    toast('Поиск чатов доступен администратору', 'error')
    return
  }
  const { el, close } = openModal({
    title: 'Поиск чата Авито',
    sub: 'Ссылка, id, имя, объявление, заказ 1С',
    body: `
      <div class="field">
        <input class="input" id="chat-search-input" placeholder="Вставьте ссылку или начните вводить имя…" />
      </div>
      <div id="chat-search-results" style="margin-top:10px;display:flex;flex-direction:column;gap:6px;max-height:320px;overflow:auto"></div>`,
    footer: '<button class="btn" data-close type="button">Закрыть</button>'
      + '<button class="btn btn-primary" data-go type="button">Найти</button>',
  })

  // Небольшое окно в правом верхнем углу
  const backdrop = el.parentElement
  if (backdrop) {
    backdrop.style.alignItems = 'flex-start'
    backdrop.style.justifyContent = 'flex-end'
    backdrop.style.padding = '18px'
  }
  el.style.width = '330px'
  el.style.maxWidth = '330px'
  el.style.maxHeight = '80vh'

  const input = el.querySelector('#chat-search-input')
  const results = el.querySelector('#chat-search-results')
  input.focus()

  const openById = (id) => {
    close()
    if (location.hash.startsWith('#/avito-chats')) {
      document.dispatchEvent(new CustomEvent('crm:avito-open', { detail: { id } }))
      return
    }
    window.__openAvitoChatId = id
    location.hash = '#/avito-chats'
  }

  const render = (items) => {
    if (items.length === 0) {
      results.innerHTML = '<div class="small" style="color:var(--danger)">Ничего не найдено</div>'
      return
    }
    results.innerHTML = items.slice(0, 20).map((item) => `
      <button class="btn" data-id="${item.id}" type="button"
        style="width:100%;justify-content:flex-start;text-align:left;display:flex;flex-direction:column;align-items:flex-start;gap:2px;height:auto;padding:8px 10px">
        <span style="font-weight:600">${esc(item.buyer_name ?? 'Без имени')} · ${esc(item.listing_title ?? 'без объявления')}</span>
        <span class="small muted">${esc(STORE_NAMES[item.store] ?? 'магазин не выбран')} · ${esc(STATUS_NAMES[item.status] ?? item.status)} · ${esc(fmtDateTime(item.started_at))}</span>
      </button>`).join('')
    results.querySelectorAll('[data-id]').forEach((button) => {
      button.addEventListener('click', () => openById(button.dataset.id))
    })
  }

  const run = async () => {
    const value = input.value.trim()
    if (!value) {
      results.innerHTML = ''
      return
    }
    results.innerHTML = '<div class="small muted">Ищем…</div>'
    try {
      const data = await api(`/api/avito-chats?q=${encodeURIComponent(value)}`)
      const items = data.items ?? []
      const exact = items.find((item) => item.chat_url === value)
        || items.find((item) => String(item.external_id ?? '') === value)
      if (exact) {
        openById(exact.id)
        return
      }
      render(items)
    } catch (error) {
      results.innerHTML = `<div class="small" style="color:var(--danger)">${esc(error.message)}</div>`
    }
  }

  el.querySelector('[data-go]').addEventListener('click', run)
  el.querySelector('[data-close]').addEventListener('click', close)
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault()
      run()
    }
  })

  // Ищем сразу при вводе или вставке: ссылка, имя, объявление, заказ
  let timer = null
  input.addEventListener('input', () => {
    clearTimeout(timer)
    timer = setTimeout(run, 300)
  })
}
