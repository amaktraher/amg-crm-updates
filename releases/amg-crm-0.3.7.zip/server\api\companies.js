import { db } from '../db.js'
import { audit, logActivity } from '../audit.js'
import { requirePermission, requireUser } from '../auth.js'
import { HttpError } from '../http.js'
import {
  clampInt, idOf, idOrNull, oneOf, optionalEmail, optionalText, text,
} from '../validate.js'

const STATUSES = ['lead', 'active', 'vip', 'archived']
const ACTIVITY_KINDS = ['note', 'call', 'email', 'meeting']

const LIST_SELECT = `
  SELECT c.*, u.name AS owner_name,
    (SELECT COUNT(*) FROM contacts x WHERE x.company_id = c.id) AS contacts_count,
    (SELECT COUNT(*) FROM tasks t WHERE t.company_id = c.id AND t.status != 'done') AS open_tasks,
    (SELECT MAX(a.created_at) FROM activities a WHERE a.entity_type = 'company' AND a.entity_id = c.id) AS last_activity_at,
    (SELECT MAX(t.updated_at) FROM tasks t WHERE t.company_id = c.id) AS last_task_at
  FROM companies c
  LEFT JOIN users u ON u.id = c.owner_id`

function readCompany(body, existing = null) {
  return {
    name: body.name === undefined ? existing?.name : text(body.name, 'Название', { max: 200 }),
    industry: body.industry === undefined ? existing?.industry ?? null : optionalText(body.industry, 'Сфера', { max: 120 }),
    website: body.website === undefined ? existing?.website ?? null : optionalText(body.website, 'Сайт', { max: 200 }),
    phone: body.phone === undefined ? existing?.phone ?? null : optionalText(body.phone, 'Телефон', { max: 60 }),
    email: body.email === undefined ? existing?.email ?? null : optionalEmail(body.email),
    address: body.address === undefined ? existing?.address ?? null : optionalText(body.address, 'Адрес', { max: 300 }),
    status: body.status === undefined ? existing?.status ?? 'lead' : oneOf(body.status, STATUSES, 'статус'),
    note: body.note === undefined ? existing?.note ?? null : optionalText(body.note, 'Заметка', { max: 4000 }),
    ownerId: body.ownerId === undefined ? existing?.owner_id ?? null : idOrNull(body.ownerId, 'ответственный'),
  }
}

export function registerCompanyRoutes(router) {
  router.get('/api/companies', async ({ query, user }) => {
    requireUser({ user })
    const q = String(query.get('q') ?? '').trim()
    const status = query.get('status')
    const ownerId = query.get('ownerId')
    const page = clampInt(query.get('page'), { min: 1, max: 100000, fallback: 1 })
    const pageSize = clampInt(query.get('pageSize'), { min: 5, max: 100, fallback: 25 })
    const sort = query.get('sort') ?? 'created'

    const where = []
    const params = []
    if (q) {
      where.push('(c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ? OR c.industry LIKE ?)')
      const like = `%${q}%`
      params.push(like, like, like, like)
    }
    if (status && STATUSES.includes(status)) { where.push('c.status = ?'); params.push(status) }
    if (ownerId && ownerId !== 'all') { where.push('c.owner_id = ?'); params.push(Number(ownerId)) }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : ''
    const order = {
      name: 'c.name COLLATE NOCASE ASC',
      activity: 'COALESCE(last_activity_at, last_task_at, c.created_at) DESC',
      created: 'c.created_at DESC',
    }[sort] ?? 'c.created_at DESC'

    const total = db.prepare(`SELECT COUNT(*) AS c FROM companies c ${whereSql}`).get(...params).c
    const rows = db.prepare(`${LIST_SELECT} ${whereSql} ORDER BY ${order} LIMIT ? OFFSET ?`)
      .all(...params, pageSize, (page - 1) * pageSize)

    return { items: rows, total, page, pageSize }
  })

  router.get('/api/companies/:id', async ({ params, user }) => {
    requireUser({ user })
    const id = idOf(params.id)
    const company = db.prepare(`${LIST_SELECT} WHERE c.id = ?`).get(id)
    if (!company) throw new HttpError(404, 'Клиент не найден', 'NOT_FOUND')
    const contacts = db.prepare(`SELECT * FROM contacts WHERE company_id = ?
      ORDER BY is_primary DESC, first_name COLLATE NOCASE`).all(id)
    const tasks = db.prepare(`SELECT t.*, u.name AS assignee_name FROM tasks t
      LEFT JOIN users u ON u.id = t.assignee_id
      WHERE t.company_id = ? ORDER BY (t.status = 'done'), COALESCE(t.due_at, t.created_at) ASC`).all(id)
    const activities = db.prepare(`SELECT a.*, u.name AS user_name FROM activities a
      LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity_type = 'company' AND a.entity_id = ?
      ORDER BY a.created_at DESC LIMIT 100`).all(id)
    return { item: company, contacts, tasks, activities }
  })

  router.post('/api/companies', async ({ body, user }) => {
    const actor = requirePermission({ user }, 'write')
    const data = readCompany(body)
    const stamp = new Date().toISOString()
    const res = db.prepare(`INSERT INTO companies
      (name, industry, website, phone, email, address, status, note, owner_id, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(data.name, data.industry, data.website, data.phone, data.email, data.address, data.status,
        data.note, data.ownerId ?? actor.id, actor.id, stamp, stamp)
    const id = Number(res.lastInsertRowid)
    logActivity('company', id, 'system', `Клиент создан: ${data.name}`, actor.id)
    audit(actor.id, 'create', 'company', id, { name: data.name })
    return { item: db.prepare(`${LIST_SELECT} WHERE c.id = ?`).get(id) }
  })

  router.patch('/api/companies/:id', async ({ body, params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT * FROM companies WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Клиент не найден', 'NOT_FOUND')
    const data = readCompany(body, existing)
    db.prepare(`UPDATE companies SET name = ?, industry = ?, website = ?, phone = ?, email = ?,
      address = ?, status = ?, note = ?, owner_id = ?, updated_at = ? WHERE id = ?`)
      .run(data.name, data.industry, data.website, data.phone, data.email, data.address, data.status,
        data.note, data.ownerId, new Date().toISOString(), id)
    if (existing.status !== data.status) {
      logActivity('company', id, 'system', `Статус изменён: ${existing.status} → ${data.status}`, actor.id)
    }
    audit(actor.id, 'update', 'company', id)
    return { item: db.prepare(`${LIST_SELECT} WHERE c.id = ?`).get(id) }
  })

  router.delete('/api/companies/:id', async ({ params, user }) => {
    const actor = requirePermission({ user }, 'manageUsers')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT name FROM companies WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Клиент не найден', 'NOT_FOUND')
    db.prepare('DELETE FROM companies WHERE id = ?').run(id)
    audit(actor.id, 'delete', 'company', id, { name: existing.name })
    return { ok: true }
  })

  router.get('/api/companies/:id/activities', async ({ params, query, user }) => {
    requireUser({ user })
    const id = idOf(params.id)
    const limit = clampInt(query.get('limit'), { min: 1, max: 200, fallback: 50 })
    const items = db.prepare(`SELECT a.*, u.name AS user_name FROM activities a
      LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity_type = 'company' AND a.entity_id = ?
      ORDER BY a.created_at DESC LIMIT ?`).all(id, limit)
    return { items }
  })

  router.post('/api/companies/:id/activities', async ({ body, params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    if (!db.prepare('SELECT 1 FROM companies WHERE id = ?').get(id)) {
      throw new HttpError(404, 'Клиент не найден', 'NOT_FOUND')
    }
    const kind = oneOf(body.kind ?? 'note', ACTIVITY_KINDS, 'тип')
    const bodyText = text(body.body, 'Текст', { max: 4000 })
    logActivity('company', id, kind, bodyText, actor.id)
    audit(actor.id, 'activity', 'company', id, { kind })
    return { ok: true }
  })
}
