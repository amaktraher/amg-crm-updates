import { db } from '../db.js'
import { audit, logActivity } from '../audit.js'
import { requirePermission, requireUser } from '../auth.js'
import { HttpError } from '../http.js'
import {
  clampInt, idOf, idOrNull, isoOrNull, oneOf, optionalText, text,
} from '../validate.js'

const STATUSES = ['new', 'chat', 'deal', 'archive']

const SELECT = `
  SELECT a.*, c.name AS company_name, u.name AS owner_name
  FROM avito_leads a
  LEFT JOIN companies c ON c.id = a.company_id
  LEFT JOIN users u ON u.id = a.owner_id`

export function registerAvitoRoutes(router) {
  router.get('/api/avito', async ({ query, user }) => {
    requireUser({ user })
    const q = String(query.get('q') ?? '').trim()
    const status = query.get('status')
    const where = []
    const params = []
    if (q) {
      where.push('(a.client_name LIKE ? OR a.phone LIKE ? OR a.item LIKE ? OR a.message LIKE ?)')
      const like = `%${q}%`
      params.push(like, like, like, like)
    }
    if (status && STATUSES.includes(status)) { where.push('a.status = ?'); params.push(status) }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : ''
    const items = db.prepare(`${SELECT} ${whereSql}
      ORDER BY (a.status = 'archive'), a.updated_at DESC LIMIT ?`).all(...params, clampInt(query.get('limit'), { max: 200, fallback: 100 }))
    return { items }
  })

  router.post('/api/avito', async ({ body, user }) => {
    const actor = requirePermission({ user }, 'write')
    const stamp = new Date().toISOString()
    const clientName = text(body.clientName, 'Клиент', { max: 200 })
    const data = {
      phone: optionalText(body.phone, 'Телефон', { max: 60 }),
      item: optionalText(body.item, 'Товар/объявление', { max: 200 }),
      message: optionalText(body.message, 'Сообщение', { max: 4000 }),
      status: oneOf(body.status ?? 'new', STATUSES, 'статус'),
      ownerId: idOrNull(body.ownerId, 'ответственный'),
      companyId: idOrNull(body.companyId, 'клиент'),
    }
    const res = db.prepare(`INSERT INTO avito_leads
      (client_name, phone, item, message, status, company_id, owner_id, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      clientName, data.phone, data.item, data.message, data.status, data.companyId,
      data.ownerId ?? actor.id, stamp, stamp,
    )
    const id = Number(res.lastInsertRowid)
    audit(actor.id, 'create', 'avito', id, { clientName })
    return { item: db.prepare(`${SELECT} WHERE a.id = ?`).get(id) }
  })

  router.patch('/api/avito/:id', async ({ body, params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT * FROM avito_leads WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Карточка не найдена', 'NOT_FOUND')
    const data = {
      clientName: body.clientName === undefined ? existing.client_name : text(body.clientName, 'Клиент', { max: 200 }),
      phone: body.phone === undefined ? existing.phone : optionalText(body.phone, 'Телефон', { max: 60 }),
      item: body.item === undefined ? existing.item : optionalText(body.item, 'Товар', { max: 200 }),
      message: body.message === undefined ? existing.message : optionalText(body.message, 'Сообщение', { max: 4000 }),
      status: body.status === undefined ? existing.status : oneOf(body.status, STATUSES, 'статус'),
      ownerId: body.ownerId === undefined ? existing.owner_id : idOrNull(body.ownerId, 'ответственный'),
    }
    db.prepare(`UPDATE avito_leads SET client_name = ?, phone = ?, item = ?, message = ?, status = ?,
      owner_id = ?, updated_at = ? WHERE id = ?`).run(
      data.clientName, data.phone, data.item, data.message, data.status,
      data.ownerId, new Date().toISOString(), id,
    )
    audit(actor.id, 'update', 'avito', id)
    return { item: db.prepare(`${SELECT} WHERE a.id = ?`).get(id) }
  })

  router.delete('/api/avito/:id', async ({ params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT client_name FROM avito_leads WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Карточка не найдена', 'NOT_FOUND')
    db.prepare('DELETE FROM avito_leads WHERE id = ?').run(id)
    audit(actor.id, 'delete', 'avito', id, { clientName: existing.client_name })
    return { ok: true }
  })

  /** Превратить карточку Авито в клиента CRM. */
  router.post('/api/avito/:id/convert', async ({ params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT * FROM avito_leads WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Карточка не найдена', 'NOT_FOUND')
    if (existing.company_id) {
      return { item: db.prepare(`${SELECT} WHERE a.id = ?`).get(id) }
    }
    const stamp = new Date().toISOString()
    const note = [existing.item ? `Авито: ${existing.item}` : null, existing.message]
      .filter(Boolean).join('\n')
    const res = db.prepare(`INSERT INTO companies
      (name, phone, status, note, owner_id, created_by, created_at, updated_at)
      VALUES (?, ?, 'lead', ?, ?, ?, ?, ?)`).run(
      existing.client_name, existing.phone, note || null, existing.owner_id, actor.id, stamp, stamp,
    )
    const companyId = Number(res.lastInsertRowid)
    db.prepare('UPDATE avito_leads SET company_id = ?, updated_at = ? WHERE id = ?').run(companyId, stamp, id)
    logActivity('company', companyId, 'system', 'Клиент создан из карточки Авито', actor.id)
    audit(actor.id, 'convert', 'avito', id, { companyId })
    return { item: db.prepare(`${SELECT} WHERE a.id = ?`).get(id), companyId }
  })
}
