/* Профиль: личные данные, пароль, оформление. */
import {
  ROLE_LABELS, api, avatar, applyTheme, esc, fmtDateTime, icon, state, toast,
} from '../lib.js'

export default {
  subtitle: () => 'Личные данные и безопасность',
  async render(ctx) {
    const user = state.user
    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Профиль</h2><div class="hint">Данные вашей учётной записи</div></div>
      </div>

      <div class="grid-2">
        <div style="display:flex;flex-direction:column;gap:16px">
          <div class="card">
            <div class="card-head"><h3>Личные данные</h3></div>
            <div class="card-pad">
              <form class="form-grid" id="profile-form">
                <div class="field span-2">
                  <label for="p-name">Имя</label>
                  <input class="input" id="p-name" name="name" value="${esc(user.name)}" required />
                </div>
                <div class="field span-2">
                  <label for="p-phone">Телефон</label>
                  <input class="input" id="p-phone" name="phone" value="${esc(user.phone ?? '')}" placeholder="+7 900 000-00-00" />
                </div>
                <div class="field span-2">
                  <label>E-mail</label>
                  <input class="input" value="${esc(user.email)}" disabled />
                  <span class="hint">E-mail меняет администратор</span>
                </div>
                <div class="field span-2" id="profile-error" style="display:none"><span class="error"></span></div>
                <div class="field span-2" style="flex-direction:row;justify-content:flex-end">
                  <button class="btn btn-primary" type="submit">Сохранить</button>
                </div>
              </form>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h3>Смена пароля</h3></div>
            <div class="card-pad">
              <form class="form-grid" id="password-form">
                <div class="field span-2">
                  <label for="p-current">Текущий пароль</label>
                  <input class="input" id="p-current" name="currentPassword" type="password" autocomplete="current-password" required />
                </div>
                <div class="field">
                  <label for="p-new">Новый пароль</label>
                  <input class="input" id="p-new" name="newPassword" type="password" autocomplete="new-password" required />
                </div>
                <div class="field">
                  <label for="p-repeat">Повтор</label>
                  <input class="input" id="p-repeat" name="repeat" type="password" autocomplete="new-password" required />
                </div>
                <div class="field span-2" id="password-error" style="display:none"><span class="error"></span></div>
                <div class="field span-2" style="flex-direction:row;justify-content:flex-end">
                  <button class="btn" type="submit">Обновить пароль</button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:16px">
          <div class="card card-pad" style="display:flex;gap:14px;align-items:center">
            ${avatar(user.name, { size: 'xl' })}
            <div style="min-width:0">
              <div style="font-size:17px;font-weight:650">${esc(user.name)}</div>
              <div class="small muted">${esc(user.email)}</div>
              <div style="margin-top:6px"><span class="pill ${user.role === 'admin' ? 'vip' : user.role === 'manager' ? 'info' : 'archived'}">${esc(ROLE_LABELS[user.role])}</span></div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h3>Учётная запись</h3></div>
            <div class="card-pad">
              <div class="info-list">
                <div class="info-row">${icon('calendar', 16)}<div><div class="k">В системе с</div>
                  <div class="v">${fmtDateTime(user.createdAt)}</div></div></div>
                <div class="info-row">${icon('clock', 16)}<div><div class="k">Последний вход</div>
                  <div class="v">${user.lastLoginAt ? fmtDateTime(user.lastLoginAt) : '—'}</div></div></div>
                <div class="info-row">${icon('shield', 16)}<div><div class="k">Права</div>
                  <div class="v">${user.role === 'admin' ? 'Полный доступ, управление командой и журналом'
    : user.role === 'manager' ? 'Просмотр и редактирование клиентов и задач'
      : 'Только просмотр'}</div></div></div>
                <div class="info-row">${icon('refresh', 16)}<div><div class="k">Версия программы</div>
                  <div class="v" id="app-version">—</div></div></div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h3>Оформление</h3></div>
            <div class="card-pad">
              <div class="segmented" id="theme">
                <button data-theme="light" class="${state.theme === 'light' ? 'active' : ''}">${icon('sun', 14)} Светлая</button>
                <button data-theme="dark" class="${state.theme === 'dark' ? 'active' : ''}">${icon('moon', 14)} Тёмная</button>
              </div>
              <p class="hint" style="margin-top:10px">Тема сохраняется в этом браузере.</p>
            </div>
          </div>

          ${state.permissions?.manageUsers ? `
          <div class="card">
            <div class="card-head"><h3>Очистка данных</h3></div>
            <div class="card-pad">
              <p class="hint">Удаляет всех клиентов, контакты, задачи, звонки, карточки Авито, события и журнал.
                Пользователи и пароли остаются.</p>
              <button class="btn btn-danger" id="reset-data" type="button" style="margin-top:10px">
                ${icon('trash', 15)} Очистить все данные
              </button>
            </div>
          </div>` : ''}
        </div>
      </div>`

    const profileForm = ctx.root.querySelector('#profile-form')
    profileForm.addEventListener('submit', async (event) => {
      event.preventDefault()
      const errorBox = ctx.root.querySelector('#profile-error')
      errorBox.style.display = 'none'
      try {
        const result = await api('/api/auth/me', {
          method: 'PATCH',
          body: { name: profileForm.name.value, phone: profileForm.phone.value },
        })
        state.user = result.user
        toast('Данные сохранены')
        ctx.refresh()
      } catch (error) {
        errorBox.style.display = ''
        errorBox.querySelector('.error').textContent = error.message
      }
    })

    const passwordForm = ctx.root.querySelector('#password-form')
    passwordForm.addEventListener('submit', async (event) => {
      event.preventDefault()
      const errorBox = ctx.root.querySelector('#password-error')
      errorBox.style.display = 'none'
      if (passwordForm.newPassword.value !== passwordForm.repeat.value) {
        errorBox.style.display = ''
        errorBox.querySelector('.error').textContent = 'Пароли не совпадают'
        return
      }
      try {
        await api('/api/auth/me', {
          method: 'PATCH',
          body: {
            currentPassword: passwordForm.currentPassword.value,
            newPassword: passwordForm.newPassword.value,
          },
        })
        passwordForm.reset()
        toast('Пароль обновлён')
      } catch (error) {
        errorBox.style.display = ''
        errorBox.querySelector('.error').textContent = error.message
      }
    })

    ctx.root.querySelectorAll('#theme button').forEach((button) => {
      button.addEventListener('click', () => {
        applyTheme(button.dataset.theme)
        ctx.root.querySelectorAll('#theme button').forEach((item) => item.classList.toggle('active', item === button))
        document.getElementById('theme-toggle').innerHTML = icon(state.theme === 'dark' ? 'sun' : 'moon', 17)
      })
    })

    api('/api/system/version').then((data) => {
      const label = document.getElementById('app-version')
      if (label) label.textContent = data.version
    }).catch(() => {})

    ctx.root.querySelector('#reset-data')?.addEventListener('click', async () => {
      const answer = window.prompt('Это удалит всех клиентов, задачи, звонки и журнал.\nЧтобы подтвердить, введите слово УДАЛИТЬ')
      if (answer === null) return
      if (answer.trim().toUpperCase() !== 'УДАЛИТЬ') {
        toast('Отменено: нужно было ввести УДАЛИТЬ', 'error')
        return
      }
      try {
        await api('/api/system/reset', { method: 'POST', body: { confirm: 'УДАЛИТЬ' } })
        toast('Все данные удалены')
        ctx.refresh()
      } catch (error) {
        toast(error.message, 'error')
      }
    })
  },
}

