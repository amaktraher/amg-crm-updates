import { db } from '../db.js'
import { audit } from '../audit.js'
import {
  PERMISSIONS, can, checkLoginRate, clearLoginFailures, clearedCookie, createSession,
  destroySession, noteLoginFailure, publicUser, requireUser, sessionCookie,
} from '../auth.js'
import { HttpError } from '../http.js'
import { verifyPassword, hashPassword } from '../security.js'
import { emailOf, optionalText, text } from '../validate.js'

export function registerAuthRoutes(router) {
  router.post('/api/auth/login', async ({ body, req, res }) => {
    const identifier = text(body.identifier ?? body.email ?? body.login ?? '', 'Логин', { max: 200 })
    const password = String(body.password ?? '')
    const ip = req.socket.remoteAddress ?? 'unknown'
    const key = `${ip}|${identifier.toLowerCase()}`
    checkLoginRate(key)

    const row = db.prepare(`SELECT * FROM users
      WHERE is_active = 1 AND (lower(login) = lower(?) OR lower(email) = lower(?) OR lower(name) = lower(?))
      ORDER BY (lower(login) = lower(?)) DESC
      LIMIT 1`).get(identifier, identifier, identifier, identifier)
    if (!row || !verifyPassword(password, row.password_hash)) {
      noteLoginFailure(key)
      throw new HttpError(401, 'Неверный логин или пароль', 'BAD_CREDENTIALS')
    }
    clearLoginFailures(key)

    const stamp = new Date().toISOString()
    db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(stamp, row.id)
    const { token, expiresAt } = createSession(row.id, req.headers['user-agent'] ?? '')
    res.setHeader('Set-Cookie', sessionCookie(token, expiresAt))
    audit(row.id, 'login', 'user', row.id)
    return { user: publicUser({ ...row, last_login_at: stamp }), permissions: PERMISSIONS[row.role] }
  })

  router.get('/api/auth/accounts', async () => {
    const rows = db.prepare(`SELECT login, name, role FROM users
      WHERE is_active = 1 AND login IS NOT NULL
      ORDER BY (role = 'admin') DESC, name COLLATE NOCASE`).all()
    return { items: rows.map((row) => ({ login: row.login, name: row.name, role: row.role })) }
  })

  router.post('/api/auth/logout', async ({ req, res }) => {
    destroySession(req)
    res.setHeader('Set-Cookie', clearedCookie())
    return { ok: true }
  })

  router.get('/api/auth/me', async ({ user }) => {
    if (!user) return { user: null, permissions: null }
    return { user, permissions: PERMISSIONS[user.role] }
  })

  router.patch('/api/auth/me', async ({ body, user }) => {
    const current = requireUser({ user })
    const name = body.name === undefined ? current.name : text(body.name, 'Имя', { max: 120 })
    const phone = body.phone === undefined ? current.phone : optionalText(body.phone, 'Телефон', { max: 40 })

    if (body.newPassword !== undefined && String(body.newPassword).length > 0) {
      const newPassword = String(body.newPassword)
      if (newPassword.length < 8) throw new HttpError(400, 'Пароль должен быть не короче 8 символов', 'VALIDATION')
      const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(current.id)
      if (!verifyPassword(String(body.currentPassword ?? ''), row.password_hash)) {
        throw new HttpError(400, 'Текущий пароль неверен', 'BAD_PASSWORD')
      }
      db.prepare('UPDATE users SET name = ?, phone = ?, password_hash = ? WHERE id = ?')
        .run(name, phone, hashPassword(newPassword), current.id)
      audit(current.id, 'change-password', 'user', current.id)
    } else {
      db.prepare('UPDATE users SET name = ?, phone = ? WHERE id = ?').run(name, phone, current.id)
    }
    const fresh = db.prepare('SELECT * FROM users WHERE id = ?').get(current.id)
    return { user: publicUser(fresh), permissions: PERMISSIONS[fresh.role] }
  })
}
