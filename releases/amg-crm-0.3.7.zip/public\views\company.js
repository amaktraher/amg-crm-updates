/* Карточка клиента: контакты, задачи, история общения и реквизиты. */
import {
  ACTIVITY_KIND, COMPANY_STATUS, ROLE_LABELS, api, avatar, dueMeta, esc, fmtDate, fmtDateTime, icon,
  plural, relTime, state, toast,
} from '../lib.js'
import { openCompanyForm, openContactForm, openTaskForm } from './forms.js'

export default {
  subtitle: (params) => `Карточка №${params.id}`,
  async render(ctx) {
    const { item: company, contacts, tasks, activities } = await api(`/api/companies/${ctx.params.id}`)
    const canWrite = state.permissions?.write
    const isAdmin = state.user.role === 'admin'
    const statusMeta = COMPANY_STATUS[company.status] ?? { label: company.status, cls: '' }
    const openTasks = tasks.filter((task) => task.status !== 'done')

    ctx.setSubtitle(company.industry ?? 'Карточка клиента')
    document.getElementById('page-title').textContent = company.name

    ctx.root.innerHTML = `
      <div class="breadcrumbs">
        <a data-nav="/companies">Клиенты</a> ${icon('chevronRight', 13)} <span>${esc(company.name)}</span>
      </div>

      <div class="hero">
        ${avatar(company.name, { size: 'xl', companyName: true })}
        <div style="min-width:0;flex:1">
          <div class="row wrap" style="gap:10px">
            <div class="name">${esc(company.name)}</div>
            <span class="pill ${statusMeta.cls}">${esc(statusMeta.label)}</span>
          </div>
          <div class="meta">
            ${company.industry ? `<span>${icon('briefcase', 13)} ${esc(company.industry)}</span>` : ''}
            ${company.phone ? `<span>${icon('phone', 13)} ${esc(company.phone)}</span>` : ''}
            ${company.email ? `<span>${icon('mail', 13)} ${esc(company.email)}</span>` : ''}
            ${company.address ? `<span>${icon('pin', 13)} ${esc(company.address)}</span>` : ''}
          </div>
          <div class="hero-stats">
            <div class="stat"><div class="v">${contacts.length}</div><div class="k">контактов</div></div>
            <div class="stat"><div class="v">${openTasks.length}</div><div class="k">задач в работе</div></div>
            <div class="stat"><div class="v">${activities.length}</div><div class="k">событий в истории</div></div>
          </div>
        </div>
        <div class="row wrap" style="gap:8px">
          ${canWrite ? `<button class="btn" data-act="edit">${icon('edit', 15)} Изменить</button>` : ''}
          ${canWrite ? `<button class="btn btn-primary" data-act="new-task">${icon('plus', 15)} Задача</button>` : ''}
          <button class="icon-btn" data-act="menu" title="Ещё">${icon('more', 17)}</button>
        </div>
      </div>

      <div class="grid-2">
        <div style="display:flex;flex-direction:column;gap:16px">
          <div class="card">
            <div class="card-head">
              <h3>Контакты</h3>
              <div class="actions">
                ${canWrite ? `<button class="btn btn-sm" data-act="new-contact">${icon('plus', 14)} Добавить</button>` : ''}
              </div>
            </div>
            <div class="card-pad" style="display:flex;flex-direction:column;gap:10px">
              ${contacts.length === 0
    ? `<div class="empty" style="padding:22px">
        <div class="icon">${icon('users', 22)}</div>
        <h4>Контактов пока нет</h4>
        <p>Добавьте людей, с которыми общаетесь по этому клиенту.</p>
        ${canWrite ? `<button class="btn btn-sm" data-act="new-contact">${icon('plus', 14)} Добавить контакт</button>` : ''}
      </div>`
    : contacts.map((contact) => `
                <div class="contact-tile">
                  ${avatar(`${contact.first_name} ${contact.last_name ?? ''}`)}
                  <div class="grow">
                    <div class="row wrap" style="gap:8px">
                      <b style="font-size:13.5px">${esc(contact.first_name)} ${esc(contact.last_name ?? '')}</b>
                      ${contact.is_primary ? '<span class="pill plain vip">основной</span>' : ''}
                    </div>
                    <div class="small muted">${esc(contact.position ?? 'Должность не указана')}</div>
                    <div class="row wrap small" style="gap:12px;margin-top:5px;color:var(--text-2)">
                      ${contact.phone ? `<span class="row" style="gap:4px">${icon('phone', 12)} ${esc(contact.phone)}</span>` : ''}
                      ${contact.email ? `<span class="row" style="gap:4px">${icon('mail', 12)} ${esc(contact.email)}</span>` : ''}
                      ${contact.telegram ? `<span>${esc(contact.telegram)}</span>` : ''}
                    </div>
                  </div>
                  ${canWrite ? `<div class="row" style="gap:4px">
                    <button class="icon-btn" style="width:30px;height:30px" data-edit-contact="${contact.id}" title="Изменить">${icon('edit', 14)}</button>
                    <button class="icon-btn" style="width:30px;height:30px" data-del-contact="${contact.id}" title="Удалить">${icon('trash', 14)}</button>
                  </div>` : ''}
                </div>`).join('')}
            </div>
          </div>

          <div class="card">
            <div class="card-head">
              <h3>Задачи клиента</h3>
              <div class="actions">
                ${canWrite ? `<button class="btn btn-sm" data-act="new-task">${icon('plus', 14)} Задача</button>` : ''}
              </div>
            </div>
            <div class="card-pad" style="padding-top:4px">
              ${tasks.length === 0
    ? `<div class="empty" style="padding:22px"><div class="icon">${icon('kanban', 22)}</div>
        <h4>Задач нет</h4><p>Поставьте задачу — она попадёт в общий список и календарь.</p></div>`
    : `<div class="list">${tasks.map((task) => {
      const due = dueMeta(task.due_at, task.status)
      return `<div class="list-row">
                    <button class="icon-btn" style="width:26px;height:26px;border-radius:50%;border-color:${task.status === 'done' ? 'var(--success)' : 'var(--border-strong)'};color:${task.status === 'done' ? 'var(--success)' : 'transparent'}"
                      data-toggle="${task.id}" title="Отметить выполнение">${icon('check', 14)}</button>
                    <div class="grow" data-task-open="${task.id}" style="cursor:pointer">
                      <div class="t" style="font-size:13.5px;${task.status === 'done' ? 'text-decoration:line-through;color:var(--muted)' : ''}">${esc(task.title)}</div>
                      <div class="s small muted">${task.assignee_name ? esc(task.assignee_name) : 'Без исполнителя'}</div>
                    </div>
                    <span class="due ${due.cls} small nowrap">${task.due_at ? `${icon('clock', 13)} ${esc(due.text)}` : ''}</span>
                  </div>`
    }).join('')}</div>`}
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h3>История общения</h3></div>
            <div class="card-pad">
              ${canWrite ? `
              <div style="margin-bottom:14px">
                <div class="row" style="gap:8px;margin-bottom:8px">
                  <select class="select" id="act-kind" style="width:150px">
                    <option value="note">Заметка</option>
                    <option value="call">Звонок</option>
                    <option value="email">Письмо</option>
                    <option value="meeting">Встреча</option>
                  </select>
                  <span class="small muted">Добавить событие в историю</span>
                </div>
                <textarea class="textarea" id="act-body" rows="2" placeholder="Что произошло? Договорённости, итоги звонка…"></textarea>
                <div class="row" style="justify-content:flex-end;margin-top:8px">
                  <button class="btn btn-primary btn-sm" id="act-add">${icon('plus', 14)} Добавить</button>
                </div>
              </div>` : ''}
              ${activities.length === 0
    ? `<div class="empty" style="padding:18px"><p>Событий ещё нет — начните с заметки о первом контакте.</p></div>`
    : `<div class="timeline">${activities.map((activity) => {
      const kind = ACTIVITY_KIND[activity.kind] ?? ACTIVITY_KIND.note
      return `<div class="timeline-item">
                      <span class="timeline-icon ${kind.cls}">${icon(kind.icon, 14)}</span>
                      <div class="timeline-body">
                        <div class="text">${esc(activity.body)}</div>
                        <div class="meta"><span>${esc(kind.label)}</span><span>·</span>
                          <span>${esc(activity.user_name ?? 'Система')}</span><span>·</span>
                          <span>${fmtDateTime(activity.created_at)}</span></div>
                      </div>
                    </div>`
    }).join('')}</div>`}
            </div>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:16px">
          <div class="card">
            <div class="card-head"><h3>Реквизиты</h3></div>
            <div class="card-pad">
              <div class="info-list">
                <div class="info-row">${icon('user', 16)}<div><div class="k">Ответственный</div>
                  <div class="v">${company.owner_name ? esc(company.owner_name) : 'Не назначен'}</div></div></div>
                <div class="info-row">${icon('phone', 16)}<div><div class="k">Телефон</div>
                  <div class="v">${company.phone ? `<a href="tel:${esc(company.phone)}">${esc(company.phone)}</a>` : '—'}</div></div></div>
                <div class="info-row">${icon('mail', 16)}<div><div class="k">E-mail</div>
                  <div class="v">${company.email ? `<a href="mailto:${esc(company.email)}">${esc(company.email)}</a>` : '—'}</div></div></div>
                <div class="info-row">${icon('globe', 16)}<div><div class="k">Сайт</div>
                  <div class="v">${company.website
    ? `<a href="${esc(company.website)}" target="_blank" rel="noopener">${esc(company.website.replace(/^https?:\/\//, ''))}</a>`
    : '—'}</div></div></div>
                <div class="info-row">${icon('pin', 16)}<div><div class="k">Адрес</div>
                  <div class="v">${company.address ? esc(company.address) : '—'}</div></div></div>
                <div class="info-row">${icon('calendar', 16)}<div><div class="k">В базе с</div>
                  <div class="v">${fmtDate(company.created_at)}</div></div></div>
              </div>
            </div>
          </div>

          ${company.note ? `<div class="card">
            <div class="card-head"><h3>Заметка</h3></div>
            <div class="card-pad"><p style="font-size:13.5px;color:var(--text-2);white-space:pre-wrap">${esc(company.note)}</p></div>
          </div>` : ''}

          <div class="card">
            <div class="card-head"><h3>Быстрые действия</h3></div>
            <div class="card-pad" style="display:flex;flex-direction:column;gap:8px">
              ${canWrite ? `<button class="btn" data-act="new-task" style="justify-content:flex-start">${icon('plus', 15)} Поставить задачу</button>` : ''}
              ${canWrite ? `<button class="btn" data-act="new-contact" style="justify-content:flex-start">${icon('users', 15)} Добавить контакт</button>` : ''}
              <button class="btn" data-act="back" style="justify-content:flex-start">${icon('arrowLeft', 15)} К списку клиентов</button>
            </div>
          </div>
        </div>
      </div>`

    /* ── Обработчики ─────────────────────────────────────── */

    ctx.root.querySelector('[data-nav="/companies"]').addEventListener('click', (event) => {
      event.preventDefault()
      ctx.navigate('/companies')
    })
    ctx.root.querySelector('[data-act="back"]')?.addEventListener('click', () => ctx.navigate('/companies'))
    ctx.root.querySelectorAll('[data-act="edit"]').forEach((button) => {
      button.addEventListener('click', () => openCompanyForm(company, ctx.refresh))
    })
    ctx.root.querySelectorAll('[data-act="new-task"]').forEach((button) => {
      button.addEventListener('click', () => openTaskForm(null, ctx.refresh, { companyId: company.id }))
    })
    ctx.root.querySelectorAll('[data-act="new-contact"]').forEach((button) => {
      button.addEventListener('click', () => openContactForm(null, ctx.refresh, { companyId: company.id }))
    })
    ctx.root.querySelector('[data-act="menu"]').addEventListener('click', async (event) => {
      const { dropdown, confirmDialog } = await import('../lib.js')
      dropdown(event.currentTarget, [
        { label: 'Открыть в списке', icon: 'building', onClick: () => ctx.navigate('/companies') },
        ...(canWrite ? [{ label: 'Редактировать', icon: 'edit', onClick: () => openCompanyForm(company, ctx.refresh) }] : []),
        ...(isAdmin ? [{ sep: true }, {
          label: 'Удалить клиента',
          icon: 'trash',
          danger: true,
          onClick: async () => {
            if (!await confirmDialog({
              title: 'Удалить клиента?',
              message: `«${company.name}» и все контакты будут удалены безвозвратно.`,
            })) return
            await api(`/api/companies/${company.id}`, { method: 'DELETE' })
            toast('Клиент удалён')
            ctx.navigate('/companies')
          },
        }] : []),
      ])
    })

    ctx.root.querySelectorAll('[data-edit-contact]').forEach((button) => {
      button.addEventListener('click', () => {
        const contact = contacts.find((item) => String(item.id) === button.dataset.editContact)
        openContactForm(contact, ctx.refresh)
      })
    })
    ctx.root.querySelectorAll('[data-del-contact]').forEach((button) => {
      button.addEventListener('click', async () => {
        const contact = contacts.find((item) => String(item.id) === button.dataset.delContact)
        const { confirmDialog } = await import('../lib.js')
        if (!await confirmDialog({
          title: 'Удалить контакт?',
          message: `${contact.first_name} ${contact.last_name ?? ''} будет удалён из базы.`,
        })) return
        await api(`/api/contacts/${contact.id}`, { method: 'DELETE' })
        toast('Контакт удалён')
        ctx.refresh()
      })
    })

    ctx.root.querySelectorAll('[data-toggle]').forEach((button) => {
      button.addEventListener('click', async () => {
        await api(`/api/tasks/${button.dataset.toggle}/toggle`, { method: 'POST' })
        ctx.refresh()
      })
    })
    ctx.root.querySelectorAll('[data-task-open]').forEach((row) => {
      row.addEventListener('click', () => {
        const task = tasks.find((item) => String(item.id) === row.dataset.taskOpen)
        openTaskForm(task, ctx.refresh)
      })
    })

    const addActivity = async () => {
      const body = ctx.root.querySelector('#act-body').value.trim()
      if (!body) {
        toast('Напишите текст события', 'warning')
        return
      }
      await api(`/api/companies/${company.id}/activities`, {
        method: 'POST',
        body: { kind: ctx.root.querySelector('#act-kind').value, body },
      })
      toast('Добавлено в историю')
      ctx.refresh()
    }
    ctx.root.querySelector('#act-add')?.addEventListener('click', addActivity)
    ctx.root.querySelector('#act-body')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) addActivity()
    })
  },
}
