/* Звонки: карточки входящих обращений, распределённые по магазинам. */
import {
  api, emptyState, esc, fmtDate, fmtDateTime, fromInputDateTime, icon, relTime, state, toast, toInputDateTime,
} from '../lib.js'
import { formModal, confirmDialog, dropdown } from '../lib.js'

const STORE_LABELS = {
  pargolovo: 'Парголово',
  'dunaysky-27k1': 'Дунайский 27к1',
  pushkino: 'Пушкино',
  krasnodar: 'Краснодар',
  'kaliningrad-1': 'Калининград 1',
  'kaliningrad-2': 'Калининград 2',
}

const OPERATOR_LABELS = {
  andrey: 'Андрей К.',
  anton: 'Антон Б.',
  robert: 'Робберт Б.',
  kirill: 'Кирилл М.',
}

const SOURCE_LABELS = {
  site: 'Сайт',
  avito: 'Авито',
  ads: 'Реклама',
  other: 'Прочее',
  questions: 'Ответы на вопросы',
  spam: 'СПАМ',
}

const TYPE_LABELS = { target: 'Целевой', not_target: 'Нецелевой' }

const STATUS_META = {
  accepted: { label: 'Принято', cls: 'info' },
  in_work: { label: 'В работе', cls: 'warning' },
  done: { label: 'Выполнен', cls: 'active' },
  refused: { label: 'Отказ', cls: 'danger' },
}

function money(value) {
  const number = Number(value) || 0
  return number.toLocaleString('ru-RU') + ' ₽'
}

export default {
  subtitle: () => 'Входящие обращения по телефону',
  async render(ctx) {
    const options = await api('/api/calls/options')
    const canCreate = options.canCreate
    const multiStore = options.visibleStores.length > 1

    const q = ctx.query.get('q') ?? ''
    const period = ctx.query.get('period') ?? 'today'
    const status = ctx.query.get('status') ?? 'all'
    const store = ctx.query.get('store') ?? 'all'
    const source = ctx.query.get('source') ?? 'all'

    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Звонки</h2><div class="hint" id="calls-hint">Загружаем…</div></div>
        <div class="actions">
          ${canCreate ? `<button class="btn btn-primary" data-act="new">${icon('phone', 16)} Новый звонок</button>` : ''}
        </div>
      </div>

      <div class="toolbar">
        <div class="search" style="width:240px">${icon('search', 15)}
          <input id="q" type="search" placeholder="Клиент, телефон, заказ 1С…" value="${esc(q)}" />
        </div>
        <select class="select" id="period" style="width:auto;min-width:150px">
          <option value="today" ${period === 'today' ? 'selected' : ''}>Сегодня</option>
          <option value="week" ${period === 'week' ? 'selected' : ''}>За неделю</option>
          <option value="all" ${period === 'all' ? 'selected' : ''}>Все</option>
        </select>
        <select class="select" id="status" style="width:auto;min-width:150px">
          <option value="all">Все статусы</option>
          ${options.statuses.map((value) => `<option value="${value}" ${status === value ? 'selected' : ''}>${STATUS_META[value].label}</option>`).join('')}
        </select>
        ${multiStore ? `<select class="select" id="store" style="width:auto;min-width:170px">
          <option value="all">Все магазины</option>
          ${options.visibleStores.map((value) => `<option value="${value}" ${store === value ? 'selected' : ''}>${STORE_LABELS[value]}</option>`).join('')}
        </select>` : ''}
        <select class="select" id="source" style="width:auto;min-width:170px">
          <option value="all">Все источники</option>
          ${options.sources.map((value) => `<option value="${value}" ${source === value ? 'selected' : ''}>${SOURCE_LABELS[value]}</option>`).join('')}
        </select>
        <div class="spacer"></div>
      </div>

      <div id="stats" class="row wrap" style="gap:8px;margin-bottom:12px"></div>

      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr>
              <th style="width:120px">Когда</th>
              <th>Клиент</th>
              <th>Телефон</th>
              <th>Тип</th>
              <th>Источник</th>
              <th>Магазин</th>
              <th>Принял</th>
              <th>Заказ 1С</th>
              <th class="num">Цена</th>
              <th>Статус</th>
              <th style="width:80px"></th>
            </tr></thead>
            <tbody id="rows"></tbody>
          </table>
        </div>
      </div>`

    const reload = (changes) => {
      const params = new URLSearchParams()
      const next = { q, period, status, store, source, ...changes }
      if (next.q) params.set('q', next.q)
      if (next.period && next.period !== 'today') params.set('period', next.period)
      if (next.status && next.status !== 'all') params.set('status', next.status)
      if (next.store && next.store !== 'all') params.set('store', next.store)
      if (next.source && next.source !== 'all') params.set('source', next.source)
      ctx.navigate(`/calls${params.toString() ? `?${params.toString()}` : ''}`)
    }

    let timer = null
    ctx.root.querySelector('#q').addEventListener('input', (event) => {
      clearTimeout(timer)
      const value = event.target.value.trim()
      timer = setTimeout(() => reload({ q: value }), 350)
    })
    ctx.root.querySelector('#period').addEventListener('change', (event) => reload({ period: event.target.value }))
    ctx.root.querySelector('#status').addEventListener('change', (event) => reload({ status: event.target.value }))
    ctx.root.querySelector('#store')?.addEventListener('change', (event) => reload({ store: event.target.value }))
    ctx.root.querySelector('#source').addEventListener('change', (event) => reload({ source: event.target.value }))

    const openForm = async (call) => {
      await formModal({
        title: call ? 'Редактировать звонок' : 'Новый звонок',
        sub: call ? call.phone : 'Кто принял звонок, по какому магазину и что заказали',
        wide: true,
        submitLabel: call ? 'Сохранить' : 'Сохранить звонок',
        fields: [
          { name: 'clientName', label: 'Ф.И.О. клиента', value: call?.client_name },
          { name: 'phone', label: 'Номер телефона', required: true, value: call?.phone, placeholder: '+7 900 000-00-00' },
          { name: 'callType', label: 'Тип звонка', type: 'select',
            options: Object.entries(TYPE_LABELS).map(([value, label]) => ({ value, label })),
            value: call?.call_type ?? 'target' },
          { name: 'source', label: 'Источник', type: 'select',
            options: Object.entries(SOURCE_LABELS).map(([value, label]) => ({ value, label })),
            value: call?.source ?? 'site' },
          { name: 'store', label: 'Магазин', type: 'select',
            options: Object.entries(STORE_LABELS).map(([value, label]) => ({ value, label })),
            value: call?.store ?? (multiStore ? '' : options.visibleStores[0]) },
          { name: 'operator', label: 'Кто принял звонок', type: 'select',
            options: Object.entries(OPERATOR_LABELS).map(([value, label]) => ({ value, label })),
            value: call?.operator ?? 'andrey' },
          { name: 'status', label: 'Статус', type: 'select',
            options: Object.entries(STATUS_META).map(([value, meta]) => ({ value, label: meta.label })),
            value: call?.status ?? 'accepted' },
          { name: 'calledAt', label: 'Дата и время', type: 'datetime-local',
            value: toInputDateTime(call?.called_at ?? new Date().toISOString()) },
          { name: 'order1c', label: 'Заказ 1С', value: call?.order_1c, placeholder: 'Номер заказа' },
          { name: 'orderPrice', label: 'Цена заказа, ₽', type: 'number', value: call?.order_price ?? 0 },
          { name: 'comment', label: 'Комментарий', type: 'textarea', span: 2, rows: 3, value: call?.comment },
        ],
        submit: async (values) => {
          const payload = {
            phone: values.phone,
            clientName: values.clientName,
            callType: values.callType,
            source: values.source,
            store: values.store,
            operator: values.operator,
            status: values.status,
            order1c: values.order1c,
            orderPrice: Number(values.orderPrice ?? 0),
            comment: values.comment,
            calledAt: fromInputDateTime(values.calledAt),
          }
          if (call) await api(`/api/calls/${call.id}`, { method: 'PATCH', body: payload })
          else await api('/api/calls', { method: 'POST', body: payload })
          toast(call ? 'Звонок обновлён' : 'Звонок сохранён')
          ctx.refresh()
        },
      })
    }

    ctx.root.querySelectorAll('[data-act="new"]').forEach((button) => {
      button.addEventListener('click', () => openForm(null))
    })

    const params = new URLSearchParams({ period })
    if (q) params.set('q', q)
    if (status !== 'all') params.set('status', status)
    if (store !== 'all') params.set('store', store)
    if (source !== 'all') params.set('source', source)

    const data = await api(`/api/calls?${params.toString()}`)
    const { stats } = data

    ctx.root.querySelector('#calls-hint').textContent = multiStore
      ? `Видно все звонки: ${stats.total} за период`
      : `Звонки магазина ${STORE_LABELS[options.visibleStores[0]] ?? ''}: ${stats.total} за период`

    ctx.root.querySelector('#stats').innerHTML = `
      <span class="pill info plain">принято: <b class="mono">${stats.accepted}</b></span>
      <span class="pill warning plain">в работе: <b class="mono">${stats.inWork}</b></span>
      <span class="pill active plain">выполнено: <b class="mono">${stats.done}</b> · ${money(stats.revenue)}</span>
      <span class="pill danger plain">отказ: <b class="mono">${stats.refused}</b></span>
      <span class="pill plain">всего за период: <b class="mono">${stats.total}</b></span>`

    const rows = ctx.root.querySelector('#rows')
    if (data.items.length === 0) {
      rows.innerHTML = `<tr><td colspan="11">${emptyState({
        iconName: 'phone',
        title: q || status !== 'all' ? 'Ничего не найдено' : 'Звонков пока нет',
        text: q || status !== 'all'
          ? 'Измените фильтры или период.'
          : (canCreate ? 'Нажмите «Новый звонок», заполните карточку и выберите магазин.' : 'Звонки вашего магазина появятся здесь.'),
        action: canCreate && !q ? `<button class="btn btn-primary" data-act="new">${icon('phone', 16)} Новый звонок</button>` : '',
      })}</td></tr>`
      rows.querySelector('[data-act="new"]')?.addEventListener('click', () => openForm(null))
      return
    }

    rows.innerHTML = data.items.map((call) => {
      const meta = STATUS_META[call.status] ?? STATUS_META.accepted
      return `<tr data-id="${call.id}" class="row-${call.status.replace('_', '-')}" style="cursor:pointer" title="Двойной клик — открыть карточку звонка">
        <td class="small nowrap">
          <div>${fmtDate(call.called_at)}</div>
          <div class="muted" style="font-size:11.5px">${relTime(call.called_at)}</div>
        </td>
        <td class="small">${call.client_name ? esc(call.client_name) : '<span class="muted">—</span>'}</td>
        <td class="small nowrap"><a href="tel:${esc(call.phone)}">${esc(call.phone)}</a></td>
        <td><span class="pill ${call.call_type === 'target' ? 'active' : 'archived'}">${esc(TYPE_LABELS[call.call_type] ?? call.call_type)}</span></td>
        <td class="small">${esc(SOURCE_LABELS[call.source] ?? call.source)}</td>
        <td class="small nowrap">${options.canCreate
          ? `<button class="link" style="border:0;background:none;padding:0;font:inherit;cursor:pointer" data-store-for="${call.id}" title="Нажмите, чтобы сменить магазин">${esc(STORE_LABELS[call.store] ?? call.store)}</button>`
          : esc(STORE_LABELS[call.store] ?? call.store)}</td>
        <td class="small nowrap">${esc(OPERATOR_LABELS[call.operator] ?? call.operator)}</td>
        <td class="small">${call.order_1c ? esc(call.order_1c) : '<span class="muted">—</span>'}</td>
        <td class="num mono">${call.order_price ? money(call.order_price) : '—'}</td>
        <td><button class="pill ${meta.cls}" data-status-for="${call.id}" style="border:0;cursor:pointer" title="Нажмите, чтобы сменить статус">${esc(meta.label)}</button></td>
        <td>
          <div class="row" style="gap:2px">
            <button class="icon-btn" style="width:28px;height:28px" data-edit="${call.id}" title="Открыть">${icon('edit', 14)}</button>
            ${options.canCreate ? `<button class="icon-btn" style="width:28px;height:28px" data-del="${call.id}" title="Удалить">${icon('trash', 14)}</button>` : ''}
          </div>
        </td>
      </tr>`
    }).join('')

    rows.querySelectorAll('[data-status-for]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation()
        const call = data.items.find((item) => String(item.id) === button.dataset.statusFor)
        dropdown(button, Object.entries(STATUS_META).map(([value, meta]) => ({
          label: meta.label,
          icon: value === call.status ? 'check' : undefined,
          onClick: async () => {
            if (value === call.status) return
            try {
              await api(`/api/calls/${call.id}`, { method: 'PATCH', body: { status: value } })
              toast(`Статус: ${meta.label}`)
              ctx.refresh()
            } catch (error) {
              toast(error.message, 'error')
            }
          },
        })))
      })
    })

    rows.querySelectorAll('[data-store-for]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation()
        const call = data.items.find((item) => String(item.id) === button.dataset.storeFor)
        dropdown(button, Object.entries(STORE_LABELS).map(([value, label]) => ({
          label,
          icon: value === call.store ? 'check' : undefined,
          onClick: async () => {
            if (value === call.store) return
            try {
              await api(`/api/calls/${call.id}`, { method: 'PATCH', body: { store: value } })
              toast(`Магазин: ${label}`)
              ctx.refresh()
            } catch (error) {
              toast(error.message, 'error')
            }
          },
        })))
      })
    })

    rows.querySelectorAll('tr[data-id]').forEach((row) => {
      row.addEventListener('dblclick', (event) => {
        if (event.target.closest('button') || event.target.closest('a')) return
        const call = data.items.find((item) => String(item.id) === row.dataset.id)
        if (call) openForm(call)
      })
    })

    rows.querySelectorAll('[data-edit]').forEach((button) => {
      button.addEventListener('click', () => {
        const call = data.items.find((item) => String(item.id) === button.dataset.edit)
        openForm(call)
      })
    })
    rows.querySelectorAll('[data-del]').forEach((button) => {
      button.addEventListener('click', async () => {
        const call = data.items.find((item) => String(item.id) === button.dataset.del)
        if (!await confirmDialog({ title: 'Удалить звонок?', message: `Звонок ${call.phone} будет удалён.` })) return
        await api(`/api/calls/${call.id}`, { method: 'DELETE' })
        toast('Звонок удалён')
        ctx.refresh()
      })
    })
  },
}
