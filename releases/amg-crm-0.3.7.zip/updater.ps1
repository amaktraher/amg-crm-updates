param(
  [Parameter(Mandatory = $true)][string]$Zip,
  [Parameter(Mandatory = $true)][string]$Target,
  [Parameter(Mandatory = $true)][string]$Exe
)

$ErrorActionPreference = 'SilentlyContinue'
$log = Join-Path $env:TEMP 'AMG-CRM-update.log'
function Log([string]$message) {
  Add-Content -Path $log -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $message)
}

Log "start: zip=$Zip target=$Target"
Log "zip size: $((Get-Item $Zip).Length) bytes"

# 1. Stop the running app and its server
Get-Process AMG-CRM -ErrorAction SilentlyContinue | ForEach-Object { $_.Kill(); $_.WaitForExit(5000) }
Get-CimInstance Win32_Process -Filter "Name='node.exe'" |
  Where-Object { $_.CommandLine -and $_.CommandLine -like "*$Target*" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep -Seconds 2
Log "processes stopped"

# 2. Unpack into a temporary folder
$staging = Join-Path $env:TEMP ('amg-update-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $staging | Out-Null
Expand-Archive -LiteralPath $Zip -DestinationPath $staging -Force
if (-not (Test-Path (Join-Path $staging 'server\index.js'))) {
  Log "ERROR: archive has no server/index.js"
  exit 1
}
Log "unpacked to $staging"

# 3. Replace program folders and files (data folder is untouched)
foreach ($folder in @('server', 'public')) {
  $source = Join-Path $staging $folder
  $destination = Join-Path $Target $folder
  if (Test-Path $source) {
    if (Test-Path $destination) { Remove-Item $destination -Recurse -Force }
    Copy-Item $source $destination -Recurse -Force
  }
}
Get-ChildItem $staging -File | ForEach-Object {
  Copy-Item $_.FullName (Join-Path $Target $_.Name) -Force
}
Log "files copied"

# 3.1 Update the installed version in Apps & Features
$versionFile = Join-Path $Target 'VERSION'
if (Test-Path $versionFile) {
  $newVersion = (Get-Content $versionFile -Raw).Trim()
  $uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AMG-CRM'
  if (Test-Path $uninstallKey) { Set-ItemProperty -Path $uninstallKey -Name 'DisplayVersion' -Value $newVersion }
}

# 4. Cleanup and restart
Remove-Item $staging -Recurse -Force
Remove-Item $Zip -Force
Start-Process -FilePath $Exe
Log "restarted $Exe"
