/* Авито: карточки клиентов из чатов. */
import {
  api, avatar, emptyState, esc, icon, relTime, state, toast,
} from '../lib.js'
import { openCompanyForm, loadUsers } from './forms.js'

const STATUS = {
  new: { label: 'Новый', cls: 'info' },
  chat: { label: 'В переписке', cls: 'warning' },
  deal: { label: 'Договорились', cls: 'active' },
  archive: { label: 'Архив', cls: 'archived' },
}

export default {
  subtitle: () => 'Карточки клиентов из чатов Авито',
  async render(ctx) {
    const q = ctx.query.get('q') ?? ''
    const status = ctx.query.get('status') ?? 'all'
    const canWrite = state.permissions?.write

    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Авито</h2><div class="hint" id="avito-count">Загружаем…</div></div>
        <div class="actions">
          ${canWrite ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Новая карточка</button>` : ''}
        </div>
      </div>

      <div class="toolbar">
        <div class="search" style="width:280px">${icon('search', 15)}
          <input id="q" type="search" placeholder="Клиент, телефон, товар, сообщение…" value="${esc(q)}" />
        </div>
        <select class="select" id="status" style="width:auto;min-width:170px">
          <option value="all">Все статусы</option>
          ${Object.entries(STATUS).map(([value, meta]) =>
    `<option value="${value}" ${status === value ? 'selected' : ''}>${esc(meta.label)}</option>`).join('')}
        </select>
        <div class="spacer"></div>
      </div>

      <div id="cards"></div>`

    const cards = ctx.root.querySelector('#cards')

    const reload = (changes) => {
      const params = new URLSearchParams()
      const next = { q, status, ...changes }
      if (next.q) params.set('q', next.q)
      if (next.status && next.status !== 'all') params.set('status', next.status)
      ctx.navigate(`/avito${params.toString() ? `?${params.toString()}` : ''}`)
    }

    let timer = null
    ctx.root.querySelector('#q').addEventListener('input', (event) => {
      clearTimeout(timer)
      const value = event.target.value.trim()
      timer = setTimeout(() => reload({ q: value }), 350)
    })
    ctx.root.querySelector('#status').addEventListener('change', (event) => reload({ status: event.target.value }))

    const openForm = async (card) => {
      const users = await loadUsers()
      const { formModal } = await import('../lib.js')
      await formModal({
        title: card ? 'Редактировать карточку' : 'Новая карточка Авито',
        sub: 'Данные из чата: клиент, товар, последнее сообщение',
        wide: true,
        submitLabel: card ? 'Сохранить' : 'Создать',
        fields: [
          { name: 'clientName', label: 'Клиент', required: true, value: card?.client_name },
          { name: 'phone', label: 'Телефон', value: card?.phone },
          { name: 'item', label: 'Товар / объявление', span: 2, value: card?.item },
          { name: 'status', label: 'Статус', type: 'select',
            options: Object.entries(STATUS).map(([value, meta]) => ({ value, label: meta.label })),
            value: card?.status ?? 'new' },
          { name: 'ownerId', label: 'Ответственный', type: 'select',
            options: [{ value: '', label: 'Не назначен' }, ...users.filter((u) => u.isActive).map((u) => ({ value: u.id, label: u.name }))],
            value: card?.owner_id ?? state.user.id },
          { name: 'message', label: 'Сообщение', type: 'textarea', span: 2, rows: 4, value: card?.message },
        ],
        submit: async (values) => {
          const payload = { ...values, ownerId: values.ownerId ? Number(values.ownerId) : null }
          if (card) await api(`/api/avito/${card.id}`, { method: 'PATCH', body: payload })
          else await api('/api/avito', { method: 'POST', body: payload })
          toast(card ? 'Карточка обновлена' : 'Карточка создана')
          ctx.refresh()
        },
      })
    }

    ctx.root.querySelectorAll('[data-act="new"]').forEach((button) => {
      button.addEventListener('click', () => openForm(null))
    })

    const data = await api(`/api/avito?${new URLSearchParams({ ...(q ? { q } : {}), ...(status !== 'all' ? { status } : {}) }).toString()}`)
    ctx.root.querySelector('#avito-count').textContent =
      `${data.items.length} ${data.items.length === 1 ? 'карточка' : 'карточек'}`

    if (data.items.length === 0) {
      cards.innerHTML = `<div class="card">${emptyState({
        iconName: 'message',
        title: q || status !== 'all' ? 'Ничего не найдено' : 'Карточек пока нет',
        text: q || status !== 'all'
          ? 'Измените запрос или сбросьте фильтр.'
          : 'Добавьте карточку из чата Авито — клиент, товар и последнее сообщение.',
        action: canWrite && !q ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Новая карточка</button>` : '',
      })}</div>`
      cards.querySelector('[data-act="new"]')?.addEventListener('click', () => openForm(null))
      return
    }

    cards.innerHTML = `<div class="grid-3">${data.items.map((card) => {
      const meta = STATUS[card.status] ?? STATUS.new
      return `<div class="card card-pad" data-card="${card.id}" title="Двойной клик — открыть карточку" style="display:flex;flex-direction:column;gap:10px">
        <div class="row" style="gap:10px">
          ${avatar(card.client_name)}
          <div class="col" style="min-width:0">
            <div class="t" style="font-size:14px">${esc(card.client_name)}</div>
            <div class="s">${card.phone ? esc(card.phone) : 'телефон не указан'}</div>
          </div>
          <span class="pill ${meta.cls}" style="margin-left:auto">${esc(meta.label)}</span>
        </div>
        ${card.item ? `<div class="small" style="color:var(--text-2)">${icon('briefcase', 13)} ${esc(card.item)}</div>` : ''}
        <div class="small muted clamp-2" style="min-height:34px">${card.message ? esc(card.message) : 'Нет сообщения'}</div>
        <div class="row small muted" style="gap:10px;margin-top:auto">
          <span>${relTime(card.updated_at)}</span>
          ${card.company_name ? `<span class="pill plain active">клиент: ${esc(card.company_name)}</span>` : ''}
          <span class="spacer"></span>
          ${canWrite ? `<button class="icon-btn" style="width:28px;height:28px" data-edit="${card.id}" title="Изменить">${icon('edit', 14)}</button>` : ''}
          ${canWrite ? `<button class="icon-btn" style="width:28px;height:28px" data-del="${card.id}" title="Удалить">${icon('trash', 14)}</button>` : ''}
        </div>
        ${canWrite && !card.company_id ? `<button class="btn btn-sm" data-convert="${card.id}">${icon('building', 14)} Создать клиента</button>` : ''}
        ${card.company_id ? `<button class="btn btn-sm" data-open="${card.company_id}">${icon('chevronRight', 14)} Открыть клиента</button>` : ''}
      </div>`
    }).join('')}</div>`

    cards.querySelectorAll('[data-card]').forEach((node) => {
      node.addEventListener('dblclick', (event) => {
        if (event.target.closest('button') || event.target.closest('a')) return
        const card = data.items.find((item) => String(item.id) === node.dataset.card)
        if (card) openForm(card)
      })
    })

    cards.querySelectorAll('[data-edit]').forEach((button) => {
      button.addEventListener('click', () => {
        const card = data.items.find((item) => String(item.id) === button.dataset.edit)
        openForm(card)
      })
    })
    cards.querySelectorAll('[data-del]').forEach((button) => {
      button.addEventListener('click', async () => {
        const card = data.items.find((item) => String(item.id) === button.dataset.del)
        const { confirmDialog } = await import('../lib.js')
        if (!await confirmDialog({ title: 'Удалить карточку?', message: `Карточка «${card.client_name}» будет удалена.` })) return
        await api(`/api/avito/${card.id}`, { method: 'DELETE' })
        toast('Карточка удалена')
        ctx.refresh()
      })
    })
    cards.querySelectorAll('[data-convert]').forEach((button) => {
      button.addEventListener('click', async () => {
        const card = data.items.find((item) => String(item.id) === button.dataset.convert)
        try {
          await api(`/api/avito/${card.id}/convert`, { method: 'POST' })
          toast(`Клиент «${card.client_name}» создан`)
          ctx.refresh()
        } catch (error) {
          toast(error.message, 'error')
        }
      })
    })
    cards.querySelectorAll('[data-open]').forEach((button) => {
      button.addEventListener('click', () => ctx.navigate(`/companies/${button.dataset.open}`))
    })
  },
}
