/* Обзор: сводка по клиентам, задачам и активности команды. */
import {
  ACTIVITY_KIND, api, avatar, dueMeta, esc, fmtDateTime, icon, plural, relTime, state, toast,
} from '../lib.js'
import { openCompanyForm, openTaskForm } from './forms.js'

function greeting() {
  const hour = new Date().getHours()
  if (hour < 5) return 'Доброй ночи'
  if (hour < 12) return 'Доброе утро'
  if (hour < 18) return 'Добрый день'
  return 'Добрый вечер'
}

function chart(days) {
  const max = Math.max(1, ...days.map((d) => d.count))
  return `<div class="bar-chart">
    ${days.map((day) => {
    const height = Math.round((day.count / max) * 100)
    const label = new Date(day.date).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })
    const style = day.count === 0 ? 'height:3px' : `height:${Math.max(6, height)}%`
    return `<div class="bar ${day.count === 0 ? 'zero' : ''}" style="${style}" title="${label}: ${day.count} событий"></div>`
  }).join('')}
  </div>`
}

export default {
  subtitle: () => 'Сводка на сегодня',
  async render(ctx) {
    const data = await api('/api/dashboard')
    const { companies, tasks, team } = data
    const active = (companies.byStatus.active ?? 0) + (companies.byStatus.vip ?? 0)
    const firstName = state.user.name.split(' ')[0]

    ctx.root.innerHTML = `
      <div class="page-head">
        <div>
          <h2>${greeting()}, ${esc(firstName)}</h2>
          <div class="hint">${tasks.overdue > 0
    ? `Просрочено задач: ${tasks.overdue}. Стоит заняться ими в первую очередь.`
    : 'Просроченных задач нет — отличный день.'}</div>
        </div>
        <div class="actions">
          <button class="btn" data-act="new-company">${icon('building', 16)} Клиент</button>
          <button class="btn btn-primary" data-act="new-task">${icon('plus', 16)} Новая задача</button>
        </div>
      </div>

      <div class="kpi-grid">
        <div class="kpi">
          <div class="glyph">${icon('building', 18)}</div>
          <div class="label">Клиенты</div>
          <div class="value">${companies.total}</div>
          <div class="foot"><span class="badge-dot"></span>${active} активных · ${companies.byStatus.lead ?? 0} ${plural(companies.byStatus.lead ?? 0, ['лид', 'лида', 'лидов'])}</div>
        </div>
        <div class="kpi violet">
          <div class="glyph">${icon('kanban', 18)}</div>
          <div class="label">Задачи в работе</div>
          <div class="value">${tasks.open}</div>
          <div class="foot">${icon('clock', 13)} сегодня к сроку: ${tasks.dueToday}</div>
        </div>
        <div class="kpi ${tasks.overdue > 0 ? 'danger' : 'success'}">
          <div class="glyph">${icon(tasks.overdue > 0 ? 'alert' : 'check', 18)}</div>
          <div class="label">Просрочено</div>
          <div class="value">${tasks.overdue}</div>
          <div class="foot">${tasks.overdue > 0 ? 'требуют внимания' : 'всё под контролем'}</div>
        </div>
        <div class="kpi success">
          <div class="glyph">${icon('trend', 18)}</div>
          <div class="label">Выполнено за неделю</div>
          <div class="value">${tasks.doneWeek}</div>
          <div class="foot">сегодня закрыто: ${tasks.doneToday}</div>
        </div>
      </div>

      <div class="grid-2">
        <div class="card">
          <div class="card-head">
            <h3>Ближайшие задачи</h3>
            <div class="actions">
              <button class="btn btn-sm btn-ghost" data-act="all-tasks">Все задачи ${icon('chevronRight', 14)}</button>
            </div>
          </div>
          <div class="card-pad" style="padding-top:6px">
            ${data.upcoming.length === 0
    ? `<div class="empty" style="padding:26px 10px">
                  <div class="icon">${icon('check', 22)}</div>
                  <h4>Запланированных задач нет</h4>
                  <p>Создайте задачу со сроком — она появится здесь.</p>
                </div>`
    : `<div class="list">${data.upcoming.map((task) => {
      const due = dueMeta(task.due_at, task.status)
      return `<div class="list-row" data-task="${task.id}" style="cursor:pointer">
                    <span class="pill ${task.priority === 'high' ? 'danger' : task.priority === 'low' ? '' : 'info'} plain"
                      style="min-width:64px;justify-content:center">${task.priority === 'high' ? 'важно' : task.priority === 'low' ? 'низкий' : 'обычно'}</span>
                    <div class="grow">
                      <div class="t truncate" style="font-size:13.5px;font-weight:550">${esc(task.title)}</div>
                      <div class="s small muted truncate">${task.company_name ? esc(task.company_name) : 'Без клиента'}
                        ${task.assignee_name ? `· ${esc(task.assignee_name)}` : ''}</div>
                    </div>
                    <span class="due ${due.cls} small nowrap">${icon('clock', 13)} ${esc(due.text)}</span>
                  </div>`
    }).join('')}</div>`}
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Активность</h3><span class="small muted" style="margin-left:auto">14 дней</span></div>
          <div class="card-pad">
            ${chart(data.activityByDay)}
            <div class="row small muted" style="justify-content:space-between;margin-top:8px">
              <span>${new Date(data.activityByDay[0].date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}</span>
              <span>сегодня</span>
            </div>
            <div class="divider" style="margin:16px 0"></div>
            <div class="row small" style="justify-content:space-between">
              <span class="muted">Событий за 14 дней</span>
              <b class="mono">${data.activityByDay.reduce((sum, d) => sum + d.count, 0)}</b>
            </div>
          </div>
        </div>
      </div>

      <div class="grid-2" style="margin-top:16px">
        <div class="card">
          <div class="card-head"><h3>Последние события</h3></div>
          <div class="card-pad">
            ${data.recent.length === 0
    ? `<div class="empty" style="padding:20px"><p>Пока нет событий</p></div>`
    : `<div class="timeline">${data.recent.map((item) => {
      const kind = ACTIVITY_KIND[item.kind] ?? ACTIVITY_KIND.note
      return `<div class="timeline-item">
                    <span class="timeline-icon ${kind.cls}">${icon(kind.icon, 14)}</span>
                    <div class="timeline-body">
                      <div class="text">${esc(item.body)}</div>
                      <div class="meta">
                        <span>${esc(item.user_name ?? 'Система')}</span>
                        <span>·</span>
                        <span>${relTime(item.created_at)}</span>
                        ${item.entity_label ? `<span>·</span><span class="link" data-company="${item.entity_type === 'company' ? item.entity_id : ''}">${esc(item.entity_label)}</span>` : ''}
                      </div>
                    </div>
                  </div>`
    }).join('')}</div>`}
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3>Загрузка команды</h3>
            ${state.permissions?.manageUsers
    ? `<button class="btn btn-sm btn-ghost" style="margin-left:auto" data-act="team">Команда ${icon('chevronRight', 14)}</button>`
    : ''}
          </div>
          <div class="card-pad">
            <div class="list">
              ${team.map((member) => `<div class="list-row">
                ${avatar(member.name, { size: 'sm' })}
                <div class="grow">
                  <div class="t" style="font-size:13.5px">${esc(member.name)}</div>
                  <div class="s muted small">${member.overdue_tasks > 0
    ? `<span style="color:var(--danger)">${member.overdue_tasks} просрочено</span>`
    : 'нет просрочек'}</div>
                </div>
                <span class="pill plain ${member.open_tasks > 5 ? 'info' : ''}">${member.open_tasks} ${plural(member.open_tasks, ['задача', 'задачи', 'задач'])}</span>
              </div>`).join('')}
            </div>
          </div>
        </div>
      </div>`

    ctx.root.querySelector('[data-act="new-company"]').addEventListener('click', () => openCompanyForm(null, ctx.refresh))
    ctx.root.querySelector('[data-act="new-task"]').addEventListener('click', () => openTaskForm(null, ctx.refresh))
    ctx.root.querySelector('[data-act="all-tasks"]').addEventListener('click', () => ctx.navigate('/tasks'))
    ctx.root.querySelector('[data-act="team"]')?.addEventListener('click', () => ctx.navigate('/team'))

    ctx.root.querySelectorAll('[data-task]').forEach((row) => {
      row.addEventListener('click', () => ctx.navigate(`/tasks?task=${row.dataset.task}`))
    })
    ctx.root.querySelectorAll('[data-company]').forEach((node) => {
      node.addEventListener('click', () => {
        const id = node.dataset.company
        if (id) ctx.navigate(`/companies/${id}`)
      })
    })
  },
}
