import { db } from '../db.js'
import { requireUser } from '../auth.js'

const startOfToday = () => {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d.toISOString()
}

const startOfTomorrow = () => {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  d.setDate(d.getDate() + 1)
  return d.toISOString()
}

export function registerDashboardRoutes(router) {
  router.get('/api/dashboard', async ({ user }) => {
    requireUser({ user })
    const now = new Date().toISOString()
    const today = startOfToday()
    const tomorrow = startOfTomorrow()
    const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString()
    const twoWeeksAgo = new Date(Date.now() - 13 * 86400000)
    twoWeeksAgo.setHours(0, 0, 0, 0)

    const companyStatuses = Object.fromEntries(
      db.prepare('SELECT status, COUNT(*) AS c FROM companies GROUP BY status').all().map((r) => [r.status, r.c]),
    )
    const companiesTotal = Object.values(companyStatuses).reduce((a, b) => a + b, 0)
    const contactsTotal = db.prepare('SELECT COUNT(*) AS c FROM contacts').get().c

    const tasks = db.prepare(`SELECT
        SUM(CASE WHEN status != 'done' THEN 1 ELSE 0 END) AS open,
        SUM(CASE WHEN status != 'done' AND due_at IS NOT NULL AND due_at < ? THEN 1 ELSE 0 END) AS today_open,
        SUM(CASE WHEN status != 'done' AND due_at IS NOT NULL AND due_at < ? THEN 1 ELSE 0 END) AS overdue,
        SUM(CASE WHEN status != 'done' AND due_at >= ? AND due_at < ? THEN 1 ELSE 0 END) AS due_today,
        SUM(CASE WHEN status = 'done' AND completed_at >= ? THEN 1 ELSE 0 END) AS done_today,
        SUM(CASE WHEN status = 'done' AND completed_at >= ? THEN 1 ELSE 0 END) AS done_week
      FROM tasks`).get(tomorrow, now, today, tomorrow, today, weekAgo)

    const rawDays = db.prepare(`SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS count
      FROM activities WHERE created_at >= ? GROUP BY day`).all(twoWeeksAgo.toISOString())
    const dayMap = Object.fromEntries(rawDays.map((r) => [r.day, r.count]))
    const activityByDay = []
    for (let i = 13; i >= 0; i -= 1) {
      const d = new Date()
      d.setHours(0, 0, 0, 0)
      d.setDate(d.getDate() - i)
      const key = d.toISOString().slice(0, 10)
      activityByDay.push({ date: key, count: dayMap[key] ?? 0 })
    }

    const upcoming = db.prepare(`SELECT t.*, c.name AS company_name, u.name AS assignee_name
      FROM tasks t LEFT JOIN companies c ON c.id = t.company_id
      LEFT JOIN users u ON u.id = t.assignee_id
      WHERE t.status != 'done' AND t.due_at IS NOT NULL
      ORDER BY t.due_at ASC LIMIT 6`).all()

    const recentRows = db.prepare(`SELECT a.*, u.name AS user_name FROM activities a
      LEFT JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC LIMIT 8`).all()
    const nameCache = { company: new Map(), contact: new Map(), task: new Map() }
    const recent = recentRows.map((row) => {
      const cache = nameCache[row.entity_type]
      let label = null
      if (cache) {
        if (!cache.has(row.entity_id)) {
          const table = row.entity_type === 'company' ? 'companies' : row.entity_type === 'contact' ? 'contacts' : 'tasks'
          const column = row.entity_type === 'task' ? 'title' : 'name'
          const found = row.entity_type === 'contact'
            ? db.prepare("SELECT first_name || ' ' || COALESCE(last_name, '') AS name FROM contacts WHERE id = ?").get(row.entity_id)
            : db.prepare(`SELECT ${column} AS name FROM ${table} WHERE id = ?`).get(row.entity_id)
          cache.set(row.entity_id, found?.name?.trim() ?? null)
        }
        label = cache.get(row.entity_id)
      }
      return { ...row, entity_label: label }
    })

    const team = db.prepare(`SELECT u.id, u.name, u.role,
        (SELECT COUNT(*) FROM tasks t WHERE t.assignee_id = u.id AND t.status != 'done') AS open_tasks,
        (SELECT COUNT(*) FROM tasks t WHERE t.assignee_id = u.id AND t.status != 'done'
          AND t.due_at IS NOT NULL AND t.due_at < ?) AS overdue_tasks
      FROM users u WHERE u.is_active = 1 ORDER BY open_tasks DESC, u.name`).all(now)

    return {
      companies: { total: companiesTotal, byStatus: companyStatuses },
      contacts: { total: contactsTotal },
      tasks: {
        open: tasks.open ?? 0,
        overdue: tasks.overdue ?? 0,
        dueToday: tasks.due_today ?? 0,
      todayOpen: tasks.today_open ?? 0,
        doneToday: tasks.done_today ?? 0,
        doneWeek: tasks.done_week ?? 0,
      },
      activityByDay,
      upcoming,
      recent,
      team,
    }
  })
}
