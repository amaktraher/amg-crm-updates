import { db } from '../db.js'
import { audit } from '../audit.js'
import { requirePermission, requireUser } from '../auth.js'
import { HttpError } from '../http.js'
import { idOf, isoOrNull, oneOf, optionalText, text } from '../validate.js'

/** Магазины, которые принимают и получают звонки. */
export const STORES = ['pargolovo', 'dunaysky-27k1', 'pushkino', 'krasnodar', 'kaliningrad-1', 'kaliningrad-2']
export const CALL_CENTER = 'pargolovo'

const CALL_TYPES = ['target', 'not_target']
const SOURCES = ['site', 'avito', 'ads', 'other', 'questions', 'spam']
const OPERATORS = ['andrey', 'anton', 'robert', 'kirill']
const STATUSES = ['accepted', 'in_work', 'done', 'refused']

/** Администратор и колл-центр (Парголово) видят все звонки. */
function seesAll(user) {
  return user.role === 'admin' || user.login === CALL_CENTER
}

/** Магазин видит только свои карточки звонков. */
function visibleStores(user) {
  if (seesAll(user)) return STORES.slice()
  return STORES.includes(user.login) ? [user.login] : []
}

const SELECT = `
  SELECT c.*, u.name AS creator_name
  FROM calls c
  LEFT JOIN users u ON u.id = c.created_by`

function statsFor(whereSql, params) {
  const row = db.prepare(`SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) AS accepted,
      SUM(CASE WHEN status = 'in_work' THEN 1 ELSE 0 END) AS in_work,
      SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) AS done,
      SUM(CASE WHEN status = 'refused' THEN 1 ELSE 0 END) AS refused,
      SUM(CASE WHEN status = 'done' THEN order_price ELSE 0 END) AS revenue
    FROM calls c ${whereSql}`).get(...params)
  return {
    total: row.total ?? 0,
    accepted: row.accepted ?? 0,
    inWork: row.in_work ?? 0,
    done: row.done ?? 0,
    refused: row.refused ?? 0,
    revenue: row.revenue ?? 0,
  }
}

export function registerCallRoutes(router) {
  router.get('/api/calls/options', async ({ user }) => {
    requireUser({ user })
    return {
      stores: STORES,
      operators: OPERATORS,
      sources: SOURCES,
      callTypes: CALL_TYPES,
      statuses: STATUSES,
      canCreate: seesAll(user),
      visibleStores: visibleStores(user),
    }
  })

  router.get('/api/calls', async ({ query, user }) => {
    requireUser({ user })
    const allowed = visibleStores(user)
    if (allowed.length === 0) {
      return { items: [], stats: statsFor('WHERE 0', []) }
    }

    const scope = []
    const scopeParams = []
    if (allowed.length < STORES.length) {
      scope.push(`c.store IN (${allowed.map(() => '?').join(',')})`)
      allowed.forEach((store) => scopeParams.push(store))
    }

    const where = scope.slice()
    const params = scopeParams.slice()
    const q = String(query.get('q') ?? '').trim()
    const status = query.get('status')
    const store = query.get('store')
    const source = query.get('source')
    const period = query.get('period') ?? 'today'

    if (period === 'today') {
      const start = new Date(); start.setHours(0, 0, 0, 0)
      const end = new Date(start); end.setDate(end.getDate() + 1)
      where.push('c.called_at >= ? AND c.called_at < ?')
      params.push(start.toISOString(), end.toISOString())
    } else if (period === 'week') {
      where.push('c.called_at >= ?')
      params.push(new Date(Date.now() - 7 * 86400000).toISOString())
    }
    if (status && STATUSES.includes(status)) { where.push('c.status = ?'); params.push(status) }
    if (store && allowed.includes(store)) { where.push('c.store = ?'); params.push(store) }
    if (source && SOURCES.includes(source)) { where.push('c.source = ?'); params.push(source) }
    if (q) {
      where.push('(c.phone LIKE ? OR c.client_name LIKE ? OR c.comment LIKE ? OR c.order_1c LIKE ?)')
      const like = `%${q}%`
      params.push(like, like, like, like)
    }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : ''
    const items = db.prepare(`${SELECT} ${whereSql} ORDER BY c.called_at DESC LIMIT 500`).all(...params)

    const statsWhere = scope.length ? `WHERE ${scope.join(' AND ')}` : ''
    return { items, stats: statsFor(statsWhere, scopeParams) }
  })

  router.post('/api/calls', async ({ body, user }) => {
    requireUser({ user })
    if (!seesAll(user)) {
      throw new HttpError(403, 'Звонки принимает колл-центр (Парголово) или администратор', 'FORBIDDEN')
    }
    const stamp = new Date().toISOString()
    const phone = text(body.phone, 'Телефон', { max: 60 })
    const data = {
      clientName: optionalText(body.clientName, 'Ф.И.О.', { max: 200 }),
      callType: oneOf(body.callType ?? 'target', CALL_TYPES, 'тип звонка'),
      source: oneOf(body.source ?? 'other', SOURCES, 'источник'),
      store: oneOf(body.store ?? CALL_CENTER, STORES, 'магазин'),
      operator: oneOf(body.operator ?? 'andrey', OPERATORS, 'кто принял'),
      comment: optionalText(body.comment, 'комментарий', { max: 4000 }),
      order1c: optionalText(body.order1c, 'заказ 1С', { max: 60 }),
      orderPrice: Math.max(0, Number(body.orderPrice ?? 0) || 0),
      status: oneOf(body.status ?? 'accepted', STATUSES, 'статус'),
      calledAt: isoOrNull(body.calledAt, 'дата звонка') ?? stamp,
    }
    const res = db.prepare(`INSERT INTO calls
      (phone, client_name, call_type, source, store, operator, comment, order_1c, order_price,
       status, called_at, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      phone, data.clientName, data.callType, data.source, data.store, data.operator,
      data.comment, data.order1c, data.orderPrice, data.status, data.calledAt, user.id, stamp, stamp,
    )
    const id = Number(res.lastInsertRowid)
    audit(user.id, 'create', 'call', id, { phone, store: data.store })
    return { item: db.prepare(`${SELECT} WHERE c.id = ?`).get(id) }
  })

  router.patch('/api/calls/:id', async ({ body, params, user }) => {
    requireUser({ user })
    const id = idOf(params.id)
    const existing = db.prepare('SELECT * FROM calls WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Звонок не найден', 'NOT_FOUND')
    const all = seesAll(user)
    if (!all && existing.store !== user.login) {
      throw new HttpError(403, 'Этот звонок принадлежит другому магазину', 'FORBIDDEN')
    }

    const data = {
      phone: body.phone === undefined || !all ? existing.phone : text(body.phone, 'Телефон', { max: 60 }),
      clientName: body.clientName === undefined ? existing.client_name : optionalText(body.clientName, 'Ф.И.О.', { max: 200 }),
      callType: body.callType === undefined || !all ? existing.call_type : oneOf(body.callType, CALL_TYPES, 'тип звонка'),
      source: body.source === undefined || !all ? existing.source : oneOf(body.source, SOURCES, 'источник'),
      store: body.store === undefined || !all ? existing.store : oneOf(body.store, STORES, 'магазин'),
      operator: body.operator === undefined || !all ? existing.operator : oneOf(body.operator, OPERATORS, 'кто принял'),
      comment: body.comment === undefined ? existing.comment : optionalText(body.comment, 'комментарий', { max: 4000 }),
      order1c: body.order1c === undefined ? existing.order_1c : optionalText(body.order1c, 'заказ 1С', { max: 60 }),
      orderPrice: body.orderPrice === undefined ? existing.order_price : Math.max(0, Number(body.orderPrice) || 0),
      status: body.status === undefined ? existing.status : oneOf(body.status, STATUSES, 'статус'),
    }
    db.prepare(`UPDATE calls SET phone = ?, client_name = ?, call_type = ?, source = ?, store = ?,
      operator = ?, comment = ?, order_1c = ?, order_price = ?, status = ?, updated_at = ? WHERE id = ?`).run(
      data.phone, data.clientName, data.callType, data.source, data.store, data.operator,
      data.comment, data.order1c, data.orderPrice, data.status, new Date().toISOString(), id,
    )
    audit(user.id, 'update', 'call', id, { status: data.status })
    return { item: db.prepare(`${SELECT} WHERE c.id = ?`).get(id) }
  })

  router.delete('/api/calls/:id', async ({ params, user }) => {
    requireUser({ user })
    if (!seesAll(user)) throw new HttpError(403, 'Удалять звонки может только администратор', 'FORBIDDEN')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT phone FROM calls WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Звонок не найден', 'NOT_FOUND')
    db.prepare('DELETE FROM calls WHERE id = ?').run(id)
    audit(user.id, 'delete', 'call', id, { phone: existing.phone })
    return { ok: true }
  })
}
