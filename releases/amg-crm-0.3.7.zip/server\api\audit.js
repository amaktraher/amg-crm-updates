import { db } from '../db.js'
import { requirePermission } from '../auth.js'
import { clampInt } from '../validate.js'

export function registerAuditRoutes(router) {
  router.get('/api/audit', async ({ query, user }) => {
    requirePermission({ user }, 'viewAudit')
    const page = clampInt(query.get('page'), { min: 1, max: 100000, fallback: 1 })
    const pageSize = clampInt(query.get('pageSize'), { min: 5, max: 200, fallback: 50 })
    const total = db.prepare('SELECT COUNT(*) AS c FROM audit_log').get().c
    const rows = db.prepare(`SELECT a.*, u.name AS actor_name, u.email AS actor_email
      FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id
      ORDER BY a.created_at DESC, a.id DESC LIMIT ? OFFSET ?`)
      .all(pageSize, (page - 1) * pageSize)
    return {
      items: rows.map((row) => ({
        ...row,
        meta: row.meta ? JSON.parse(row.meta) : null,
      })),
      total,
      page,
      pageSize,
    }
  })
}
