/* Постоянные клиенты: люди, которые возвращаются. */
import {
  api, avatar, emptyState, esc, icon, skeletonRows, state, toast,
} from '../lib.js'
import { loadCompanies, openContactForm } from './forms.js'

export default {
  subtitle: () => 'Люди из карточек постоянных клиентов',
  async render(ctx) {
    const q = ctx.query.get('q') ?? ''
    const companyId = ctx.query.get('companyId') ?? 'all'
    const canWrite = state.permissions?.write
    const companies = await loadCompanies()

    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Люди</h2><div class="hint" id="contacts-count">Загружаем…</div></div>
        <div class="actions">
          ${canWrite ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Новый контакт</button>` : ''}
        </div>
      </div>

      <div class="segmented" style="margin-bottom:14px">
        <button data-go="/companies">Клиенты</button>
        <button class="active">Люди</button>
      </div>

      <div class="toolbar">
        <div class="search" style="width:280px">${icon('search', 15)}
          <input id="q" type="search" placeholder="Имя, телефон, почта, должность…" value="${esc(q)}" />
        </div>
        <select class="select" id="company" style="width:auto;min-width:200px">
          <option value="all">Все клиенты</option>
          ${companies.map((company) => `<option value="${company.id}" ${String(companyId) === String(company.id) ? 'selected' : ''}>${esc(company.name)}</option>`).join('')}
        </select>
        <div class="spacer"></div>
      </div>

      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr>
              <th style="width:30%">Контакт</th>
              <th>Клиент</th>
              <th>Телефон</th>
              <th>E-mail</th>
              <th>Telegram</th>
              <th style="width:80px"></th>
            </tr></thead>
            <tbody id="rows">${skeletonRows(5)}</tbody>
          </table>
        </div>
      </div>`

    const reload = (changes) => {
      const params = new URLSearchParams()
      const next = { q: ctx.query.get('q') ?? '', companyId: ctx.query.get('companyId') ?? 'all', ...changes }
      if (next.q) params.set('q', next.q)
      if (next.companyId && next.companyId !== 'all') params.set('companyId', next.companyId)
      ctx.navigate(`/contacts${params.toString() ? `?${params.toString()}` : ''}`)
    }

    let timer = null
    ctx.root.querySelector('#q').addEventListener('input', (event) => {
      clearTimeout(timer)
      const value = event.target.value.trim()
      timer = setTimeout(() => reload({ q: value }), 350)
    })
    ctx.root.querySelector('#company').addEventListener('change', (event) => reload({ companyId: event.target.value }))
    ctx.root.querySelectorAll('[data-act="new"]').forEach((button) => {
      button.addEventListener('click', () => openContactForm(null, ctx.refresh, { companyId: companyId === 'all' ? '' : companyId }))
    })

    const params = new URLSearchParams()
    if (q) params.set('q', q)
    if (companyId !== 'all') params.set('companyId', companyId)
    const data = await api(`/api/contacts?${params.toString()}`)
    ctx.root.querySelectorAll('[data-go]').forEach((button) => {
      button.addEventListener('click', () => ctx.navigate(button.dataset.go))
    })

    const rows = ctx.root.querySelector('#rows')
    ctx.root.querySelector('#contacts-count').textContent = `${data.items.length} контактов в базе`

    if (data.items.length === 0) {
      rows.innerHTML = ''
      ctx.root.querySelector('.table-wrap').innerHTML = emptyState({
        iconName: 'users',
        title: q ? 'Ничего не найдено' : 'Контактов пока нет',
        text: q ? 'Измените запрос или сбросьте фильтр клиента.' : 'Добавьте контакт и привяжите его к клиенту.',
        action: canWrite && !q ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Добавить контакт</button>` : '',
      })
      ctx.root.querySelector('[data-act="new"]')?.addEventListener('click', () => openContactForm(null, ctx.refresh))
      return
    }

    rows.innerHTML = data.items.map((contact) => `
      <tr data-id="${contact.id}">
        <td>
          <div class="stack">
            ${avatar(`${contact.first_name} ${contact.last_name ?? ''}`)}
            <div class="col">
              <div class="t">${esc(contact.first_name)} ${esc(contact.last_name ?? '')}
                ${contact.is_primary ? '<span class="pill plain vip" style="margin-left:6px">основной</span>' : ''}</div>
              <div class="s">${esc(contact.position ?? 'Должность не указана')}</div>
            </div>
          </div>
        </td>
        <td>${contact.company_id
    ? `<span class="link" data-company="${contact.company_id}">${esc(contact.company_name)}</span>`
    : '<span class="muted small">Без клиента</span>'}</td>
        <td class="small">${contact.phone ? `<a href="tel:${esc(contact.phone)}">${esc(contact.phone)}</a>` : '<span class="muted">—</span>'}</td>
        <td class="small">${contact.email ? `<a href="mailto:${esc(contact.email)}">${esc(contact.email)}</a>` : '<span class="muted">—</span>'}</td>
        <td class="small">${contact.telegram ? esc(contact.telegram) : '<span class="muted">—</span>'}</td>
        <td>
          ${canWrite ? `<div class="row" style="gap:2px">
            <button class="icon-btn" style="width:30px;height:30px" data-edit="${contact.id}" title="Изменить">${icon('edit', 14)}</button>
            <button class="icon-btn" style="width:30px;height:30px" data-del="${contact.id}" title="Удалить">${icon('trash', 14)}</button>
          </div>` : ''}
        </td>
      </tr>`).join('')

    rows.querySelectorAll('tr[data-id]').forEach((row) => {
      row.addEventListener('click', (event) => {
        if (event.target.closest('button') || event.target.closest('[data-company]') || event.target.closest('a')) return
        const contact = data.items.find((item) => String(item.id) === row.dataset.id)
        if (canWrite) openContactForm(contact, ctx.refresh)
      })
    })
    rows.querySelectorAll('[data-company]').forEach((node) => {
      node.addEventListener('click', () => ctx.navigate(`/companies/${node.dataset.company}`))
    })
    rows.querySelectorAll('[data-edit]').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation()
        const contact = data.items.find((item) => String(item.id) === button.dataset.edit)
        openContactForm(contact, ctx.refresh)
      })
    })
    rows.querySelectorAll('[data-del]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.stopPropagation()
        const contact = data.items.find((item) => String(item.id) === button.dataset.del)
        const { confirmDialog } = await import('../lib.js')
        if (!await confirmDialog({
          title: 'Удалить контакт?',
          message: `${contact.first_name} ${contact.last_name ?? ''} будет удалён из базы.`,
        })) return
        await api(`/api/contacts/${contact.id}`, { method: 'DELETE' })
        toast('Контакт удалён')
        ctx.refresh()
      })
    })
  },
}
