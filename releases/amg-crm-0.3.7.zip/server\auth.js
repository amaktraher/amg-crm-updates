import { db } from './db.js'
import { HttpError } from './http.js'
import { randomToken, sha256 } from './security.js'

export const SESSION_COOKIE = 'crm_sid'
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000

export const PERMISSIONS = {
  admin: { read: true, write: true, manageUsers: true, viewAudit: true },
  manager: { read: true, write: true, manageUsers: false, viewAudit: false },
  viewer: { read: true, write: false, manageUsers: false, viewAudit: false },
}

export function can(user, permission) {
  return Boolean(user && PERMISSIONS[user.role]?.[permission])
}

export function publicUser(row) {
  if (!row) return null
  return {
    id: row.id,
    email: row.email,
    login: row.login ?? null,
    name: row.name,
    role: row.role,
    phone: row.phone ?? null,
    isActive: Boolean(row.is_active),
    createdAt: row.created_at,
    lastLoginAt: row.last_login_at ?? null,
  }
}

export function createSession(userId, userAgent = '') {
  const token = randomToken(32)
  const createdAt = new Date()
  const expiresAt = new Date(createdAt.getTime() + SESSION_TTL_MS)
  db.prepare(`INSERT INTO sessions (token_hash, user_id, created_at, expires_at, user_agent)
    VALUES (?, ?, ?, ?, ?)`)
    .run(sha256(token), userId, createdAt.toISOString(), expiresAt.toISOString(), String(userAgent).slice(0, 255))
  return { token, expiresAt }
}

/** Resolve the signed-in user from the request cookie, deleting expired sessions. */
export function sessionUser(req) {
  const cookie = req.headers.cookie ?? ''
  const match = new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`).exec(cookie)
  if (!match) return null
  const token = decodeURIComponent(match[1])
  const row = db.prepare(`SELECT s.expires_at, u.* FROM sessions s
    JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ?`).get(sha256(token))
  if (!row) return null
  if (new Date(row.expires_at).getTime() < Date.now() || !row.is_active) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token))
    return null
  }
  return publicUser(row)
}

export function destroySession(req) {
  const cookie = req.headers.cookie ?? ''
  const match = new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`).exec(cookie)
  if (!match) return
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(decodeURIComponent(match[1])))
}

export function sessionCookie(token, expiresAt) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Expires=${expiresAt.toUTCString()}`
}

export function clearedCookie() {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`
}

export function requireUser(ctx) {
  if (!ctx.user) throw new HttpError(401, 'Требуется вход', 'UNAUTHENTICATED')
  return ctx.user
}

export function requirePermission(ctx, permission) {
  const user = requireUser(ctx)
  if (!can(user, permission)) throw new HttpError(403, 'Недостаточно прав', 'FORBIDDEN')
  return user
}

/* Simple in-memory brute-force guard for the login endpoint. */
const attempts = new Map()

export function checkLoginRate(key) {
  const now = Date.now()
  const entry = attempts.get(key)
  if (!entry || now - entry.first > 5 * 60 * 1000) {
    attempts.set(key, { count: 0, first: now })
    return
  }
  if (entry.count >= 10) throw new HttpError(429, 'Слишком много попыток входа. Подождите пару минут.')
}

export function noteLoginFailure(key) {
  const entry = attempts.get(key) ?? { count: 0, first: Date.now() }
  entry.count += 1
  attempts.set(key, entry)
}

export function clearLoginFailures(key) {
  attempts.delete(key)
}
