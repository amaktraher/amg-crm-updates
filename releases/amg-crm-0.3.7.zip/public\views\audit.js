/* Журнал действий: кто, что и когда изменил. */
import {
  actionLabel, api, avatar, bindPagination, entityLabel, esc, fmtDateTime, icon, pagination, relTime,
} from '../lib.js'

export default {
  adminOnly: true,
  subtitle: () => 'История изменений в системе',
  async render(ctx) {
    const page = Number(ctx.query.get('page') ?? 1)
    const pageSize = 50
    const data = await api(`/api/audit?page=${page}&pageSize=${pageSize}`)

    const describe = (row) => {
      const meta = row.meta ?? {}
      if (row.action === 'status' && meta.from && meta.to) return `${meta.from} → ${meta.to}`
      if (row.action === 'create' && meta.name) return meta.name
      if (row.action === 'delete' && meta.name) return meta.name
      if (row.action === 'login') return 'успешный вход'
      if (meta.email) return meta.email
      if (meta.role) return `роль: ${meta.role}`
      if (meta.title) return meta.title
      return ''
    }

    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Журнал действий</h2>
          <div class="hint">${data.total} записей · фиксируются вход, изменения и удаления</div></div>
      </div>

      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr>
              <th style="width:180px">Время</th>
              <th style="width:210px">Сотрудник</th>
              <th style="width:170px">Действие</th>
              <th style="width:130px">Объект</th>
              <th>Детали</th>
            </tr></thead>
            <tbody>
              ${data.items.length === 0
    ? `<tr><td colspan="5">${''}</td></tr>`
    : data.items.map((row) => `<tr>
                  <td class="small nowrap">
                    <div>${fmtDateTime(row.created_at)}</div>
                    <div class="muted" style="font-size:11.5px">${relTime(row.created_at)}</div>
                  </td>
                  <td>
                    <div class="stack">
                      ${row.actor_name ? avatar(row.actor_name, { size: 'sm' }) : `<span class="avatar sm" style="background:var(--surface-3);color:var(--muted)">${icon('settings', 13)}</span>`}
                      <div class="col">
                        <div class="t" style="font-size:13px">${esc(row.actor_name ?? 'Система')}</div>
                        <div class="s">${esc(row.actor_email ?? '')}</div>
                      </div>
                    </div>
                  </td>
                  <td><span class="pill plain ${row.action === 'delete' ? 'danger' : row.action === 'create' ? 'active' : ''}">${esc(actionLabel(row.action))}</span></td>
                  <td class="small">${esc(entityLabel(row.entity_type))}${row.entity_id ? ` #${row.entity_id}` : ''}</td>
                  <td class="small">${esc(describe(row))}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
        <div id="pager">${pagination({ page, pageSize, total: data.total })}</div>
      </div>`

    bindPagination(ctx.root, (nextPage) => ctx.navigate(`/audit?page=${nextPage}`))
  },
}
