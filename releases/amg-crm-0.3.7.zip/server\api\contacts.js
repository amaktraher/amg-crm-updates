import { db } from '../db.js'
import { audit, logActivity } from '../audit.js'
import { requirePermission, requireUser } from '../auth.js'
import { HttpError } from '../http.js'
import { idOf, idOrNull, optionalEmail, optionalText, oneOf, text } from '../validate.js'

const ACTIVITY_KINDS = ['note', 'call', 'email', 'meeting']

const SELECT = `
  SELECT ct.*, c.name AS company_name, c.status AS company_status
  FROM contacts ct
  LEFT JOIN companies c ON c.id = ct.company_id`

export function registerContactRoutes(router) {
  router.get('/api/contacts', async ({ query, user }) => {
    requireUser({ user })
    const q = String(query.get('q') ?? '').trim()
    const companyId = query.get('companyId')
    const where = []
    const params = []
    if (q) {
      where.push(`(ct.first_name LIKE ? OR ct.last_name LIKE ? OR ct.phone LIKE ? OR ct.email LIKE ?
        OR ct.position LIKE ? OR c.name LIKE ?)`)
      const like = `%${q}%`
      params.push(like, like, like, like, like, like)
    }
    if (companyId && companyId !== 'all') { where.push('ct.company_id = ?'); params.push(Number(companyId)) }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : ''
    const items = db.prepare(`${SELECT} ${whereSql}
      ORDER BY ct.is_primary DESC, ct.first_name COLLATE NOCASE, ct.last_name COLLATE NOCASE
      LIMIT 500`).all(...params)
    return { items }
  })

  router.get('/api/contacts/:id', async ({ params, user }) => {
    requireUser({ user })
    const id = idOf(params.id)
    const item = db.prepare(`${SELECT} WHERE ct.id = ?`).get(id)
    if (!item) throw new HttpError(404, 'Контакт не найден', 'NOT_FOUND')
    const activities = db.prepare(`SELECT a.*, u.name AS user_name FROM activities a
      LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity_type = 'contact' AND a.entity_id = ?
      ORDER BY a.created_at DESC LIMIT 100`).all(id)
    const tasks = db.prepare(`SELECT t.*, u.name AS assignee_name FROM tasks t
      LEFT JOIN users u ON u.id = t.assignee_id
      WHERE t.contact_id = ? ORDER BY (t.status = 'done'), COALESCE(t.due_at, t.created_at) ASC`).all(id)
    return { item, activities, tasks }
  })

  router.post('/api/contacts', async ({ body, user }) => {
    const actor = requirePermission({ user }, 'write')
    const stamp = new Date().toISOString()
    const firstName = text(body.firstName, 'Имя', { max: 80 })
    const data = {
      companyId: idOrNull(body.companyId, 'клиент'),
      lastName: optionalText(body.lastName, 'Фамилия', { max: 80 }),
      position: optionalText(body.position, 'Должность', { max: 120 }),
      phone: optionalText(body.phone, 'Телефон', { max: 60 }),
      email: optionalEmail(body.email),
      telegram: optionalText(body.telegram, 'Telegram', { max: 80 }),
      note: optionalText(body.note, 'Заметка', { max: 4000 }),
      isPrimary: body.isPrimary ? 1 : 0,
    }
    if (data.companyId && !db.prepare('SELECT 1 FROM companies WHERE id = ?').get(data.companyId)) {
      throw new HttpError(400, 'Клиент не найден', 'VALIDATION')
    }
    const res = db.prepare(`INSERT INTO contacts
      (company_id, first_name, last_name, position, phone, email, telegram, is_primary, note, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(data.companyId, firstName, data.lastName, data.position, data.phone, data.email, data.telegram,
        data.isPrimary, data.note, actor.id, stamp, stamp)
    const id = Number(res.lastInsertRowid)
    audit(actor.id, 'create', 'contact', id, { name: firstName })
    return { item: db.prepare(`${SELECT} WHERE ct.id = ?`).get(id) }
  })

  router.patch('/api/contacts/:id', async ({ body, params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT * FROM contacts WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Контакт не найден', 'NOT_FOUND')
    const data = {
      companyId: body.companyId === undefined ? existing.company_id : idOrNull(body.companyId, 'клиент'),
      firstName: body.firstName === undefined ? existing.first_name : text(body.firstName, 'Имя', { max: 80 }),
      lastName: body.lastName === undefined ? existing.last_name : optionalText(body.lastName, 'Фамилия', { max: 80 }),
      position: body.position === undefined ? existing.position : optionalText(body.position, 'Должность', { max: 120 }),
      phone: body.phone === undefined ? existing.phone : optionalText(body.phone, 'Телефон', { max: 60 }),
      email: body.email === undefined ? existing.email : optionalEmail(body.email),
      telegram: body.telegram === undefined ? existing.telegram : optionalText(body.telegram, 'Telegram', { max: 80 }),
      note: body.note === undefined ? existing.note : optionalText(body.note, 'Заметка', { max: 4000 }),
      isPrimary: body.isPrimary === undefined ? existing.is_primary : (body.isPrimary ? 1 : 0),
    }
    db.prepare(`UPDATE contacts SET company_id = ?, first_name = ?, last_name = ?, position = ?, phone = ?,
      email = ?, telegram = ?, is_primary = ?, note = ?, updated_at = ? WHERE id = ?`)
      .run(data.companyId, data.firstName, data.lastName, data.position, data.phone, data.email,
        data.telegram, data.isPrimary, data.note, new Date().toISOString(), id)
    audit(actor.id, 'update', 'contact', id)
    return { item: db.prepare(`${SELECT} WHERE ct.id = ?`).get(id) }
  })

  router.delete('/api/contacts/:id', async ({ params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT first_name, last_name FROM contacts WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Контакт не найден', 'NOT_FOUND')
    db.prepare('DELETE FROM contacts WHERE id = ?').run(id)
    audit(actor.id, 'delete', 'contact', id, { name: existing.first_name })
    return { ok: true }
  })

  router.post('/api/contacts/:id/activities', async ({ body, params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    if (!db.prepare('SELECT 1 FROM contacts WHERE id = ?').get(id)) {
      throw new HttpError(404, 'Контакт не найден', 'NOT_FOUND')
    }
    const kind = oneOf(body.kind ?? 'note', ACTIVITY_KINDS, 'тип')
    logActivity('contact', id, kind, text(body.body, 'Текст', { max: 4000 }), actor.id)
    return { ok: true }
  })
}
