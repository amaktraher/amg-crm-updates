/* Календарь: задачи по дням месяца. */
import { TASK_STATUS, api, dueMeta, esc, icon, monthTitle, state } from '../lib.js'
import { openTaskForm } from './forms.js'

const DOW = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']

const dayKey = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`

export default {
  subtitle: () => 'Задачи и сроки по дням',
  async render(ctx) {
    const monthParam = ctx.query.get('m')
    const base = monthParam ? new Date(`${monthParam}-01T00:00:00`) : new Date()
    const monthStart = new Date(base.getFullYear(), base.getMonth(), 1)
    const nextMonth = new Date(base.getFullYear(), base.getMonth() + 1, 1)
    const gridStart = new Date(monthStart)
    const weekday = (gridStart.getDay() + 6) % 7
    gridStart.setDate(gridStart.getDate() - weekday)
    const gridEnd = new Date(nextMonth)
    gridEnd.setDate(gridEnd.getDate() + ((7 - ((gridEnd.getDay() + 6) % 7)) % 7))

    const canWrite = state.permissions?.write

    const data = await api(`/api/tasks?scope=all&from=${gridStart.toISOString()}&to=${gridEnd.toISOString()}`)
    const byDay = new Map()
    for (const task of data.items) {
      if (!task.due_at) continue
      const key = dayKey(new Date(task.due_at))
      if (!byDay.has(key)) byDay.set(key, [])
      byDay.get(key).push(task)
    }

    const todayKey = dayKey(new Date())
    const cells = []
    const cursor = new Date(gridStart)
    while (cursor < gridEnd) {
      const key = dayKey(cursor)
      const dayTasks = (byDay.get(key) ?? []).sort((a, b) => a.due_at.localeCompare(b.due_at))
      const other = cursor.getMonth() !== monthStart.getMonth()
      cells.push(`<div class="calendar-cell ${other ? 'other' : ''} ${key === todayKey ? 'today' : ''}" data-day="${key}">
        <div class="row" style="justify-content:space-between">
          <span class="day-num">${cursor.getDate()}</span>
          ${dayTasks.length > 0 ? `<span class="small muted">${dayTasks.length}</span>` : ''}
        </div>
        ${dayTasks.slice(0, 3).map((task) => {
    const due = dueMeta(task.due_at, task.status)
    void due
    return `<div class="cal-event ${task.status === 'done' ? 'done' : ''} ${task.priority === 'high' ? 'high' : ''}"
            data-task="${task.id}" title="${esc(`${TASK_STATUS[task.status]}: ${task.title}`)}">
            ${String(new Date(task.due_at).getHours()).padStart(2, '0')}:${String(new Date(task.due_at).getMinutes()).padStart(2, '0')} · ${esc(task.title)}
          </div>`
  }).join('')}
        ${dayTasks.length > 3 ? `<div class="small muted" style="padding-left:4px">ещё ${dayTasks.length - 3}</div>` : ''}
      </div>`)
      cursor.setDate(cursor.getDate() + 1)
    }

    const navTo = (date) => {
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`
      ctx.navigate(`/calendar?m=${key}`)
    }

    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Календарь</h2><div class="hint">Задачи с указанным сроком</div></div>
        <div class="actions">
          ${canWrite ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Новая задача</button>` : ''}
        </div>
      </div>

      <div class="calendar">
        <div class="calendar-head">
          <button class="icon-btn" id="prev" title="Предыдущий месяц">${icon('chevronLeft', 16)}</button>
          <button class="icon-btn" id="next" title="Следующий месяц">${icon('chevronRight', 16)}</button>
          <h3 style="margin-left:6px">${monthTitle(monthStart)}</h3>
          <span class="spacer" style="flex:1"></span>
          <span class="small muted">${data.items.filter((t) => t.status !== 'done').length} открытых задач в периоде</span>
          <button class="btn btn-sm" id="today">Сегодня</button>
        </div>
        <div class="calendar-grid">
          ${DOW.map((day) => `<div class="calendar-dow">${day}</div>`).join('')}
          ${cells.join('')}
        </div>
      </div>`

    ctx.root.querySelector('#prev').addEventListener('click', () => navTo(new Date(monthStart.getFullYear(), monthStart.getMonth() - 1, 1)))
    ctx.root.querySelector('#next').addEventListener('click', () => navTo(new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 1)))
    ctx.root.querySelector('#today').addEventListener('click', () => navTo(new Date()))
    ctx.root.querySelector('[data-act="new"]')?.addEventListener('click', () => openTaskForm(null, ctx.refresh))

    ctx.root.querySelectorAll('[data-task]').forEach((node) => {
      node.addEventListener('click', async (event) => {
        event.stopPropagation()
        const task = data.items.find((item) => String(item.id) === node.dataset.task)
        if (task && canWrite) openTaskForm(task, ctx.refresh)
      })
    })

    ctx.root.querySelectorAll('.calendar-cell').forEach((cell) => {
      cell.addEventListener('click', async (event) => {
        if (!canWrite) return
        if (event.target.closest('[data-task]')) return
        const [year, month, day] = cell.dataset.day.split('-').map(Number)
        const due = new Date(year, month - 1, day, 12, 0, 0)
        await openTaskForm(null, ctx.refresh, { dueAt: due.toISOString() })
      })
    })
  },
}
