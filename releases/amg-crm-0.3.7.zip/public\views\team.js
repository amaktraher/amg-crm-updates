/* Команда: сотрудники, роли и доступ. Раздел только для администраторов. */
import {
  ROLE_LABELS, api, avatar, esc, fmtDateTime, icon, plural, state, toast,
} from '../lib.js'
import { openUserForm } from './forms.js'

export default {
  adminOnly: true,
  subtitle: () => 'Сотрудники, роли и права доступа',
  async render(ctx) {
    const data = await api('/api/users')
    const items = data.items

    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Команда</h2><div class="hint">${items.length} ${plural(items.length, ['сотрудник', 'сотрудника', 'сотрудников'])} в системе</div></div>
        <div class="actions">
          <button class="btn btn-primary" data-act="new">${icon('plus', 16)} Добавить сотрудника</button>
        </div>
      </div>

      <div class="grid-3" style="margin-bottom:16px">
        ${Object.entries(ROLE_LABELS).map(([role, label]) => {
    const count = items.filter((item) => item.role === role).length
    return `<div class="card card-pad">
          <div class="row" style="justify-content:space-between">
            <span class="small muted">${esc(label)}</span>
            <span class="pill ${role === 'admin' ? 'vip' : role === 'manager' ? 'info' : 'archived'}">${count}</span>
          </div>
          <div style="font-size:24px;font-weight:700;margin-top:6px">${count}</div>
          <div class="small muted">${role === 'admin' ? 'полный доступ и настройки' : role === 'manager' ? 'работа с клиентами и задачами' : 'только просмотр данных'}</div>
        </div>`
  }).join('')}
      </div>

      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr>
              <th style="width:28%">Сотрудник</th>
              <th>Роль</th>
              <th>Клиенты</th>
              <th>Открытые задачи</th>
              <th>Последний вход</th>
              <th>Статус</th>
              <th style="width:44px"></th>
            </tr></thead>
            <tbody>
              ${items.map((member) => `
                <tr data-id="${member.id}">
                  <td>
                    <div class="stack">
                      ${avatar(member.name, { size: member.isActive ? '' : 'sm' })}
                      <div class="col">
                        <div class="t">${esc(member.name)} ${member.id === state.user.id ? '<span class="pill plain" style="margin-left:4px">это вы</span>' : ''}</div>
                        <div class="s">${member.login ? `логин: ${esc(member.login)}` : esc(member.email)}</div>
                      </div>
                    </div>
                  </td>
                  <td><span class="pill ${member.role === 'admin' ? 'vip' : member.role === 'manager' ? 'info' : 'archived'}">${esc(ROLE_LABELS[member.role])}</span></td>
                  <td class="mono">${member.companiesCount}</td>
                  <td class="mono">${member.openTasks}</td>
                  <td class="small muted nowrap">${member.lastLoginAt ? fmtDateTime(member.lastLoginAt) : 'не входил'}</td>
                  <td>${member.isActive
    ? '<span class="pill active">активен</span>'
    : '<span class="pill archived">отключён</span>'}</td>
                  <td>
                    <button class="icon-btn" style="width:30px;height:30px;border:0;background:transparent" data-menu="${member.id}">${icon('more', 16)}</button>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`

    ctx.root.querySelector('[data-act="new"]').addEventListener('click', () => openUserForm(null, ctx.refresh))

    ctx.root.querySelectorAll('[data-menu]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.stopPropagation()
        const member = items.find((item) => String(item.id) === button.dataset.menu)
        const { dropdown, confirmDialog } = await import('../lib.js')
        dropdown(button, [
          { label: 'Редактировать', icon: 'edit', onClick: () => openUserForm(member, ctx.refresh) },
          { label: 'Сменить пароль', icon: 'key', onClick: () => openUserForm(member, ctx.refresh) },
          ...(member.id === state.user.id ? [] : [{ sep: true }, {
            label: 'Удалить сотрудника',
            icon: 'trash',
            danger: true,
            onClick: async () => {
              if (!await confirmDialog({
                title: 'Удалить сотрудника?',
                message: `${member.name} потеряет доступ. Задачи и клиенты останутся в системе.`,
              })) return
              try {
                await api(`/api/users/${member.id}`, { method: 'DELETE' })
                toast('Сотрудник удалён')
                ctx.refresh()
              } catch (error) {
                toast(error.message, 'error')
              }
            },
          }]),
        ])
      })
    })
  },
}
