/* Клиенты: таблица с поиском, фильтрами, сортировкой и пагинацией. */
import {
  COMPANY_STATUS, api, avatar, bindPagination, emptyState, esc, icon, pagination, plural, relTime, skeletonRows,
  state, toast,
} from '../lib.js'
import { loadUsers, openCompanyForm } from './forms.js'

export default {
  subtitle: (params) => 'База компаний и частных лиц',
  async render(ctx) {
    const q = ctx.query.get('q') ?? ''
    const status = ctx.query.get('status') ?? 'all'
    const owner = ctx.query.get('ownerId') ?? 'all'
    const sort = ctx.query.get('sort') ?? 'created'
    const page = Number(ctx.query.get('page') ?? 1)
    const pageSize = 25

    const users = await loadUsers()
    const canWrite = state.permissions?.write
    const isAdmin = state.user.role === 'admin'

    const params = new URLSearchParams()
    if (q) params.set('q', q)
    if (status !== 'all') params.set('status', status)
    if (owner !== 'all') params.set('ownerId', owner)
    if (sort !== 'created') params.set('sort', sort)
    if (page > 1) params.set('page', String(page))

    ctx.root.innerHTML = `
      <div class="page-head">
        <div>
          <h2>Постоянные клиенты</h2>
          <div class="hint" id="clients-count">Загружаем…</div>
        </div>
        <div class="actions">
          ${canWrite ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Новый клиент</button>` : ''}
        </div>
      </div>

      <div class="segmented" style="margin-bottom:14px">
        <button class="active">Клиенты</button>
        <button data-go="/contacts">Люди</button>
      </div>
      <div class="toolbar">
        <div class="search" style="width:280px">${icon('search', 15)}
          <input id="q" type="search" placeholder="Название, телефон, e-mail…" value="${esc(q)}" />
        </div>
        <select class="select" id="status" style="width:auto;min-width:150px">
          <option value="all">Все статусы</option>
          ${Object.entries(COMPANY_STATUS).map(([value, meta]) =>
    `<option value="${value}" ${status === value ? 'selected' : ''}>${esc(meta.label)}</option>`).join('')}
        </select>
        <select class="select" id="owner" style="width:auto;min-width:170px">
          <option value="all">Все ответственные</option>
          ${users.map((user) => `<option value="${user.id}" ${String(owner) === String(user.id) ? 'selected' : ''}>${esc(user.name)}</option>`).join('')}
        </select>
        <select class="select" id="sort" style="width:auto;min-width:160px">
          <option value="created" ${sort === 'created' ? 'selected' : ''}>Сначала новые</option>
          <option value="name" ${sort === 'name' ? 'selected' : ''}>По названию</option>
          <option value="activity" ${sort === 'activity' ? 'selected' : ''}>По активности</option>
        </select>
        <div class="spacer"></div>
      </div>

      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr>
              <th style="width:36%">Клиент</th>
              <th>Статус</th>
              <th>Контакты</th>
              <th>Задачи</th>
              <th>Ответственный</th>
              <th>Активность</th>
              <th style="width:44px"></th>
            </tr></thead>
            <tbody id="rows">${skeletonRows(6)}</tbody>
          </table>
        </div>
        <div id="pager"></div>
      </div>`

    ctx.root.querySelectorAll('[data-go]').forEach((button) => {
      button.addEventListener('click', () => ctx.navigate(button.dataset.go))
    })

    const rows = ctx.root.querySelector('#rows')

    const load = async () => {
      rows.innerHTML = skeletonRows(6)
      const data = await api(`/api/companies?${params.toString()}&page=${page}&pageSize=${pageSize}`)
      ctx.root.querySelector('#clients-count').textContent =
        `${data.total} ${plural(data.total, ['клиент', 'клиента', 'клиентов'])} в базе`
      if (data.items.length === 0) {
        rows.innerHTML = ''
        ctx.root.querySelector('#pager').innerHTML = emptyState({
          iconName: 'building',
          title: q ? 'Ничего не найдено' : 'Клиентов пока нет',
          text: q ? 'Попробуйте изменить запрос или сбросить фильтры.' : 'Добавьте первого клиента — и начните вести историю.',
          action: canWrite && !q ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Добавить клиента</button>` : '',
        })
        ctx.root.querySelector('[data-act="new"]')?.addEventListener('click', () => openCompanyForm(null, ctx.refresh))
        return
      }

      rows.innerHTML = data.items.map((company) => {
        const statusMeta = COMPANY_STATUS[company.status] ?? { label: company.status, cls: '' }
        const openTasks = company.open_tasks
        const activity = company.last_activity_at ?? company.last_task_at
        return `<tr data-id="${company.id}">
          <td>
            <div class="stack">
              ${avatar(company.name, { companyName: true })}
              <div class="col">
                <div class="t">${esc(company.name)}</div>
                <div class="s">${esc(company.industry ?? 'Сфера не указана')}</div>
              </div>
            </div>
          </td>
          <td><span class="pill ${statusMeta.cls}">${esc(statusMeta.label)}</span></td>
          <td class="mono">${company.contacts_count}</td>
          <td>${openTasks > 0
    ? `<span class="pill info plain">${openTasks} ${plural(openTasks, ['задача', 'задачи', 'задач'])}</span>`
    : '<span class="muted small">—</span>'}</td>
          <td>${company.owner_name
    ? `<div class="stack">${avatar(company.owner_name, { size: 'sm' })}<span class="small">${esc(company.owner_name)}</span></div>`
    : '<span class="muted small">Не назначен</span>'}</td>
          <td class="small muted nowrap">${activity ? relTime(activity) : 'нет событий'}</td>
          <td>
            <button class="icon-btn" style="width:30px;height:30px;border:0;background:transparent" data-menu="${company.id}" title="Действия">${icon('more', 16)}</button>
          </td>
        </tr>`
      }).join('')

      ctx.root.querySelector('#pager').innerHTML = pagination({ page, pageSize, total: data.total })
      bindPagination(ctx.root, (nextPage) => {
        params.set('page', String(nextPage))
        ctx.navigate(`/companies?${params.toString()}`)
      })

      rows.querySelectorAll('tr[data-id]').forEach((row) => {
        row.addEventListener('click', (event) => {
          if (event.target.closest('[data-menu]')) return
          ctx.navigate(`/companies/${row.dataset.id}`)
        })
      })

      ctx.root.querySelectorAll('[data-menu]').forEach((button) => {
        button.addEventListener('click', (event) => {
          event.stopPropagation()
          const company = data.items.find((item) => String(item.id) === button.dataset.menu)
          import('../lib.js').then(({ dropdown }) => dropdown(button, [
            { label: 'Открыть карточку', icon: 'building', onClick: () => ctx.navigate(`/companies/${company.id}`) },
            ...(canWrite ? [{ label: 'Редактировать', icon: 'edit', onClick: () => openCompanyForm(company, ctx.refresh) }] : []),
            ...(isAdmin ? [{ sep: true }, {
              label: 'Удалить клиента',
              icon: 'trash',
              danger: true,
              onClick: async () => {
                const { confirmDialog } = await import('../lib.js')
                if (!await confirmDialog({
                  title: 'Удалить клиента?',
                  message: `«${company.name}» и все его контакты будут удалены безвозвратно.`,
                })) return
                await api(`/api/companies/${company.id}`, { method: 'DELETE' })
                toast('Клиент удалён')
                ctx.refresh()
              },
            }] : []),
          ]))
        })
      })
    }

    const reloadWith = (changes) => {
      const next = new URLSearchParams(params)
      for (const [key, value] of Object.entries(changes)) {
        if (value === '' || value === null || value === undefined) next.delete(key)
        else next.set(key, value)
      }
      if (!('page' in changes)) next.delete('page')
      ctx.navigate(`/companies${next.toString() ? `?${next.toString()}` : ''}`)
    }

    let searchTimer = null
    ctx.root.querySelector('#q').addEventListener('input', (event) => {
      clearTimeout(searchTimer)
      const value = event.target.value.trim()
      searchTimer = setTimeout(() => reloadWith({ q: value }), 350)
    })
    ctx.root.querySelector('#status').addEventListener('change', (event) => reloadWith({ status: event.target.value }))
    ctx.root.querySelector('#owner').addEventListener('change', (event) => reloadWith({ ownerId: event.target.value }))
    ctx.root.querySelector('#sort').addEventListener('change', (event) => reloadWith({ sort: event.target.value }))
    ctx.root.querySelectorAll('[data-act="new"]').forEach((button) => {
      button.addEventListener('click', () => openCompanyForm(null, ctx.refresh))
    })

    await load()
  },
}
