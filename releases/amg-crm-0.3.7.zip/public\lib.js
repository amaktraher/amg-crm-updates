/* Общие утилиты интерфейса: состояние, API, иконки, форматирование, тосты, модалки. */

export const state = {
  user: null,
  permissions: null,
  users: [],
  theme: localStorage.getItem('crm-theme') ?? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'),
  onUnauthorized: null,
}

/* ── API ─────────────────────────────────────────────────── */

export class ApiError extends Error {
  constructor(message, status, code) {
    super(message)
    this.status = status
    this.code = code
  }
}

export async function api(path, { method = 'GET', body } = {}) {
  const response = await fetch(path, {
    method,
    credentials: 'same-origin',
    headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const text = await response.text()
  let data = null
  try { data = text ? JSON.parse(text) : null } catch { data = { raw: text } }
  if (!response.ok) {
    if (response.status === 401 && state.onUnauthorized) state.onUnauthorized()
    throw new ApiError(data?.error ?? 'Ошибка запроса', response.status, data?.code)
  }
  return data
}

/* ── Иконки ──────────────────────────────────────────────── */

const ICONS = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.6"/><rect x="14" y="3" width="7" height="7" rx="1.6"/><rect x="3" y="14" width="7" height="7" rx="1.6"/><rect x="14" y="14" width="7" height="7" rx="1.6"/>',
  building: '<path d="M3 21h18"/><path d="M5 21V6.5L12 3l7 3.5V21"/><path d="M9 21v-5h6v5"/><path d="M9 9h1.5M13.5 9H15M9 12.5h1.5M13.5 12.5H15"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  contact: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2.2"/><path d="M6 17c.6-1.7 1.8-2.5 3-2.5s2.4.8 3 2.5"/><path d="M15 9h3M15 13h3"/>',
  kanban: '<rect x="3" y="4" width="5.5" height="16" rx="1.6"/><rect x="10" y="4" width="5.5" height="10" rx="1.6"/><rect x="17" y="4" width="4" height="13" rx="1.6"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 11h18"/>',
  shield: '<path d="M12 3 5 6v6c0 4.2 2.9 7.6 7 9 4.1-1.4 7-4.8 7-9V6l-7-3Z"/><path d="m9 12 2 2 4-4"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 8v4l3 2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 13a8.5 8.5 0 1 1-9.9-9.8A7 7 0 0 0 21 13Z"/>',
  logout: '<path d="M9 21H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h3"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
  more: '<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
  trash: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 15h10l1-15"/><path d="M10 11v6M14 11v6"/>',
  phone: '<path d="M22 16.9v2.6a2 2 0 0 1-2.2 2 19 19 0 0 1-8.3-2.9 18.7 18.7 0 0 1-5.7-5.7A19 19 0 0 1 2.9 4.6 2 2 0 0 1 4.9 2.4h2.6a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.5 10.3a15 15 0 0 0 5.2 5.2l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3.5 7 8.5 6 8.5-6"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a15 15 0 0 1 0 18a15 15 0 0 1 0-18Z"/>',
  pin: '<path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z"/><circle cx="12" cy="10" r="2.6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  alert: '<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v5M12 17h.01"/>',
  check: '<path d="m4 12.5 5 5L20 6.5"/>',
  chevronLeft: '<path d="m15 18-6-6 6-6"/>',
  chevronRight: '<path d="m9 18 6-6-6-6"/>',
  chevronDown: '<path d="m6 9 6 6 6-6"/>',
  arrowLeft: '<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>',
  trend: '<path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
  message: '<path d="M21 15a3 3 0 0 1-3 3H8l-5 4V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3Z"/>',
  briefcase: '<rect x="3" y="7" width="18" height="13" rx="3"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/><path d="M3 12h18"/>',
  filter: '<path d="M4 5h16l-6 7v6l-4 2v-8Z"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 4v5h-5"/>',
  bolt: '<path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z"/>',
  star: '<path d="m12 3 2.7 5.7 6.3.9-4.5 4.4 1 6.2-5.5-3-5.5 3 1-6.2L3 9.6l6.3-.9L12 3Z"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2 2 2 0 1 1-4 0 1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.4-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 4.6a2 2 0 1 1 4 0 1.7 1.7 0 0 0 2.9 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 11a2 2 0 1 1 0 4Z"/>',
  download: '<path d="M12 3v12"/><path d="m7 11 5 5 5-5"/><path d="M4 21h16"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9"/><path d="m17 6 3 3"/>',
}

export function icon(name, size = 18, cls = '') {
  const body = ICONS[name] ?? ICONS.grid
  return `<svg class="${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`
}

/* ── Форматирование ──────────────────────────────────────── */

export const esc = (value) => String(value ?? '')
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;')
  .replaceAll("'", '&#39;')

const MONTHS = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек']
const MONTHS_FULL = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь']

export function fmtDate(iso) {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return '—'
  const sameYear = d.getFullYear() === new Date().getFullYear()
  return `${d.getDate()} ${MONTHS[d.getMonth()]}${sameYear ? '' : ` ${d.getFullYear()}`}`
}

export function fmtDateTime(iso) {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return '—'
  const time = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
  return `${d.getDate()} ${MONTHS[d.getMonth()]}, ${time}`
}

export function monthTitle(date) {
  return `${MONTHS_FULL[date.getMonth()]} ${date.getFullYear()}`
}

export function relTime(iso) {
  if (!iso) return '—'
  const diff = (Date.now() - new Date(iso).getTime()) / 1000
  if (diff < 60) return 'только что'
  if (diff < 3600) return `${Math.floor(diff / 60)} мин назад`
  if (diff < 86400) return `${Math.floor(diff / 3600)} ч назад`
  const days = Math.floor(diff / 86400)
  if (days === 1) return 'вчера'
  if (days < 7) return `${days} дн назад`
  return fmtDate(iso)
}

export function plural(n, forms) {
  const abs = Math.abs(n) % 100
  const last = abs % 10
  if (abs > 10 && abs < 20) return forms[2]
  if (last === 1) return forms[0]
  if (last >= 2 && last <= 4) return forms[1]
  return forms[2]
}

const LEGAL_FORMS = new Set(['ооо', 'оао', 'зао', 'пао', 'ао', 'ип', 'нко', 'анo', 'ано', 'llc', 'ltd', 'inc', 'corp', 'gmbh'])

export function initials(name) {
  const cleaned = String(name ?? '?').replace(/[«»"'()[\].,]/g, ' ')
  const words = cleaned.split(/\s+/).filter((word) => word.length > 1)
  const meaningful = words.filter((word) => !LEGAL_FORMS.has(word.toLowerCase()))
  const source = (meaningful.length > 0 ? meaningful : words).slice(0, 2)
  const letters = source.map((word) => word[0]).join('')
  return (letters || String(name ?? '?')[0] || '?').toUpperCase()
}

const AVATAR_COLORS = [
  'linear-gradient(135deg,#6366f1,#8b5cf6)',
  'linear-gradient(135deg,#0ea5e9,#22d3ee)',
  'linear-gradient(135deg,#f59e0b,#f97316)',
  'linear-gradient(135deg,#10b981,#34d399)',
  'linear-gradient(135deg,#ec4899,#f472b6)',
  'linear-gradient(135deg,#8b5cf6,#d946ef)',
  'linear-gradient(135deg,#ef4444,#f97316)',
  'linear-gradient(135deg,#14b8a6,#0ea5e9)',
]

export function avatarColor(seed) {
  let hash = 0
  const value = String(seed ?? '')
  for (let i = 0; i < value.length; i += 1) hash = (hash * 31 + value.charCodeAt(i)) % 997
  return AVATAR_COLORS[hash % AVATAR_COLORS.length]
}

/** Круглый аватар с инициалами. Флаг companyName оставлен для совместимости вызовов. */
export function avatar(name, { size = '', companyName } = {}) {
  void companyName
  const cls = `avatar ${size}`.trim()
  const label = initials(name)
  return `<span class="${cls}" style="background:${avatarColor(name)}" title="${esc(name)}">${esc(label)}</span>`
}

export const COMPANY_STATUS = {
  lead: { label: 'Лид', cls: 'lead' },
  active: { label: 'Активный', cls: 'active' },
  vip: { label: 'VIP', cls: 'vip' },
  archived: { label: 'Архив', cls: 'archived' },
}

export function statusPill(status) {
  const meta = COMPANY_STATUS[status] ?? { label: status, cls: '' }
  return `<span class="pill ${meta.cls}">${esc(meta.label)}</span>`
}

export const TASK_STATUS = { todo: 'К выполнению', doing: 'В работе', done: 'Готово' }
export const TASK_PRIORITY = { low: 'Низкий', normal: 'Обычный', high: 'Высокий' }

export const ACTIVITY_KIND = {
  note: { label: 'Заметка', icon: 'message', cls: '' },
  call: { label: 'Звонок', icon: 'phone', cls: 'phone' },
  email: { label: 'Письмо', icon: 'mail', cls: 'email' },
  meeting: { label: 'Встреча', icon: 'calendar', cls: 'meeting' },
  system: { label: 'Система', icon: 'clock', cls: 'system' },
}

export const ROLE_LABELS = { admin: 'Администратор', manager: 'Менеджер', viewer: 'Наблюдатель' }

const ACTION_LABELS = {
  create: 'создал(а)', update: 'изменил(а)', delete: 'удалил(а)', status: 'сменил(а) статус',
  login: 'вход в систему', activity: 'заметка', 'change-password': 'сменил(а) пароль',
  'reset-password': 'сбросил(а) пароль', seed: 'первичное наполнение',
}
const ENTITY_LABELS = { company: 'клиент', contact: 'контакт', task: 'задача', user: 'пользователь', system: 'система' }
export const actionLabel = (action) => ACTION_LABELS[action] ?? action
export const entityLabel = (type) => ENTITY_LABELS[type] ?? type

export function dueMeta(iso, status) {
  if (!iso) return { text: 'без срока', cls: '' }
  const date = new Date(iso)
  const now = new Date()
  const startToday = new Date(now); startToday.setHours(0, 0, 0, 0)
  const startTomorrow = new Date(startToday); startTomorrow.setDate(startTomorrow.getDate() + 1)
  const time = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
  if (status === 'done') return { text: fmtDate(iso), cls: '' }
  if (date < now) {
    const days = Math.max(1, Math.ceil((now - date) / 86400000))
    return { text: `просрочено на ${days} ${plural(days, ['день', 'дня', 'дней'])}`, cls: 'overdue' }
  }
  if (date >= startToday && date < startTomorrow) return { text: `сегодня, ${time}`, cls: 'today' }
  if (date >= startTomorrow && date < new Date(startTomorrow.getTime() + 86400000)) return { text: `завтра, ${time}`, cls: '' }
  return { text: `${fmtDate(iso)}, ${time}`, cls: '' }
}

export function toInputDateTime(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

export function fromInputDateTime(value) {
  if (!value) return null
  const d = new Date(value)
  return Number.isNaN(d.getTime()) ? null : d.toISOString()
}

/* ── Тосты ───────────────────────────────────────────────── */

export function toast(message, type = 'success') {
  const root = document.getElementById('toast-root')
  if (!root) return
  const el = document.createElement('div')
  el.className = `toast ${type}`
  el.innerHTML = `<span class="dot"></span><span>${esc(message)}</span>`
  root.appendChild(el)
  setTimeout(() => {
    el.classList.add('out')
    setTimeout(() => el.remove(), 200)
  }, 3400)
}

/* ── Модальные окна ──────────────────────────────────────── */

let openCount = 0

export function openModal({ title, sub = '', body = '', footer = '', wide = false, onMount }) {
  const root = document.getElementById('modal-root')
  const backdrop = document.createElement('div')
  backdrop.className = 'modal-backdrop'
  backdrop.innerHTML = `
    <div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">
      <div class="modal-head">
        <div>
          <h3>${esc(title)}</h3>
          ${sub ? `<div class="sub">${esc(sub)}</div>` : ''}
        </div>
        <button class="icon-btn close" type="button" aria-label="Закрыть">${icon('x', 16)}</button>
      </div>
      <div class="modal-body">${body}</div>
      ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
    </div>`
  document.body.appendChild(backdrop)
  document.body.style.overflow = 'hidden'
  openCount += 1

  const close = () => {
    backdrop.remove()
    openCount = Math.max(0, openCount - 1)
    if (openCount === 0) document.body.style.overflow = ''
    document.removeEventListener('keydown', onKey)
  }
  const onKey = (event) => { if (event.key === 'Escape') close() }
  document.addEventListener('keydown', onKey)
  backdrop.querySelector('.close').addEventListener('click', close)
  backdrop.addEventListener('mousedown', (event) => { if (event.target === backdrop) close() })
  const modal = backdrop.querySelector('.modal')
  onMount?.(modal, close)

  return { el: modal, backdrop, close }
}

export function confirmDialog({ title, message, confirmLabel = 'Удалить', cancelLabel = 'Отмена', danger = true }) {
  return new Promise((resolve) => {
    const { el, close } = openModal({
      title,
      body: `<p style="color:var(--text-2);font-size:13.5px;line-height:1.6">${esc(message)}</p>`,
      footer: `<button class="btn" data-act="cancel">${esc(cancelLabel)}</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-act="ok">${esc(confirmLabel)}</button>`,
    })
    el.querySelector('[data-act="cancel"]').addEventListener('click', () => { close(); resolve(false) })
    el.querySelector('[data-act="ok"]').addEventListener('click', () => { close(); resolve(true) })
  })
}

/**
 * Универсальная форма в модальном окне.
 * fields: { name, label, type, value, options, required, placeholder, hint, span, rows }
 */
export function formModal({
  title, sub = '', fields, submitLabel = 'Сохранить', wide = false, submit, extraFooter = '',
}) {
  return new Promise((resolve) => {
    const rows = fields.map((field) => {
      const id = `f-${field.name}`
      const span = field.span === 2 ? 'span-2' : ''
      const common = `id="${id}" name="${esc(field.name)}" ${field.required ? 'required' : ''}`
      let control = ''
      if (field.type === 'textarea') {
        control = `<textarea class="textarea" ${common} rows="${field.rows ?? 4}"
          placeholder="${esc(field.placeholder ?? '')}">${esc(field.value ?? '')}</textarea>`
      } else if (field.type === 'select') {
        const options = (field.options ?? []).map((option) => {
          const value = typeof option === 'string' ? option : option.value
          const label = typeof option === 'string' ? option : option.label
          const selected = String(field.value ?? '') === String(value) ? 'selected' : ''
          return `<option value="${esc(value)}" ${selected}>${esc(label)}</option>`
        }).join('')
        control = `<select class="select" ${common}>${options}</select>`
      } else if (field.type === 'checkbox') {
        control = `<label class="checkbox"><input type="checkbox" ${common} ${field.value ? 'checked' : ''}/> ${esc(field.checkboxLabel ?? '')}</label>`
      } else {
        control = `<input class="input" type="${field.type ?? 'text'}" ${common}
          value="${esc(field.value ?? '')}" placeholder="${esc(field.placeholder ?? '')}"
          ${field.autocomplete ? `autocomplete="${esc(field.autocomplete)}"` : ''}
          ${field.min !== undefined ? `min="${esc(field.min)}"` : ''} />`
      }
      return `<div class="field ${span}">
        <label for="${id}">${esc(field.label)}${field.required ? ' *' : ''}</label>
        ${control}
        ${field.hint ? `<span class="hint">${esc(field.hint)}</span>` : ''}
      </div>`
    }).join('')

    const { el, close } = openModal({
      title,
      sub,
      wide,
      body: `<form class="form-grid" id="modal-form" novalidate>${rows}
        <div class="field span-2" id="form-error" style="display:none"><span class="error"></span></div>
      </form>`,
      footer: `<div class="left">${extraFooter}</div>
        <button class="btn" type="button" data-act="cancel">Отмена</button>
        <button class="btn btn-primary" type="submit" form="modal-form">${esc(submitLabel)}</button>`,
    })

    const form = el.querySelector('#modal-form')
    const errorBox = el.querySelector('#form-error')
    const submitButton = el.querySelector('[data-act="submit"], button[type="submit"]')
    el.querySelector('[data-act="cancel"]').addEventListener('click', () => { close(); resolve(null) })

    const collect = () => {
      const values = {}
      for (const field of fields) {
        const node = form.elements.namedItem(field.name)
        if (!node) continue
        if (field.type === 'checkbox') values[field.name] = node.checked
        else if (field.type === 'number') values[field.name] = node.value === '' ? null : Number(node.value)
        else values[field.name] = node.value
      }
      return values
    }

    form.addEventListener('submit', async (event) => {
      event.preventDefault()
      errorBox.style.display = 'none'
      const values = collect()
      for (const field of fields) {
        if (field.required && !String(values[field.name] ?? '').trim()) {
          errorBox.style.display = ''
          errorBox.querySelector('.error').textContent = `Заполните поле «${field.label}»`
          form.elements.namedItem(field.name)?.focus()
          return
        }
      }
      submitButton.disabled = true
      const original = submitButton.textContent
      submitButton.innerHTML = '<span class="spinner"></span>'
      try {
        await submit(values)
        close()
        resolve(values)
      } catch (error) {
        errorBox.style.display = ''
        errorBox.querySelector('.error').textContent = error.message ?? 'Не удалось сохранить'
        submitButton.disabled = false
        submitButton.textContent = original
      }
    })

    setTimeout(() => form.querySelector('input, textarea, select')?.focus(), 40)
  })
}

/* ── Выпадающее меню ─────────────────────────────────────── */

export function dropdown(anchor, items) {
  document.querySelectorAll('.menu').forEach((node) => node.remove())
  const rect = anchor.getBoundingClientRect()
  const menu = document.createElement('div')
  menu.className = 'menu'
  menu.innerHTML = items.map((item, index) => (item.sep
    ? '<div class="sep"></div>'
    : `<button type="button" data-i="${index}" class="${item.danger ? 'danger' : ''}">
        ${item.icon ? icon(item.icon, 16) : ''}<span>${esc(item.label)}</span></button>`)).join('')
  document.body.appendChild(menu)
  const width = menu.offsetWidth
  let left = Math.min(rect.right - width, window.innerWidth - width - 12)
  left = Math.max(12, rect.right - width)
  let top = rect.bottom + 6
  if (top + menu.offsetHeight > window.innerHeight - 12) top = rect.top - menu.offsetHeight - 6
  menu.style.left = `${left}px`
  menu.style.top = `${Math.max(12, top)}px`
  menu.style.position = 'fixed'

  const close = () => { menu.remove(); document.removeEventListener('mousedown', onOutside) }
  const onOutside = (event) => { if (!menu.contains(event.target)) close() }
  setTimeout(() => document.addEventListener('mousedown', onOutside), 0)
  menu.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-i]')
    if (!button) return
    const item = items[Number(button.dataset.i)]
    close()
    item?.onClick?.()
  })
  return close
}

/* ── Мелкие шаблоны ──────────────────────────────────────── */

export function emptyState({ iconName = 'grid', title, text = '', action = '' }) {
  return `<div class="empty">
    <div class="icon">${icon(iconName, 24)}</div>
    <h4>${esc(title)}</h4>
    ${text ? `<p>${esc(text)}</p>` : ''}
    ${action}
  </div>`
}

export function pagination({ page, pageSize, total }) {
  const pages = Math.max(1, Math.ceil(total / pageSize))
  if (total === 0) return ''
  const from = (page - 1) * pageSize + 1
  const to = Math.min(total, page * pageSize)
  return `<div class="pagination">
    <span>${from}–${to} из ${total}</span>
    <span class="spacer"></span>
    <button class="btn btn-sm" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>${icon('chevronLeft', 14)}</button>
    <span class="small">${page} / ${pages}</span>
    <button class="btn btn-sm" data-page="${page + 1}" ${page >= pages ? 'disabled' : ''}>${icon('chevronRight', 14)}</button>
  </div>`
}

export function bindPagination(root, onPage) {
  root.querySelectorAll('[data-page]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.stopPropagation()
      const page = Number(button.dataset.page)
      if (page > 0) onPage(page)
    })
  })
}

export function skeletonRows(count = 6) {
  return Array.from({ length: count }, () => `
    <tr><td><div class="skeleton sk-line" style="width:65%"></div></td>
    <td><div class="skeleton sk-line" style="width:40%"></div></td>
    <td><div class="skeleton sk-line" style="width:55%"></div></td>
    <td><div class="skeleton sk-line" style="width:35%"></div></td>
    <td><div class="skeleton sk-line" style="width:45%"></div></td></tr>`).join('')
}

export function applyTheme(theme = state.theme) {
  state.theme = theme
  document.documentElement.dataset.theme = theme
  localStorage.setItem('crm-theme', theme)
}

export function toggleTheme() {
  applyTheme(state.theme === 'dark' ? 'light' : 'dark')
}
