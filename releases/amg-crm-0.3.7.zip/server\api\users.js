import { db } from '../db.js'
import { audit } from '../audit.js'
import { PERMISSIONS, publicUser, requirePermission, requireUser } from '../auth.js'
import { HttpError } from '../http.js'
import { hashPassword } from '../security.js'
import { emailOf, idOf, oneOf, optionalText, text } from '../validate.js'

const ROLES = ['admin', 'manager', 'viewer']
const MIN_PASSWORD = 4

/** Логин: латиница/кириллица, цифры, дефис, точка, подчёркивание. */
function loginOf(value) {
  const raw = String(value ?? '').trim().toLowerCase().replace(/\s+/g, '-')
  if (!raw) return null
  if (!/^[a-zа-яё0-9._-]{2,40}$/i.test(raw)) {
    throw new HttpError(400, 'Логин: 2–40 символов — буквы, цифры, дефис, точка или подчёркивание', 'VALIDATION')
  }
  return raw
}

/** Свободный служебный e-mail для учётной записи без почты. */
function freeEmail(login) {
  let email = `${login}@amg-crm.local`
  let index = 1
  while (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) {
    email = `${login}${index}@amg-crm.local`
    index += 1
  }
  return email
}

export function registerUserRoutes(router) {
  router.get('/api/users', async ({ user }) => {
    requireUser({ user })
    const rows = db.prepare(`SELECT u.*,
      (SELECT COUNT(*) FROM tasks t WHERE t.assignee_id = u.id AND t.status != 'done') AS open_tasks,
      (SELECT COUNT(*) FROM companies c WHERE c.owner_id = u.id) AS companies_count
      FROM users u ORDER BY u.is_active DESC, u.name COLLATE NOCASE`).all()
    return {
      items: rows.map((row) => ({
        ...publicUser(row),
        openTasks: row.open_tasks,
        companiesCount: row.companies_count,
        permissions: PERMISSIONS[row.role],
      })),
    }
  })

  router.post('/api/users', async ({ body, user }) => {
    const actor = requirePermission({ user }, 'manageUsers')
    const name = text(body.name, 'Имя', { max: 120 })
    const role = oneOf(body.role ?? 'manager', ROLES, 'role')
    const password = String(body.password ?? '')
    if (password.length < MIN_PASSWORD) {
      throw new HttpError(400, `Пароль должен быть не короче ${MIN_PASSWORD} символов`, 'VALIDATION')
    }
    const phone = optionalText(body.phone, 'Телефон', { max: 40 })
    const declaredLogin = loginOf(body.login) ?? loginOf(String(body.email ?? '').split('@')[0]) ?? loginOf(name)
    if (!declaredLogin) throw new HttpError(400, 'Укажите логин', 'VALIDATION')

    const email = body.email ? emailOf(body.email) : freeEmail(declaredLogin)
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) {
      throw new HttpError(409, 'Пользователь с таким e-mail уже есть', 'DUPLICATE')
    }
    if (db.prepare('SELECT 1 FROM users WHERE lower(login) = lower(?)').get(declaredLogin)) {
      throw new HttpError(409, 'Такой логин уже занят', 'DUPLICATE')
    }

    const res = db.prepare(`INSERT INTO users (email, login, name, password_hash, role, phone, is_active, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 1, ?)`).run(
      email, declaredLogin, name, hashPassword(password), role, phone, new Date().toISOString(),
    )
    const id = Number(res.lastInsertRowid)
    audit(actor.id, 'create', 'user', id, { email, login: declaredLogin, role })
    return { item: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id)) }
  })

  router.patch('/api/users/:id', async ({ body, params, user }) => {
    const actor = requirePermission({ user }, 'manageUsers')
    const id = idOf(params.id)
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(id)
    if (!row) throw new HttpError(404, 'Пользователь не найден', 'NOT_FOUND')

    const name = body.name === undefined ? row.name : text(body.name, 'Имя', { max: 120 })
    const role = body.role === undefined ? row.role : oneOf(body.role, ROLES, 'role')
    const phone = body.phone === undefined ? row.phone : optionalText(body.phone, 'Телефон', { max: 40 })
    const isActive = body.isActive === undefined ? row.is_active : (body.isActive ? 1 : 0)

    let login = row.login
    if (body.login !== undefined) {
      const nextLogin = loginOf(body.login)
      if (nextLogin && nextLogin !== row.login) {
        if (db.prepare('SELECT 1 FROM users WHERE lower(login) = lower(?) AND id != ?').get(nextLogin, id)) {
          throw new HttpError(409, 'Такой логин уже занят', 'DUPLICATE')
        }
        login = nextLogin
      }
    }

    if (row.role === 'admin' && (role !== 'admin' || isActive === 0)) {
      const admins = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND is_active = 1").get().c
      if (admins <= 1) throw new HttpError(400, 'В системе должен остаться хотя бы один активный администратор', 'LAST_ADMIN')
    }
    if (id === actor.id && isActive === 0) throw new HttpError(400, 'Нельзя отключить собственную учётную запись', 'SELF')

    if (body.password !== undefined && String(body.password).length > 0) {
      const password = String(body.password)
      if (password.length < MIN_PASSWORD) {
        throw new HttpError(400, `Пароль должен быть не короче ${MIN_PASSWORD} символов`, 'VALIDATION')
      }
      db.prepare('UPDATE users SET login = ?, name = ?, role = ?, phone = ?, is_active = ?, password_hash = ? WHERE id = ?')
        .run(login, name, role, phone, isActive, hashPassword(password), id)
      db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id)
      audit(actor.id, 'reset-password', 'user', id)
    } else {
      db.prepare('UPDATE users SET login = ?, name = ?, role = ?, phone = ?, is_active = ? WHERE id = ?')
        .run(login, name, role, phone, isActive, id)
    }
    if (isActive === 0) db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id)
    audit(actor.id, 'update', 'user', id, { role, isActive: Boolean(isActive) })
    return { item: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id)) }
  })

  router.delete('/api/users/:id', async ({ params, user }) => {
    const actor = requirePermission({ user }, 'manageUsers')
    const id = idOf(params.id)
    if (id === actor.id) throw new HttpError(400, 'Нельзя удалить собственную учётную запись', 'SELF')
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(id)
    if (!row) throw new HttpError(404, 'Пользователь не найден', 'NOT_FOUND')
    if (row.role === 'admin') {
      const admins = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND is_active = 1").get().c
      if (admins <= 1) throw new HttpError(400, 'Нельзя удалить последнего администратора', 'LAST_ADMIN')
    }
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id)
    db.prepare('DELETE FROM users WHERE id = ?').run(id)
    audit(actor.id, 'delete', 'user', id, { email: row.email })
    return { ok: true }
  })
}
