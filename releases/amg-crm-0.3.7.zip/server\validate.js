import { HttpError } from './http.js'

/** Require a trimmed non-empty string. */
export function text(value, field, { max = 500, min = 1 } = {}) {
  const result = String(value ?? '').trim()
  if (result.length < min) throw new HttpError(400, `Поле «${field}» обязательно`, 'VALIDATION')
  if (result.length > max) throw new HttpError(400, `Поле «${field}» длиннее ${max} символов`, 'VALIDATION')
  return result
}

/** Optional trimmed string, normalised to null when blank. */
export function optionalText(value, field, { max = 2000 } = {}) {
  if (value === undefined || value === null) return null
  const result = String(value).trim()
  if (result.length === 0) return null
  if (result.length > max) throw new HttpError(400, `Поле «${field}» длиннее ${max} символов`, 'VALIDATION')
  return result
}

export function oneOf(value, allowed, field, fallback = undefined) {
  if (value === undefined || value === null || value === '') {
    if (fallback !== undefined) return fallback
    throw new HttpError(400, `Поле «${field}» обязательно`, 'VALIDATION')
  }
  const normalized = String(value)
  if (!allowed.includes(normalized)) throw new HttpError(400, `Недопустимое значение «${field}»`, 'VALIDATION')
  return normalized
}

/** Positive integer id or null. */
export function idOrNull(value, field = 'id') {
  if (value === undefined || value === null || value === '') return null
  const number = Number(value)
  if (!Number.isInteger(number) || number <= 0) throw new HttpError(400, `Некорректный «${field}»`, 'VALIDATION')
  return number
}

export function idOf(value, field = 'id') {
  const result = idOrNull(value, field)
  if (result === null) throw new HttpError(400, `Некорректный «${field}»`, 'VALIDATION')
  return result
}

/** ISO timestamp from an ISO string, or null. */
export function isoOrNull(value, field = 'дата') {
  if (value === undefined || value === null || value === '') return null
  const time = Date.parse(String(value))
  if (Number.isNaN(time)) throw new HttpError(400, `Некорректная ${field}`, 'VALIDATION')
  return new Date(time).toISOString()
}

export function oneOfNullable(value, allowed, field) {
  if (value === undefined || value === null || value === '') return null
  return oneOf(value, allowed, field)
}

export function clampInt(value, { min = 1, max = 100, fallback = 25 } = {}) {
  const number = Number.parseInt(String(value ?? ''), 10)
  if (!Number.isFinite(number)) return fallback
  return Math.min(max, Math.max(min, number))
}

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export function emailOf(value, field = 'email') {
  const result = text(value, field, { max: 200 }).toLowerCase()
  if (!EMAIL_RE.test(result)) throw new HttpError(400, 'Некорректный e-mail', 'VALIDATION')
  return result
}

export function optionalEmail(value, field = 'email') {
  const result = optionalText(value, field, { max: 200 })
  if (result === null) return null
  if (!EMAIL_RE.test(result)) throw new HttpError(400, 'Некорректный e-mail', 'VALIDATION')
  return result.toLowerCase()
}
