import { db } from './db.js'

/** Write one audit-log entry. Never throws into the request path. */
export function audit(actorId, action, entityType, entityId = null, meta = null) {
  try {
    db.prepare(`INSERT INTO audit_log (actor_id, action, entity_type, entity_id, meta, created_at)
      VALUES (?, ?, ?, ?, ?, ?)`)
      .run(actorId ?? null, action, entityType, entityId ?? null, meta ? JSON.stringify(meta) : null, new Date().toISOString())
  } catch (error) {
    console.error('[crm] audit failed:', error.message)
  }
}

/** Append a timeline entry for a company, contact or task. */
export function logActivity(entityType, entityId, kind, body, userId) {
  db.prepare(`INSERT INTO activities (entity_type, entity_id, kind, body, user_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?)`)
    .run(entityType, entityId, kind, body, userId ?? null, new Date().toISOString())
}
