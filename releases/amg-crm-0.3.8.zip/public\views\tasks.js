/* Задачи: канбан с перетаскиванием, фильтры и быстрые действия. */
import {
  TASK_PRIORITY, TASK_STATUS, api, avatar, dueMeta, emptyState, esc, icon, plural, state, toast,
} from '../lib.js'
import { loadUsers, openTaskForm } from './forms.js'

const STORE_NAMES = {
  pargolovo: 'Парголово',
  'dunaysky-27k1': 'Дунайский 27к1',
  pushkino: 'Пушкино',
  krasnodar: 'Краснодар',
  'kaliningrad-1': 'Калининград 1',
  'kaliningrad-2': 'Калининград 2',
}

const COLUMNS = [
  { status: 'todo', title: 'К выполнению' },
  { status: 'doing', title: 'В работе' },
  { status: 'done', title: 'Готово' },
]

export default {
  subtitle: () => 'Что нужно сделать сегодня',
  async render(ctx) {
    const mine = ctx.query.get('mine') === '1'
    const day = ctx.query.get('day') ?? 'today'
    const assignee = ctx.query.get('assigneeId') ?? 'all'
    const q = ctx.query.get('q') ?? ''
    const canWrite = state.permissions?.write
    const canDelete = Boolean(state.permissions?.manageUsers)
    const refresh = () => {
      document.dispatchEvent(new Event('crm:tasks-changed'))
      ctx.refresh()
    }
    const users = await loadUsers()

    ctx.root.innerHTML = `
      <div class="page-head">
        <div><h2>Задачи на сегодня</h2><div class="hint" id="task-hint">Загружаем…</div></div>
        <div class="actions">
          ${canWrite ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Новая задача</button>` : ''}
        </div>
      </div>

      <div class="toolbar">
        <div class="segmented" id="day">
          <button data-day="today" class="${day === 'today' ? 'active' : ''}">На сегодня</button>
          <button data-day="all" class="${day === 'all' ? 'active' : ''}">Все</button>
        </div>
        <div class="segmented" id="scope">
          <button data-mine="1" class="${mine ? '' : 'active'}">Все задачи</button>
          <button data-mine="0" class="${mine ? 'active' : ''}">Мои задачи</button>
        </div>
        <div class="search" style="width:250px">${icon('search', 15)}
          <input id="q" type="search" placeholder="Поиск по задачам…" value="${esc(q)}" />
        </div>
        <select class="select" id="assignee" style="width:auto;min-width:180px">
          <option value="all">Все исполнители</option>
          ${users.map((user) => `<option value="${user.id}" ${String(assignee) === String(user.id) ? 'selected' : ''}>${esc(user.name)}</option>`).join('')}
        </select>
        <div class="spacer"></div>
        <span class="small muted" id="counts"></span>
      </div>

      <div class="board" id="board">
        ${COLUMNS.map((column) => `
          <div class="board-col" data-status="${column.status}">
            <div class="board-col-head">
              <span class="title">${column.title}</span>
              <span class="count" data-count="${column.status}">0</span>
              ${canWrite && column.status !== 'done' ? `<button class="icon-btn" style="width:26px;height:26px;margin-left:4px" data-add="${column.status}" title="Добавить">${icon('plus', 14)}</button>` : ''}
            </div>
            <div class="board-cards" data-cards="${column.status}"></div>
          </div>`).join('')}
      </div>`

    const reload = (changes) => {
      const next = { mine: mine ? '1' : '', assigneeId: assignee === 'all' ? '' : assignee, q, day, ...changes }
      const params = new URLSearchParams()
      if (next.mine) params.set('mine', '1')
      if (next.assigneeId) params.set('assigneeId', next.assigneeId)
      if (next.q) params.set('q', next.q)
      if (next.day && next.day !== 'today') params.set('day', next.day)
      ctx.navigate(`/tasks${params.toString() ? `?${params.toString()}` : ''}`)
    }

    let timer = null
    ctx.root.querySelector('#q').addEventListener('input', (event) => {
      clearTimeout(timer)
      const value = event.target.value.trim()
      timer = setTimeout(() => reload({ q: value }), 350)
    })
    ctx.root.querySelector('#assignee').addEventListener('change', (event) => reload({ assigneeId: event.target.value }))
    ctx.root.querySelectorAll('#day button').forEach((button) => {
      button.addEventListener('click', () => reload({ day: button.dataset.day }))
    })
    ctx.root.querySelectorAll('#scope button').forEach((button) => {
      button.addEventListener('click', () => reload({ mine: button.dataset.mine === '1' ? '1' : '' }))
    })
    ctx.root.querySelectorAll('[data-act="new"]').forEach((button) => {
      button.addEventListener('click', () => openTaskForm(null, refresh))
    })
    ctx.root.querySelectorAll('[data-add]').forEach((button) => {
      button.addEventListener('click', async () => {
        const status = button.dataset.add
        await openTaskForm(null, refresh, { status })
      })
    })

    const params = new URLSearchParams({ scope: 'all' })
    if (mine) params.set('assigneeId', String(state.user.id))
    else if (assignee !== 'all') params.set('assigneeId', assignee)
    if (q) params.set('q', q)

    const data = await api(`/api/tasks?${params.toString()}`)
    const startToday = new Date(); startToday.setHours(0, 0, 0, 0)
    const endToday = new Date(startToday); endToday.setDate(endToday.getDate() + 1)
    const items = day === 'today'
      ? data.items.filter((task) => (task.status === 'done'
        ? task.completed_at && new Date(task.completed_at) >= startToday
        : task.due_at && new Date(task.due_at) < endToday))
      : data.items
    const openTask = ctx.query.get('task')

    const counts = { todo: 0, doing: 0, done: 0 }
    items.forEach((task) => { counts[task.status] += 1 })
    ctx.root.querySelector('#task-hint').textContent =
      `${counts.todo + counts.doing} в работе · ${counts.done} выполнено`
    ctx.root.querySelector('#counts').textContent =
      `${items.length} ${plural(items.length, ['задача', 'задачи', 'задач'])}`

    const renderCard = (task) => {
      const due = dueMeta(task.due_at, task.status)
      const initialsName = task.assignee_name ?? ''
      return `<div class="task-card prio-${task.priority} ${task.status === 'done' ? 'done' : ''}"
          draggable="${canWrite && task.status !== 'done'}" data-task="${task.id}">
        <span class="prio"></span>
        <div class="title">${esc(task.order_1c ? "№ " + task.order_1c : task.title)}</div>
        <div class="meta">
          ${task.store ? `<span class="row" style="gap:4px">${icon('building', 12)} ${esc(STORE_NAMES[task.store] ?? task.store)}</span>` : ''}
          ${task.phone ? `<a class="row" href="tel:${esc(task.phone)}" style="gap:4px;color:inherit;text-decoration:none">${icon('phone', 12)} ${esc(task.phone)}</a>` : ''}
          ${task.due_at ? `<span class="due ${due.cls}">${icon('clock', 12)} ${esc(due.text)}</span>` : ''}
          ${task.priority === 'high' ? '<span class="pill danger plain" style="padding:0 6px">важно</span>' : ''}
          <span class="spacer"></span>
          ${canDelete ? `<button class="task-del" type="button" data-del="${task.id}" title="Удалить задачу">${icon('trash', 13)}</button>` : ''}
          ${initialsName ? `<span title="${esc(initialsName)}">${avatar(initialsName, { size: 'sm' })}</span>` : ''}
        </div>
      </div>`
    }

    COLUMNS.forEach((column) => {
      const target = ctx.root.querySelector(`[data-cards="${column.status}"]`)
      const tasks = items.filter((task) => task.status === column.status)
      ctx.root.querySelector(`[data-count="${column.status}"]`).textContent = String(tasks.length)
      target.innerHTML = tasks.length === 0
        ? `<div class="empty" style="padding:18px 8px;font-size:12px">
            ${icon(column.status === 'done' ? 'check' : 'kanban', 20)}
            <p>${column.status === 'done' ? 'Пока пусто' : 'Перетащите задачу сюда'}</p>
          </div>`
        : tasks.map(renderCard).join('')
    })

    if (items.length === 0) {
      ctx.root.querySelector('#board').innerHTML = `<div class="card" style="grid-column:1/-1">${emptyState({
        iconName: 'kanban',
        title: q ? 'Задачи не найдены' : 'Задач пока нет',
        text: q ? 'Попробуйте другой запрос или сбросьте фильтры.' : 'Создайте первую задачу — и распределите её по исполнителям.',
        action: canWrite ? `<button class="btn btn-primary" data-act="new">${icon('plus', 16)} Создать задачу</button>` : '',
      })}</div>`
      ctx.root.querySelectorAll('[data-act="new"]').forEach((button) => {
        button.addEventListener('click', () => openTaskForm(null, refresh))
      })
      return
    }

    /* Удаление задачи (только администратор) */
    ctx.root.querySelectorAll('[data-del]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.stopPropagation()
        const task = items.find((item) => String(item.id) === button.dataset.del)
        if (!task) return
        const { confirmDialog } = await import('../lib.js')
        if (!await confirmDialog({ title: 'Удалить задачу?', message: `«${task.title}» будет удалена.` })) return
        try {
          await api(`/api/tasks/${task.id}`, { method: 'DELETE' })
          toast('Задача удалена')
          refresh()
        } catch (error) {
          toast(error.message, 'error')
        }
      })
    })

    /* Перетаскивание между колонками */
    ctx.root.querySelectorAll('[data-task]').forEach((card) => {
      card.addEventListener('dragstart', (event) => {
        event.dataTransfer.setData('text/plain', card.dataset.task)
        event.dataTransfer.effectAllowed = 'move'
        card.classList.add('dragging')
      })
      card.addEventListener('dragend', () => card.classList.remove('dragging'))
      card.addEventListener('click', (event) => {
        if (event.target.closest('[data-toggle]') || event.target.closest('[data-del]')) return
        const task = items.find((item) => String(item.id) === card.dataset.task)
        if (canWrite) openTaskForm(task, refresh)
      })
    })

    ctx.root.querySelectorAll('.board-col[data-status]').forEach((column) => {
      column.addEventListener('dragover', (event) => {
        event.preventDefault()
        column.classList.add('drop-target')
      })
      column.addEventListener('dragleave', (event) => {
        if (!column.contains(event.relatedTarget)) column.classList.remove('drop-target')
      })
      column.addEventListener('drop', async (event) => {
        event.preventDefault()
        column.classList.remove('drop-target')
        const id = event.dataTransfer.getData('text/plain')
        if (!id) return
        const status = column.dataset.status
        const task = items.find((item) => String(item.id) === id)
        if (!task || task.status === status) return
        try {
          await api(`/api/tasks/${id}`, { method: 'PATCH', body: { status } })
          toast(`Статус: ${TASK_STATUS[status]}`)
          refresh()
        } catch (error) {
          toast(error.message, 'error')
        }
      })
    })

    if (openTask) {
      const task = items.find((item) => String(item.id) === openTask)
        ?? (await api(`/api/tasks/${openTask}`).catch(() => null))?.item
      if (task) openTaskForm(task, refresh)
    }
  },
}
