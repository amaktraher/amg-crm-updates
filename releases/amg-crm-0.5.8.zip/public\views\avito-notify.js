/* Оповещение о новом чате Авито: строка в списке + короткий тост. */
import { api, toast } from '../lib.js'

const shown = new Set()

export async function checkNewAvitoChats() {
  try {
    const data = await api('/api/avito-chats?new=1')
    const fresh = (data.items ?? []).filter((item) => !shown.has(item.id))
    if (fresh.length === 0) return
    for (const item of fresh) shown.add(item.id)
    const first = fresh[0]
    toast(fresh.length === 1
      ? `Новый чат Авито: ${first.buyer_name ?? 'клиент'}`
      : `Новых чатов Авито: ${fresh.length}`)
    document.dispatchEvent(new CustomEvent('crm:avito-chat'))
  } catch {
    /* уведомления не должны мешать работе */
  }
}
