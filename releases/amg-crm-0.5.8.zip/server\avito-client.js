/**
 * Клиент Авито API. Только чтение.
 *
 * Жёсткие правила:
 *  1. Разрешены только GET-запросы по белому списку адресов из READ_ONLY_PATHS.
 *  2. Единственное исключение — получение токена (POST /token), он денег не тратит.
 *  3. Любой другой адрес или метод блокируется до выхода в сеть.
 *  4. Все обращения пишутся в журнал avito-requests.log рядом с базой.
 */
import { appendFile } from 'node:fs/promises'
import { join } from 'node:path'

const BASE = 'https://api.avito.ru'

/** Белый список только тех адресов, которые нужны для чтения чатов. */
const READ_ONLY_PATHS = [
  /^\/core\/v1\/accounts\/self$/,
  /^\/messenger\/v2\/accounts\/\d+\/chats(\?.*)?$/,
  /^\/messenger\/v2\/accounts\/\d+\/chats\/[^/?]+(\?.*)?$/,
  /^\/messenger\/v2\/accounts\/\d+\/chats\/[^/?]+\/messages(\?.*)?$/,
  /^\/core\/v1\/items\/\d+$/,
  /^\/core\/v1\/user$/,
]

function logPath() {
  const dir = process.env.CRM_DATA_DIR ?? join(process.env.LOCALAPPDATA ?? '', 'AMG-CRM', 'data')
  return join(dir, 'avito-requests.log')
}

async function log(line) {
  try {
    await appendFile(logPath(), `${new Date().toISOString()}  ${line}\r\n`)
  } catch {
    /* журнал не должен ломать работу */
  }
}

export function isAllowedPath(path) {
  return READ_ONLY_PATHS.some((pattern) => pattern.test(path))
}

/** Получение токена: единственный POST, который делает программа. */
export async function avitoToken(clientId, clientSecret) {
  if (!clientId || !clientSecret) throw new Error('Не заданы client_id и client_secret')
  await log('POST /token (получение токена)')
  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: clientId,
    client_secret: clientSecret,
  })
  const response = await fetch(`${BASE}/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    signal: AbortSignal.timeout(20000),
  })
  if (!response.ok) throw new Error(`Авито отклонил ключи: HTTP ${response.status}`)
  const data = await response.json()
  if (!data.access_token) throw new Error('Авито не вернул токен')
  return data.access_token
}

/** Чтение данных Авито. Всё, что не в белом списке, блокируется. */
export async function avitoGet(path, token) {
  if (!isAllowedPath(path)) {
    await log(`ЗАБЛОКИРОВАНО: ${path}`)
    throw new Error('Запрос заблокирован: программа работает с Авито только на чтение')
  }
  await log(`GET ${path}`)
  const response = await fetch(BASE + path, {
    method: 'GET',
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(20000),
  })
  if (!response.ok) throw new Error(`Авито ответил HTTP ${response.status} на ${path}`)
  return await response.json()
}

/** Для проверки в тестах: список разрешённых шаблонов. */
export function allowedPaths() {
  return READ_ONLY_PATHS.map((pattern) => String(pattern))
}
