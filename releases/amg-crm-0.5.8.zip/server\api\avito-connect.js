/** Подключение к Авито: ключи доступа и проверка (только чтение). */
import { readFile, writeFile, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { db } from '../db.js'
import { audit } from '../audit.js'
import { requirePermission } from '../auth.js'
import { HttpError } from '../http.js'
import { avitoGet, avitoToken } from '../avito-client.js'

function keysPath() {
  const dir = process.env.CRM_DATA_DIR ?? join(process.env.LOCALAPPDATA ?? '', 'AMG-CRM', 'data')
  return join(dir, 'avito.json')
}

async function readKeys() {
  try {
    const raw = await readFile(keysPath(), 'utf8')
    const data = JSON.parse(raw)
    if (data.clientId && data.clientSecret) return data
  } catch {
    /* ключей нет */
  }
  return null
}

async function saveKeys(clientId, clientSecret) {
  const dir = process.env.CRM_DATA_DIR ?? join(process.env.LOCALAPPDATA ?? '', 'AMG-CRM', 'data')
  await writeFile(keysPath(), JSON.stringify({ clientId, clientSecret }, null, 2), 'utf8')
  try {
    const { chmod } = await import('node:fs/promises')
    await chmod(keysPath(), 0o600)
  } catch {
    /* windows */
  }
  void dir
}

/** Сколько чатов и с какой даты реально отдаёт Авито (ничего не записываем). */
async function probe(token) {
  const account = await avitoGet('/core/v1/accounts/self', token).catch(() => null)
  const accountId = account?.id ?? account?.user_id ?? null

  const result = {
    accountId: accountId ?? null,
    accountName: account?.name ?? null,
    chatsCount: 0,
    earliestChatAt: null,
    latestChatAt: null,
    messageDepth: null,
    sample: null,
    error: null,
  }

  if (!accountId) {
    result.error = 'Авито не вернул id аккаунта'
    return result
  }

  try {
    const chats = await avitoGet(`/messenger/v2/accounts/${accountId}/chats?limit=100&offset=0`, token)
    const items = chats?.chats ?? chats?.items ?? []
    result.chatsCount = items.length
    const dates = items
      .map((chat) => chat.created || chat.created_at || chat.updated || chat.updated_at || chat.last_message?.created)
      .filter(Boolean)
      .map((value) => new Date(value).toISOString())
      .sort()
    if (dates.length > 0) {
      result.earliestChatAt = dates[0]
      result.latestChatAt = dates[dates.length - 1]
    }
    if (items.length > 0) {
      const chat = items[0]
      const chatId = chat.id ?? chat.chat_id
      result.sample = {
        id: chatId,
        buyer: chat.users?.find((user) => user.id !== accountId)?.name ?? chat.title ?? null,
        link: chatId ? `https://www.avito.ru/messages/${chatId}` : null,
      }
      try {
        const messages = await avitoGet(`/messenger/v2/accounts/${accountId}/chats/${chatId}/messages?limit=100`, token)
        const list = messages?.messages ?? messages?.items ?? []
        result.messageDepth = list.length
      } catch (error) {
        result.messageDepth = null
        result.error = error.message
      }
    }
  } catch (error) {
    result.error = error.message
  }
  return result
}

export function registerAvitoConnectRoutes(router) {
  const admin = (user) => requirePermission({ user }, 'manageUsers')

  router.get('/api/avito-chats/connection', async ({ user }) => {
    admin(user)
    const keys = await readKeys()
    return { configured: Boolean(keys), clientId: keys ? `${String(keys.clientId).slice(0, 6)}…` : null }
  })

  router.put('/api/avito-chats/connection', async ({ body, user }) => {
    const actor = admin(user)
    const clientId = String(body.clientId ?? '').trim()
    const clientSecret = String(body.clientSecret ?? '').trim()
    if (!clientId || !clientSecret) throw new HttpError(400, 'Нужны client_id и client_secret', 'VALIDATION')
    let token
    try {
      token = await avitoToken(clientId, clientSecret)
    } catch (error) {
      throw new HttpError(400, error.message, 'AVITO_AUTH')
    }
    const info = await probe(token)
    await saveKeys(clientId, clientSecret)
    audit(actor.id, 'update', 'avito_keys', null, { accountId: info.accountId })
    return { ok: true, probe: info }
  })

  router.delete('/api/avito-chats/connection', async ({ user }) => {
    const actor = admin(user)
    await rm(keysPath(), { force: true })
    audit(actor.id, 'delete', 'avito_keys', null, {})
    return { ok: true }
  })

  router.post('/api/avito-chats/probe', async ({ user }) => {
    admin(user)
    const keys = await readKeys()
    if (!keys) throw new HttpError(400, 'Ключи Авито не заданы', 'AVITO_KEYS')
    const token = await avitoToken(keys.clientId, keys.clientSecret)
    return { ok: true, probe: await probe(token) }
  })

  void db
}
