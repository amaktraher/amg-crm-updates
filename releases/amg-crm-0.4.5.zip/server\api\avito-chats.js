/** Авито — все чаты: карточки обращений из чатов Авито. */
import { db } from '../db.js'
import { audit } from '../audit.js'
import { requirePermission } from '../auth.js'
import { HttpError } from '../http.js'
import { idOf, isoOrNull, oneOf, optionalText, text } from '../validate.js'

export const AVITO_STATUSES = ['in_work', 'done', 'postponed', 'refused', 'no_answer', 'not_target', 'opt']
export const AVITO_STORES = ['pargolovo', 'dunaysky-27k1', 'pushkino', 'krasnodar', 'kaliningrad-1', 'kaliningrad-2']

const SELECT = `SELECT * FROM avito_chats`

function row(payload, existing = null) {
  const now = new Date().toISOString()
  const status = payload.status === undefined
    ? (existing?.status ?? 'in_work')
    : oneOf(payload.status, AVITO_STATUSES, 'статус')
  return {
    startedAt: payload.startedAt === undefined ? (existing?.started_at ?? now) : (isoOrNull(payload.startedAt, 'дата начала') ?? now),
    chatUrl: payload.chatUrl === undefined ? existing?.chat_url ?? null : optionalText(payload.chatUrl, 'ссылка на чат', { max: 500 }),
    buyerName: payload.buyerName === undefined ? existing?.buyer_name ?? null : optionalText(payload.buyerName, 'имя собеседника', { max: 120 }),
    store: payload.store === undefined
      ? existing?.store ?? null
      : (payload.store ? oneOf(payload.store, AVITO_STORES, 'магазин') : null),
    listingPrice: payload.listingPrice === undefined ? Number(existing?.listing_price ?? 0) : Number(payload.listingPrice) || 0,
    listingTitle: payload.listingTitle === undefined ? existing?.listing_title ?? null : optionalText(payload.listingTitle, 'название объявления', { max: 300 }),
    order1c: payload.order1c === undefined ? existing?.order_1c ?? null : optionalText(payload.order1c, 'номер заказа 1С', { max: 60 }),
    orderPrice: payload.orderPrice === undefined ? Number(existing?.order_price ?? 0) : Number(payload.orderPrice) || 0,
    status,
    refuseReason: payload.refuseReason === undefined ? existing?.refuse_reason ?? null : optionalText(payload.refuseReason, 'причина отказа', { max: 300 }),
    comment: payload.comment === undefined ? existing?.comment ?? null : optionalText(payload.comment, 'комментарий', { max: 2000 }),
    lastActivityAt: now,
  }
}

/** Устойчивый ключ чата: id канала из ссылки или переданный externalId. */
function chatKeyOf(chatUrl, externalId) {
  if (externalId) return String(externalId).trim().slice(0, 120)
  const match = String(chatUrl ?? '').match(/(?:channel\/|\/messages\/)([A-Za-z0-9_~-]+)/)
  return match ? match[1] : ''
}

function findExisting(key, chatUrl) {
  if (key) {
    const byKey = db.prepare('SELECT * FROM avito_chats WHERE external_id = ?').get(key)
    if (byKey) return byKey
  }
  if (chatUrl) {
    const byUrl = db.prepare('SELECT * FROM avito_chats WHERE chat_url = ?').get(chatUrl)
    if (byUrl) return byUrl
  }
  return null
}

function changedActivity(payload) {
  return payload.status !== undefined || payload.comment !== undefined
}

export function registerAvitoChatRoutes(router) {
  const admin = (user) => requirePermission({ user }, 'manageUsers')

  router.get('/api/avito-chats/options', async ({ user }) => {
    admin(user)
    return { statuses: AVITO_STATUSES, stores: AVITO_STORES }
  })

  router.get('/api/avito-chats', async ({ query, user }) => {
    admin(user)
    const where = []
    const params = []
    const status = query.get('status')
    if (status && AVITO_STATUSES.includes(status)) {
      where.push('status = ?')
      params.push(status)
    }
    const store = query.get('store')
    if (store) {
      where.push('store = ?')
      params.push(store)
    }
    const onlyNew = query.get('new')
    if (onlyNew === '1') where.push('store IS NULL')
    const search = (query.get('q') ?? '').trim()
    if (search) {
      where.push('(buyer_name LIKE ? OR listing_title LIKE ? OR order_1c LIKE ? OR comment LIKE ?)')
      const like = `%${search}%`
      params.push(like, like, like, like)
    }
    const sql = `${SELECT}${where.length ? ' WHERE ' + where.join(' AND ') : ''} ORDER BY last_activity_at DESC LIMIT 500`
    const items = db.prepare(sql).all(...params)
    const stats = {
      total: items.length,
      newChats: items.filter((item) => !item.store).length,
      inWork: items.filter((item) => item.status === 'in_work').length,
      done: items.filter((item) => item.status === 'done').length,
      refused: items.filter((item) => item.status === 'refused').length,
      revenue: items.filter((item) => item.status === 'done').reduce((sum, item) => sum + (item.order_price || 0), 0),
    }
    return { items, stats }
  })

  router.post('/api/avito-chats', async ({ body, user }) => {
    const actor = admin(user)
    const now = new Date().toISOString()
    const data = row({ ...body, startedAt: body.startedAt ?? now }, null)
    const key = chatKeyOf(data.chatUrl, body.externalId)

    // Дублей быть не должно: если такой чат уже есть — возвращаем его
    const existing = findExisting(key, data.chatUrl)
    if (existing) {
      return { item: existing, duplicate: true }
    }

    const res = db.prepare(`INSERT INTO avito_chats
      (external_id, started_at, chat_url, buyer_name, store, listing_price, listing_title, order_1c, order_price,
       status, refuse_reason, comment, last_activity_at, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(key || null, data.startedAt, data.chatUrl, data.buyerName, data.store, data.listingPrice,
        data.listingTitle, data.order1c, data.orderPrice, data.status, data.refuseReason, data.comment,
        data.lastActivityAt, now, now)
    const id = Number(res.lastInsertRowid)
    audit(actor.id, 'create', 'avito_chat', id, { buyer: data.buyerName })
    return { item: db.prepare(`${SELECT} WHERE id = ?`).get(id) }
  })

  router.patch('/api/avito-chats/:id', async ({ body, params, user }) => {
    const actor = admin(user)
    const id = idOf(params.id)
    const existing = db.prepare(`${SELECT} WHERE id = ?`).get(id)
    if (!existing) throw new HttpError(404, 'Чат не найден', 'NOT_FOUND')
    const data = row(body, existing)
    const activity = changedActivity(body) ? new Date().toISOString() : existing.last_activity_at
    db.prepare(`UPDATE avito_chats SET started_at = ?, chat_url = ?, buyer_name = ?, store = ?, listing_price = ?,
      listing_title = ?, order_1c = ?, order_price = ?, status = ?, refuse_reason = ?, comment = ?,
      last_activity_at = ?, updated_at = ? WHERE id = ?`)
      .run(data.startedAt, data.chatUrl, data.buyerName, data.store, data.listingPrice, data.listingTitle,
        data.order1c, data.orderPrice, data.status, data.refuseReason, data.comment, activity,
        new Date().toISOString(), id)
    audit(actor.id, 'update', 'avito_chat', id, { status: data.status })
    return { item: db.prepare(`${SELECT} WHERE id = ?`).get(id) }
  })

  router.delete('/api/avito-chats/:id', async ({ params, user }) => {
    const actor = admin(user)
    const id = idOf(params.id)
    const existing = db.prepare('SELECT buyer_name FROM avito_chats WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Чат не найден', 'NOT_FOUND')
    db.prepare('DELETE FROM avito_chats WHERE id = ?').run(id)
    audit(actor.id, 'delete', 'avito_chat', id, { buyer: existing.buyer_name })
    return { ok: true }
  })

  /**
   * Приём чатов из Авито (внешняя интеграция).
   * Токен задаётся в переменной окружения AVITO_IMPORT_TOKEN.
   */
  router.post('/api/avito-chats/import', async ({ body, headers }) => {
    const token = process.env.AVITO_IMPORT_TOKEN ?? ''
    if (token) {
      const given = headers['x-avito-token'] ?? ''
      if (given !== token) throw new HttpError(403, 'Неверный токен импорта', 'FORBIDDEN')
    }
    const items = Array.isArray(body.items) ? body.items : [body]
    const created = []
    let skipped = 0
    for (const item of items) {
      const data = row({ ...item, startedAt: item.startedAt ?? new Date().toISOString() }, null)
      const key = chatKeyOf(data.chatUrl, item.externalId)
      if (!key) {
        skipped += 1
        continue
      }
      const existing = findExisting(key, data.chatUrl)
      if (existing) {
        skipped += 1
        if (item.comment && item.comment !== existing.comment) {
          db.prepare('UPDATE avito_chats SET comment = ?, last_activity_at = ?, updated_at = ? WHERE id = ?')
            .run(String(item.comment), new Date().toISOString(), new Date().toISOString(), existing.id)
        }
        continue
      }
      const now = new Date().toISOString()
      const res = db.prepare(`INSERT INTO avito_chats
        (external_id, started_at, chat_url, buyer_name, store, listing_price, listing_title, order_1c, order_price,
         status, refuse_reason, comment, last_activity_at, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(key, data.startedAt, data.chatUrl, data.buyerName, data.store, data.listingPrice,
          data.listingTitle, data.order1c, data.orderPrice, data.status, data.refuseReason, data.comment, now, now, now)
      created.push(Number(res.lastInsertRowid))
    }
    return { ok: true, created: created.length, skipped, ids: created }
  })
}
