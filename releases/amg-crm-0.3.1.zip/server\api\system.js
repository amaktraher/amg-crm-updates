/** Системные настройки: версия, источник обновлений, проверка и установка обновлений. */
import { db } from '../db.js'
import { audit } from '../audit.js'
import { requirePermission, requireUser } from '../auth.js'
import { HttpError } from '../http.js'
import { appendFile, copyFile, mkdir, readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { readFileSync } from 'node:fs'

const HERE = dirname(fileURLToPath(import.meta.url))
/** Корень установленной программы. */
export const APP_DIR = resolve(HERE, '..', '..')

/** Текущая версия из файла VERSION. */
export function currentVersion() {
  try {
    return readFileSync(join(APP_DIR, 'VERSION'), 'utf8').trim() || '0.0.0'
  } catch {
    return '0.0.0'
  }
}

function defaultManifestUrl() {
  try {
    const raw = readFileSync(join(APP_DIR, 'server', 'update-default.json'), 'utf8')
    return String(JSON.parse(raw).manifestUrl ?? '').trim()
  } catch {
    return ''
  }
}

/** Источник обновлений: настройка администратора или встроенный адрес. */
function updateSource() {
  return getSetting('update.manifestUrl') || defaultManifestUrl()
}

function getSetting(key, fallback = '') {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key)
  return row?.value ?? fallback
}

function setSetting(key, value) {
  db.prepare(`INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value`).run(key, value)
}

/** Сравнение версий вида 1.2.3 (больше > 0, равно 0, меньше < 0). */
export function compareVersions(a, b) {
  const left = String(a).split('.').map((part) => Number.parseInt(part, 10) || 0)
  const right = String(b).split('.').map((part) => Number.parseInt(part, 10) || 0)
  const length = Math.max(left.length, right.length)
  for (let index = 0; index < length; index += 1) {
    const diff = (left[index] ?? 0) - (right[index] ?? 0)
    if (diff !== 0) return diff
  }
  return 0
}

/** Адрес обновлений может быть ссылкой http(s) или путём к файлу/папке в сети. */
function isRemote(url) {
  return /^https?:\/\//i.test(url)
}

/**
 * raw.githubusercontent.com отдаёт файлы из кэша несколько минут, поэтому
 * для GitHub манифест читаем через API (он всегда свежий), а raw — запасной путь.
 */
function githubApiUrl(url) {
  const match = /^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/.exec(url)
  if (!match) return null
  const [, owner, repo, branch, path] = match
  return `https://api.github.com/repos/${owner}/${repo}/contents/${path}?ref=${branch}`
}

async function readJson(source) {
  if (isRemote(source)) {
    const apiUrl = githubApiUrl(source)
    if (apiUrl) {
      try {
        const apiResponse = await fetch(apiUrl, {
          headers: { Accept: 'application/vnd.github.raw', 'User-Agent': 'AMG-CRM' },
          signal: AbortSignal.timeout(15000),
        })
        if (apiResponse.ok) return await apiResponse.json()
      } catch {
        /* пробуем обычную ссылку */
      }
    }
    const response = await fetch(source, { signal: AbortSignal.timeout(15000) })
    if (!response.ok) throw new HttpError(502, `Не удалось прочитать манифест: HTTP ${response.status}`, 'UPDATE_SOURCE')
    return await response.json()
  }
  const text = await readFile(source, 'utf8')
  return JSON.parse(text)
}

/** Путь/ссылка на архив обновления относительно манифеста. */
function resolvePayload(manifestUrl, file) {
  if (!file) throw new HttpError(502, 'В манифесте не указан файл обновления', 'UPDATE_SOURCE')
  if (isRemote(file) || /^[a-zA-Z]:[\\/]/.test(file) || file.startsWith('\\\\')) return file
  if (isRemote(manifestUrl)) return new URL(file, manifestUrl).toString()
  const slash = Math.max(manifestUrl.lastIndexOf('/'), manifestUrl.lastIndexOf('\\'))
  return manifestUrl.slice(0, slash + 1) + file
}

async function loadManifest() {
  const manifestUrl = updateSource()
  if (!manifestUrl) throw new HttpError(400, 'Источник обновлений не настроен', 'UPDATE_NOT_CONFIGURED')
  const manifest = await readJson(manifestUrl)
  const version = String(manifest.version ?? '').trim()
  if (!/^\d+\.\d+\.\d+$/.test(version)) {
    throw new HttpError(502, 'В манифесте некорректная версия (нужно вида 1.2.3)', 'UPDATE_SOURCE')
  }
  return {
    manifestUrl,
    version,
    notes: String(manifest.notes ?? ''),
    publishedAt: manifest.publishedAt ?? null,
    payload: resolvePayload(manifestUrl, manifest.file),
    sha256: String(manifest.sha256 ?? '').toLowerCase(),
  }
}

export function registerSystemRoutes(router) {
  router.get('/api/system/version', async ({ user }) => {
    requireUser({ user })
    return { version: currentVersion() }
  })

  router.get('/api/system/update', async ({ user }) => {
    requireUser({ user })
    const result = {
      current: currentVersion(),
      configured: Boolean(updateSource()),
      defaultUrl: defaultManifestUrl(),
      available: false,
      latest: null,
      notes: '',
      publishedAt: null,
      error: null,
    }
    if (!result.configured) return result
    try {
      const manifest = await loadManifest()
      result.latest = manifest.version
      result.notes = manifest.notes
      result.publishedAt = manifest.publishedAt
      result.available = compareVersions(manifest.version, result.current) > 0
    } catch (error) {
      result.error = error.message
    }
    return result
  })

  router.get('/api/system/settings', async ({ user }) => {
    requirePermission({ user }, 'manageUsers')
    return { manifestUrl: getSetting('update.manifestUrl'), version: currentVersion() }
  })

  router.put('/api/system/settings', async ({ body, user }) => {
    const actor = requirePermission({ user }, 'manageUsers')
    const manifestUrl = String(body.manifestUrl ?? '').trim().slice(0, 1000)
    setSetting('update.manifestUrl', manifestUrl)
    audit(actor.id, 'update', 'settings', null, { manifestUrl })
    return { manifestUrl }
  })

  /** Скачать обновление, проверить контрольную сумму и запустить установку. */
  router.post('/api/system/update/apply', async ({ user }) => {
    requireUser({ user })
    const manifest = await loadManifest()
    if (compareVersions(manifest.version, currentVersion()) <= 0) {
      throw new HttpError(400, 'Установлена актуальная версия', 'UPDATE_NOT_NEEDED')
    }

    const zipPath = join(tmpdir(), `amg-crm-${manifest.version}-${Date.now()}.zip`)
    if (isRemote(manifest.payload)) {
      const response = await fetch(manifest.payload, { signal: AbortSignal.timeout(120000) })
      if (!response.ok) throw new HttpError(502, `Не удалось скачать обновление: HTTP ${response.status}`, 'UPDATE_DOWNLOAD')
      await writeFile(zipPath, Buffer.from(await response.arrayBuffer()))
    } else {
      await copyFile(manifest.payload, zipPath)
    }

    if (manifest.sha256) {
      const bytes = await readFile(zipPath)
      const hash = createHash('sha256').update(bytes).digest('hex')
      if (hash !== manifest.sha256) {
        await writeFile(zipPath, '')
        throw new HttpError(502, 'Файл обновления повреждён (не совпала контрольная сумма)', 'UPDATE_CORRUPT')
      }
    }

    const updaterSource = join(APP_DIR, 'updater.ps1')
    const updaterPath = join(tmpdir(), `amg-updater-${Date.now()}.ps1`)
    await copyFile(updaterSource, updaterPath)

    const exe = join(APP_DIR, 'AMG-CRM.exe')
    const systemRoot = process.env.SystemRoot ?? 'C:\\Windows'
    const powershell = join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
    const cmd = join(systemRoot, 'System32', 'cmd.exe')
    const logPath = join(tmpdir(), 'AMG-CRM-update.log')
    const child = spawn(cmd, [
      '/c', 'start', '""', '/min', powershell,
      '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', updaterPath,
      '-Zip', zipPath, '-Target', APP_DIR, '-Exe', exe,
    ], { detached: true, stdio: 'ignore', windowsHide: true })

    child.on('error', (error) => {
      appendFile(logPath, `spawn error: ${error.message}\r\n`).catch(() => {})
    })
    child.unref()

    audit(user.id, 'update', 'system', null, { version: manifest.version })
    setTimeout(() => process.exit(0), 1200)
    return { ok: true, version: manifest.version }
  })
}
