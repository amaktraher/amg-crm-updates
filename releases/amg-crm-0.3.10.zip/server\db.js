import { DatabaseSync } from 'node:sqlite'
import { mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { hashPassword } from './security.js'

const HERE = dirname(fileURLToPath(import.meta.url))
export const DATA_DIR = process.env.CRM_DATA_DIR ?? resolve(HERE, '..', 'data')
export const DB_PATH = resolve(DATA_DIR, 'crm.db')

mkdirSync(DATA_DIR, { recursive: true })

export const db = new DatabaseSync(DB_PATH)

db.exec('PRAGMA journal_mode = WAL')
db.exec('PRAGMA foreign_keys = ON')
db.exec('PRAGMA busy_timeout = 5000')

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'manager' CHECK (role IN ('admin','manager','viewer')),
  phone         TEXT,
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL,
  last_login_at TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  user_agent TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS companies (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  industry   TEXT,
  website    TEXT,
  phone      TEXT,
  email      TEXT,
  address    TEXT,
  status     TEXT NOT NULL DEFAULT 'lead' CHECK (status IN ('lead','active','vip','archived')),
  note       TEXT,
  owner_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_companies_name ON companies(name);
CREATE INDEX IF NOT EXISTS idx_companies_status ON companies(status);
CREATE INDEX IF NOT EXISTS idx_companies_owner ON companies(owner_id);

CREATE TABLE IF NOT EXISTS contacts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
  first_name TEXT NOT NULL,
  last_name  TEXT,
  position   TEXT,
  phone      TEXT,
  email      TEXT,
  telegram   TEXT,
  is_primary INTEGER NOT NULL DEFAULT 0,
  note       TEXT,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_contacts_company ON contacts(company_id);
CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(first_name, last_name);

CREATE TABLE IF NOT EXISTS tasks (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT NOT NULL,
  description  TEXT,
  status       TEXT NOT NULL DEFAULT 'todo' CHECK (status IN ('todo','doing','done')),
  priority     TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high')),
  due_at       TEXT,
  company_id   INTEGER REFERENCES companies(id) ON DELETE SET NULL,
  contact_id   INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
  assignee_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  completed_at TEXT,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks(due_at);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee ON tasks(assignee_id);
CREATE INDEX IF NOT EXISTS idx_tasks_company ON tasks(company_id);

CREATE TABLE IF NOT EXISTS activities (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('company','contact','task')),
  entity_id   INTEGER NOT NULL,
  kind        TEXT NOT NULL DEFAULT 'note' CHECK (kind IN ('note','call','email','meeting','system')),
  body        TEXT NOT NULL,
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_activities_entity ON activities(entity_type, entity_id, created_at);

CREATE TABLE IF NOT EXISTS audit_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action      TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id   INTEGER,
  meta        TEXT,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);

CREATE TABLE IF NOT EXISTS avito_leads (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  client_name TEXT NOT NULL,
  phone       TEXT,
  item        TEXT,
  message     TEXT,
  status      TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','chat','deal','archive')),
  company_id  INTEGER REFERENCES companies(id) ON DELETE SET NULL,
  owner_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_avito_status ON avito_leads(status);
CREATE INDEX IF NOT EXISTS idx_avito_company ON avito_leads(company_id);

CREATE TABLE IF NOT EXISTS calls (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  phone        TEXT NOT NULL,
  client_name  TEXT,
  call_type    TEXT NOT NULL DEFAULT 'target' CHECK (call_type IN ('target','not_target')),
  source       TEXT NOT NULL DEFAULT 'other' CHECK (source IN ('site','avito','ads','other','questions','spam')),
  store        TEXT NOT NULL DEFAULT 'pargolovo' CHECK (store IN ('pargolovo','dunaysky-27k1','pushkino','krasnodar','kaliningrad-1','kaliningrad-2')),
  operator     TEXT NOT NULL DEFAULT 'andrey' CHECK (operator IN ('andrey','anton','robert','kirill')),
  comment      TEXT,
  order_1c     TEXT,
  order_price  REAL NOT NULL DEFAULT 0,
  status       TEXT NOT NULL DEFAULT 'accepted' CHECK (status IN ('accepted','in_work','done','refused')),
  called_at    TEXT NOT NULL,
  created_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
`

db.exec(SCHEMA)

/** Миграция: колонка login — вход по логину, а не только по e-mail. */
export function migrateUsers() {
  const columns = db.prepare('PRAGMA table_info(users)').all().map((row) => row.name)
  if (!columns.includes('login')) {
    db.exec('ALTER TABLE users ADD COLUMN login TEXT')
  }
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_login ON users(login)')
}

migrateUsers()

/** Миграция журнала звонков старого формата (направление / пропущен) в новый. */
export function migrateCalls() {
  const columns = db.prepare('PRAGMA table_info(calls)').all().map((row) => row.name)
  if (columns.length === 0 || columns.includes('call_type')) return
  db.exec('ALTER TABLE calls RENAME TO calls_legacy')
  db.exec('DROP INDEX IF EXISTS idx_calls_called')
  db.exec('DROP INDEX IF EXISTS idx_calls_company')
  db.exec(`CREATE TABLE calls (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    phone        TEXT NOT NULL,
    client_name  TEXT,
    call_type    TEXT NOT NULL DEFAULT 'target' CHECK (call_type IN ('target','not_target')),
    source       TEXT NOT NULL DEFAULT 'other' CHECK (source IN ('site','avito','ads','other','questions','spam')),
    store        TEXT NOT NULL DEFAULT 'pargolovo' CHECK (store IN ('pargolovo','dunaysky-27k1','pushkino','krasnodar','kaliningrad-1','kaliningrad-2')),
    operator     TEXT NOT NULL DEFAULT 'andrey' CHECK (operator IN ('andrey','anton','robert','kirill')),
    comment      TEXT,
    order_1c     TEXT,
    order_price  REAL NOT NULL DEFAULT 0,
    status       TEXT NOT NULL DEFAULT 'accepted' CHECK (status IN ('accepted','in_work','done','refused')),
    called_at    TEXT NOT NULL,
    created_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
  )`)
  db.exec(`INSERT INTO calls
    (phone, client_name, call_type, source, store, operator, comment, order_1c, order_price,
     status, called_at, created_by, created_at, updated_at)
    SELECT phone, client_name, 'target', 'other', 'pargolovo', 'andrey', note, NULL, 0,
      CASE status WHEN 'answered' THEN 'in_work' WHEN 'callback' THEN 'in_work' ELSE 'accepted' END,
      called_at, user_id, created_at, created_at
    FROM calls_legacy`)
  db.exec('DROP TABLE calls_legacy')
  db.exec('CREATE INDEX IF NOT EXISTS idx_calls_called ON calls(called_at)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_calls_store ON calls(store)')
  db.exec('CREATE INDEX IF NOT EXISTS idx_calls_status ON calls(status)')
}

migrateCalls()

/** Миграция задач: магазин и номер заказа 1С. */
export function migrateTasks() {
  const columns = db.prepare('PRAGMA table_info(tasks)').all().map((row) => row.name)
  if (!columns.includes('store')) db.exec('ALTER TABLE tasks ADD COLUMN store TEXT')
  if (!columns.includes('order_1c')) db.exec('ALTER TABLE tasks ADD COLUMN order_1c TEXT')
  if (!columns.includes('phone')) db.exec('ALTER TABLE tasks ADD COLUMN phone TEXT')
  if (!columns.includes('chat_url')) db.exec('ALTER TABLE tasks ADD COLUMN chat_url TEXT')
  db.exec('CREATE INDEX IF NOT EXISTS idx_tasks_store ON tasks(store)')
}

migrateTasks()

/** Магазины (учётные записи точек). */
export const STORE_ACCOUNTS = [
  ['pargolovo', 'Парголово'],
  ['dunaysky-27k1', 'Дунайский 27к1'],
  ['pushkino', 'Пушкино'],
  ['krasnodar', 'Краснодар'],
  ['kaliningrad-1', 'Калининград 1'],
  ['kaliningrad-2', 'Калининград 2'],
]

export const ADMIN_PASSWORD = '316497825'
export const STORE_PASSWORD = '12345'


const now = () => new Date().toISOString()
const iso = (d) => new Date(d).toISOString()
const daysFromNow = (n, hour = 12) => {
  const d = new Date()
  d.setDate(d.getDate() + n)
  d.setHours(hour, 0, 0, 0)
  return d.toISOString()
}

/** Insert the first administrator when the user table is empty. */
function seedUsers() {
  const count = db.prepare('SELECT COUNT(*) AS c FROM users').get().c
  if (count > 0) return
  const insert = db.prepare(`INSERT INTO users (email, name, password_hash, role, phone, created_at)
    VALUES (?, ?, ?, ?, ?, ?)`)
  const createdAt = now()
  insert.run('admin@crm.local', 'Администратор', hashPassword('Admin123!'), 'admin', '+7 900 000-00-01', createdAt)
  insert.run('maria@crm.local', 'Мария Соколова', hashPassword('Manager123!'), 'manager', '+7 900 000-00-02', createdAt)
  insert.run('oleg@crm.local', 'Олег Петров', hashPassword('Viewer123!'), 'viewer', '+7 900 000-00-03', createdAt)
  console.log('[crm] созданы пользователи: admin@crm.local / Admin123!')
}

/** Demo dataset so a fresh install never opens on empty screens. */
function seedDemo() {
  if (process.env.CRM_SEED_DEMO !== '1') return
  const count = db.prepare('SELECT COUNT(*) AS c FROM companies').get().c
  if (count > 0) return

  const admin = db.prepare("SELECT id FROM users WHERE email = 'admin@crm.local'").get()?.id ?? null
  const maria = db.prepare("SELECT id FROM users WHERE email = 'maria@crm.local'").get()?.id ?? null
  const oleg = db.prepare("SELECT id FROM users WHERE email = 'oleg@crm.local'").get()?.id ?? null

  const companies = [
    ['ООО «Северный Ветер»', 'Логистика', 'https://seveter.ru', '+7 812 555-11-22', 'info@seveter.ru', 'Санкт-Петербург, Лиговский пр., 74', 'active', 'Ключевой клиент, 3 филиала. Договор до конца года.', admin],
    ['ИП Соколов А. В.', 'Розничная торговля', null, '+7 921 444-33-55', 'sokolov@mail.ru', 'Псков, ул. Мира, 12', 'lead', 'Интересуется оптовыми поставками, первый контакт на выставке.', maria],
    ['«ТехноПарк»', 'IT и оборудование', 'https://technopark.io', '+7 495 777-88-99', 'sales@technopark.io', 'Москва, Пресненская наб., 8', 'vip', 'Крупный контракт на обслуживание, продление в декабре.', maria],
    ['ООО «Гранд Строй»', 'Строительство', null, '+7 903 222-44-66', 'office@grandstroy.ru', 'Казань, ул. Баумана, 44', 'active', 'Работаем по объектам, оплата по этапам.', oleg],
    ['Студия «Пиксель»', 'Маркетинг', 'https://pixel.studio', '+7 911 100-20-30', 'hello@pixel.studio', 'Санкт-Петербург, наб. реки Мойки, 15', 'lead', 'Запросили коммерческое предложение на пакет услуг.', maria],
    ['ООО «МедСервис»', 'Медицина', null, '+7 861 333-22-11', 'reception@medservice.ru', 'Краснодар, ул. Красная, 176', 'active', 'Поставка оборудования, ежегодное обслуживание.', admin],
    ['«Альфа Ритейл»', 'Ритейл', 'https://alfa-retail.ru', '+7 800 505-05-05', 'b2b@alfa-retail.ru', 'Москва, Ленинградский пр., 39', 'vip', 'Сетевой клиент, 12 точек. Отдельный менеджер.', maria],
    ['ООО «КлиматПро»', 'Услуги', null, '+7 342 210-30-40', 'info@climatpro.ru', 'Пермь, ул. Ленина, 58', 'archived', 'Сотрудничество приостановлено с прошлого квартала.', oleg],
  ]

  const companyIds = []
  const insertCompany = db.prepare(`INSERT INTO companies
    (name, industry, website, phone, email, address, status, note, owner_id, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
  companies.forEach((row, index) => {
    const createdAt = iso(Date.now() - (index + 2) * 86400000 * 3)
    const res = insertCompany.run(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], admin, createdAt, createdAt)
    companyIds.push(Number(res.lastInsertRowid))
  })

  const contacts = [
    [0, 'Алексей', 'Морозов', 'Директор по закупкам', '+7 812 555-11-23', 'a.morozov@seveter.ru', '@amorozov', 1],
    [0, 'Елена', 'Ковалёва', 'Логист', '+7 812 555-11-24', 'e.kovaleva@seveter.ru', null, 0],
    [1, 'Андрей', 'Соколов', 'Владелец', '+7 921 444-33-55', 'sokolov@mail.ru', '@sokolov_av', 1],
    [2, 'Дмитрий', 'Волков', 'CTO', '+7 495 777-88-90', 'd.volkov@technopark.io', '@dvolkov', 1],
    [2, 'Ирина', 'Лебедева', 'Менеджер проектов', '+7 495 777-88-91', 'i.lebedeva@technopark.io', null, 0],
    [3, 'Сергей', 'Громов', 'Прораб', '+7 903 222-44-67', 's.gromov@grandstroy.ru', null, 1],
    [4, 'Анна', 'Смирнова', 'Арт-директор', '+7 911 100-20-31', 'anna@pixel.studio', '@anna_s', 1],
    [5, 'Ольга', 'Кузнецова', 'Главный врач', '+7 861 333-22-12', 'o.kuznetsova@medservice.ru', null, 1],
    [6, 'Павел', 'Орлов', 'Категорийный менеджер', '+7 800 505-05-06', 'p.orlov@alfa-retail.ru', '@porlov', 1],
    [6, 'Наталья', 'Зайцева', 'Закупки', '+7 800 505-05-07', 'n.zaytseva@alfa-retail.ru', null, 0],
  ]
  const insertContact = db.prepare(`INSERT INTO contacts
    (company_id, first_name, last_name, position, phone, email, telegram, is_primary, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
  const contactIds = []
  contacts.forEach((c) => {
    const createdAt = iso(Date.now() - 86400000 * 10)
    const res = insertContact.run(companyIds[c[0]], c[1], c[2], c[3], c[4], c[5], c[6], c[7], admin, createdAt, createdAt)
    contactIds.push(Number(res.lastInsertRowid))
  })

  const tasks = [
    ['Позвонить Алексею Морозову по продлению договора', 'Обсудить условия на следующий год, запросить объёмы.', 'todo', 'high', daysFromNow(0, 15), 0, 0, maria],
    ['Подготовить КП для студии «Пиксель»', 'Пакет услуг: дизайн + поддержка. Смета в приложении.', 'doing', 'normal', daysFromNow(1, 11), 4, 6, maria],
    ['Встреча в «ТехноПарк»', 'Демонстрация нового модуля, обсудить SLA.', 'todo', 'high', daysFromNow(2, 10), 2, 3, admin],
    ['Счёт для «Гранд Строй» за этап 2', 'Выставить и отправить на office@grandstroy.ru.', 'todo', 'normal', daysFromNow(-1, 12), 3, 5, oleg],
    ['Собрать обратную связь по «МедСервис»', 'Опрос по качеству обслуживания за квартал.', 'todo', 'low', daysFromNow(4, 16), 5, 7, admin],
    ['Согласовать список точек «Альфа Ритейл»', '12 точек, нужен график выездов.', 'doing', 'normal', daysFromNow(3, 14), 6, 8, maria],
    ['Отправить договор ИП Соколов', 'Шаблон договора + спецификация.', 'todo', 'normal', daysFromNow(5, 12), 1, 2, maria],
    ['Проверить задолженность по «КлиматПро»', 'Закрыть долг или перевести в архив.', 'todo', 'high', daysFromNow(-3, 12), 7, null, oleg],
    ['Заполнить карточку «ТехноПарк»', 'Добавить ИНН, юр. адрес, банковские реквизиты.', 'done', 'low', daysFromNow(-2, 18), 2, 3, admin],
    ['Планёрка отдела продаж', 'Итоги недели, план на следующую.', 'done', 'normal', daysFromNow(-1, 9), null, null, admin],
    ['Онбординг: новый менеджер', 'Выдать доступы, провести по CRM.', 'doing', 'normal', daysFromNow(6, 10), null, null, admin],
    ['Обновить шаблоны писем', 'Добавить новый прайс-лист.', 'todo', 'low', daysFromNow(9, 17), null, null, maria],
  ]
  const insertTask = db.prepare(`INSERT INTO tasks
    (title, description, status, priority, due_at, company_id, contact_id, assignee_id, created_by, completed_at, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
  tasks.forEach((t) => {
    const createdAt = iso(Date.now() - 86400000 * 2)
    insertTask.run(
      t[0], t[1], t[2], t[3], t[4],
      t[5] === null ? null : companyIds[t[5]],
      t[6] === null ? null : contactIds[t[6]],
      t[7], admin,
      t[2] === 'done' ? iso(Date.now() - 3600000) : null,
      createdAt, createdAt,
    )
  })

  const insertActivity = db.prepare(`INSERT INTO activities (entity_type, entity_id, kind, body, user_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?)`)
  const demoActivities = [
    ['company', 0, 'call', 'Созвонились с Алексеем: продление договора в силе, ждут КП до пятницы.', maria, -0.2],
    ['company', 0, 'note', 'Клиент просил добавить склад в Санкт-Петербурге в зону обслуживания.', admin, -2],
    ['company', 2, 'meeting', 'Встреча в офисе: демо модуля аналитики, заинтересовались.', admin, -1],
    ['company', 2, 'email', 'Отправлен коммерческий расчёт на 12 месяцев.', maria, -3],
    ['company', 1, 'call', 'Первый звонок: нужен опт, запросили прайс-лист.', maria, -5],
    ['company', 4, 'note', 'Запросили КП на пакет «Дизайн + поддержка».', maria, -0.5],
    ['company', 6, 'meeting', 'Обсудили график выездов по 12 точкам.', maria, -4],
    ['company', 3, 'call', 'Согласовали суммы по этапу 2.', oleg, -2],
  ]
  demoActivities.forEach(([type, id, kind, body, userId, days]) => {
    insertActivity.run(type, companyIds[id], kind, body, userId, iso(Date.now() + days * 86400000))
  })

  const insertAudit = db.prepare(`INSERT INTO audit_log (actor_id, action, entity_type, entity_id, meta, created_at)
    VALUES (?, ?, ?, ?, ?, ?)`)
  insertAudit.run(admin, 'seed', 'system', null, JSON.stringify({ companies: companyIds.length }), now())
  console.log(`[crm] демо-данные: ${companyIds.length} компаний, ${contactIds.length} контактов, ${tasks.length} задач`)
}

/** Учётные записи: администратор и магазины. Существующие пароли не перезаписываются. */
function seedAccounts() {
  const createdAt = now()
  const admin = db.prepare(
    "SELECT * FROM users WHERE login = 'admin' OR email = 'admin@crm.local' ORDER BY (login = 'admin') DESC",
  ).get()

  if (admin) {
    if (admin.login !== 'admin') {
      db.prepare('UPDATE users SET login = ?, role = ?, is_active = 1, password_hash = ? WHERE id = ?')
        .run('admin', 'admin', hashPassword(ADMIN_PASSWORD), admin.id)
    }
  } else {
    db.prepare(`INSERT INTO users (email, login, name, password_hash, role, is_active, created_at)
      VALUES (?, ?, ?, ?, 'admin', 1, ?)`)
      .run('admin@amg-crm.local', 'admin', 'Администратор', hashPassword(ADMIN_PASSWORD), createdAt)
  }

  const exists = db.prepare('SELECT 1 FROM users WHERE login = ?')
  const insertStore = db.prepare(`INSERT INTO users (email, login, name, password_hash, role, is_active, created_at)
    VALUES (?, ?, ?, ?, 'manager', 1, ?)`)
  let created = 0
  for (const [login, name] of STORE_ACCOUNTS) {
    if (exists.get(login)) continue
    insertStore.run(`${login}@amg-crm.local`, login, name, hashPassword(STORE_PASSWORD), createdAt)
    created += 1
  }

  // демонстрационные учётные записи больше не используются
  db.prepare("UPDATE users SET is_active = 0 WHERE email IN ('maria@crm.local', 'oleg@crm.local')").run()

  console.log(`[crm] учётные записи: admin (администратор), магазины: ${STORE_ACCOUNTS.map(([, name]) => name).join(', ')}`)
  if (created > 0) console.log(`[crm] создано новых магазинов: ${created}`)
}

seedUsers()
seedDemo()
seedAccounts()
cleanupDemoData()

/** Демонстрационные данные из ранних версий: убираем их при запуске. */
function cleanupDemoData() {
  const demoEmails = [
    'info@seveter.ru', 'sokolov@mail.ru', 'sales@technopark.io', 'office@grandstroy.ru',
    'hello@pixel.studio', 'reception@medservice.ru', 'b2b@alfa-retail.ru', 'info@climatpro.ru',
  ]
  const demoTitles = [
    'Позвонить Алексею Морозову по продлению договора',
    'Подготовить КП для студии «Пиксель»',
    'Встреча в «ТехноПарк»',
    'Счёт для «Гранд Строй» за этап 2',
    'Собрать обратную связь по «МедСервис»',
    'Согласовать список точек «Альфа Ритейл»',
    'Отправить договор ИП Соколов',
    'Проверить задолженность по «КлиматПро»',
    'Заполнить карточку «ТехноПарк»',
    'Планёрка отдела продаж',
    'Онбординг: новый менеджер',
    'Обновить шаблоны писем',
  ]
  try {
    const marks = demoEmails.map(() => '?').join(',')
    const companies = db.prepare(`SELECT id FROM companies WHERE email IN (${marks})`).all(...demoEmails)
    const ids = companies.map((row) => row.id)
    if (ids.length > 0) {
      const idMarks = ids.map(() => '?').join(',')
      db.prepare(`DELETE FROM activities WHERE entity_type = 'company' AND entity_id IN (${idMarks})`).run(...ids)
      db.prepare(`DELETE FROM contacts WHERE company_id IN (${idMarks})`).run(...ids)
      db.prepare(`DELETE FROM tasks WHERE company_id IN (${idMarks})`).run(...ids)
      db.prepare(`DELETE FROM companies WHERE id IN (${idMarks})`).run(...ids)
    }
    const titleMarks = demoTitles.map(() => '?').join(',')
    db.prepare(`DELETE FROM tasks WHERE title IN (${titleMarks})`).run(...demoTitles)

    const demoBodies = [
      'Созвонились с Алексеем: продление договора в силе, ждут КП до пятницы.',
      'Клиент просил добавить склад в Санкт-Петербурге в зону обслуживания.',
      'Встреча в офисе: демо модуля аналитики, заинтересовались.',
      'Отправлен коммерческий расчёт на 12 месяцев.',
      'Первый звонок: нужен опт, запросили прайс-лист.',
      'Запросили КП на пакет «Дизайн + поддержка».',
      'Обсудили график выездов по 12 точкам.',
      'Согласовали суммы по этапу 2.',
    ]
    const bodyMarks = demoBodies.map(() => '?').join(',')
    db.prepare(`DELETE FROM activities WHERE body IN (${bodyMarks})`).run(...demoBodies)
    db.exec("DELETE FROM activities WHERE entity_type = 'company' AND entity_id NOT IN (SELECT id FROM companies)")
    db.exec("DELETE FROM activities WHERE entity_type = 'contact' AND entity_id NOT IN (SELECT id FROM contacts)")
    db.exec("DELETE FROM activities WHERE entity_type = 'task' AND entity_id NOT IN (SELECT id FROM tasks)")
    db.exec("DELETE FROM audit_log WHERE action = 'seed'")
    db.prepare("DELETE FROM users WHERE email IN ('maria@crm.local', 'oleg@crm.local') AND login IS NULL").run()
  } catch (error) {
    console.error('[crm] не удалось убрать демо-данные:', error.message)
  }
}

export function transaction(fn) {
  db.exec('BEGIN')
  try {
    const result = fn()
    db.exec('COMMIT')
    return result
  } catch (error) {
    db.exec('ROLLBACK')
    throw error
  }
}
