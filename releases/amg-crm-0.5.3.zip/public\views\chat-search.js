/* Поиск чата Авито по ссылке или имени — отдельное окно (Ctrl+F). */
import { api, esc, openModal, state, toast } from '../lib.js'

export function openChatSearch() {
  if (!state.permissions?.manageUsers) {
    toast('Поиск чатов доступен администратору', 'error')
    return
  }
  const { el, close } = openModal({
    title: 'Поиск чата Авито',
    sub: 'Вставьте ссылку на чат или имя собеседника',
    body: `
      <div class="field">
        <label for="chat-search-input">Ссылка на чат, id или имя</label>
        <input class="input" id="chat-search-input" placeholder="https://www.avito.ru/profile/messenger/channel/…" />
      </div>
      <div id="chat-search-results" style="margin-top:12px;display:flex;flex-direction:column;gap:6px"></div>`,
    footer: '<button class="btn" data-close type="button">Закрыть</button>'
      + '<button class="btn btn-primary" data-go type="button">Найти</button>',
  })

  const input = el.querySelector('#chat-search-input')
  const results = el.querySelector('#chat-search-results')
  input.focus()

  const openById = (id) => {
    window.__openAvitoChatId = id
    close()
    location.hash = '#/avito-chats'
  }

  const run = async () => {
    const value = input.value.trim()
    if (!value) return
    results.innerHTML = '<div class="small muted">Ищем…</div>'
    try {
      const data = await api(`/api/avito-chats?q=${encodeURIComponent(value)}`)
      const items = data.items ?? []
      if (items.length === 0) {
        results.innerHTML = '<div class="small" style="color:var(--danger)">Чат не найден</div>'
        return
      }
      const exact = items.find((item) => item.chat_url === value)
        || items.find((item) => String(item.external_id ?? '') === value)
        || (items.length === 1 ? items[0] : null)
      if (exact) {
        openById(exact.id)
        return
      }
      results.innerHTML = items.slice(0, 8).map((item) => `
        <button class="btn" data-id="${item.id}" type="button"
          style="width:100%;justify-content:flex-start;text-align:left">
          ${esc(item.buyer_name ?? 'Без имени')} · ${esc(item.listing_title ?? 'без объявления')}
        </button>`).join('')
      results.querySelectorAll('[data-id]').forEach((button) => {
        button.addEventListener('click', () => openById(button.dataset.id))
      })
    } catch (error) {
      results.innerHTML = `<div class="small" style="color:var(--danger)">${esc(error.message)}</div>`
    }
  }

  el.querySelector('[data-go]').addEventListener('click', run)
  el.querySelector('[data-close]').addEventListener('click', close)
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault()
      run()
    }
  })
}
