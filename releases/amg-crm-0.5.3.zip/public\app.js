import {
  ROLE_LABELS, api, applyTheme, avatar, dropdown, esc, icon, initials, openModal, state, toast, toggleTheme,
} from './lib.js'

import dashboardView from './views/dashboard.js'
import companiesView from './views/companies.js'
import companyView from './views/company.js'
import avitoView from './views/avito.js'
import avitoChatsView from './views/avito-chats.js'
import { checkNewAvitoChats } from './views/avito-notify.js'
import { openChatSearch } from './views/chat-search.js'
import callsView from './views/calls.js'
import contactsView from './views/contacts.js'
import tasksView from './views/tasks.js'
import calendarView from './views/calendar.js'
import teamView from './views/team.js'
import auditView from './views/audit.js'
import profileView from './views/profile.js'

const ROUTES = [
  { path: '/dashboard', title: 'Обзор', view: dashboardView, nav: 'dashboard' },
  { path: '/companies', title: 'Постоянные клиенты', view: companiesView, nav: 'companies' },
  { path: '/companies/:id', title: 'Клиент', view: companyView, nav: 'companies' },
  { path: '/avito', title: 'Авито', view: avitoView, nav: 'avito' },
  { path: '/avito-chats', title: 'Авито — все чаты', view: avitoChatsView, nav: 'avito-chats', adminOnly: true },
  { path: '/calls', title: 'Звонки', view: callsView, nav: 'calls' },
  { path: '/contacts', title: 'Люди', view: contactsView, nav: 'companies' },
  { path: '/tasks', title: 'Задачи на сегодня', view: tasksView, nav: 'tasks' },
  { path: '/calendar', title: 'Календарь', view: calendarView, nav: 'calendar' },
  { path: '/team', title: 'Команда', view: teamView, nav: 'team' },
  { path: '/audit', title: 'Журнал действий', view: auditView, nav: 'audit' },
  { path: '/profile', title: 'Профиль', view: profileView, nav: '' },
]

const root = document.getElementById('root')
let currentParams = {}

export function navigate(to) {
  const target = to.startsWith('#') ? to : `#${to}`
  if (location.hash === target) renderRoute()
  else location.hash = target
}

function parseHash() {
  const raw = location.hash.replace(/^#/, '') || '/dashboard'
  const [pathPart, queryPart] = raw.split('?')
  const path = pathPart || '/dashboard'
  const query = new URLSearchParams(queryPart ?? '')
  return { path, query }
}

function matchRoute(path) {
  const parts = path.split('/').filter(Boolean)
  for (const route of ROUTES) {
    const segments = route.path.split('/').filter(Boolean)
    if (segments.length !== parts.length) continue
    const params = {}
    let ok = true
    for (let i = 0; i < segments.length; i += 1) {
      if (segments[i].startsWith(':')) params[segments[i].slice(1)] = decodeURIComponent(parts[i])
      else if (segments[i] !== parts[i]) { ok = false; break }
    }
    if (ok) return { route, params }
  }
  return null
}

/* ── Логин ───────────────────────────────────────────────── */

function renderLogin(message = '') {
  state.user = null
  document.body.style.overflow = ''
  root.innerHTML = `
    <div class="auth">
      <aside class="auth-brand">
        <div class="row" style="gap:10px">
          <span class="brand-mark">${icon('bolt', 19)}</span>
          <div>
            <div class="brand-name">AMG-CRM</div>
              </div>
        </div>
        <div>
          <h1>Все клиенты, задачи и история — в одном месте.</h1>
          <p class="lead">Спокойная система для отдела продаж: карточки клиентов, контакты,
            задачи с календарём и полный журнал действий команды.</p>
          <div class="auth-features">
            <div class="auth-feature"><span class="ic">${icon('building', 16)}</span>
              <div><b>Клиенты и контакты</b><br/>Единая база компаний, людей, телефонов и заметок.</div></div>
            <div class="auth-feature"><span class="ic">${icon('kanban', 16)}</span>
              <div><b>Задачи и календарь</b><br/>Канбан, сроки, приоритеты и загрузка команды.</div></div>
            <div class="auth-feature"><span class="ic">${icon('shield', 16)}</span>
              <div><b>Роли и журнал</b><br/>Права администратора, менеджера и наблюдателя, аудит изменений.</div></div>
          </div>
        </div>
        <div class="auth-foot">© ${new Date().getFullYear()} AMG-CRM · локальная установка</div>
      </aside>

      <section class="auth-panel">
        <div class="auth-card">
          <h2>Вход в систему</h2>
          <p class="sub">Выберите магазин и введите пароль.</p>
          <form class="auth-form" id="login-form">
            <div class="field">
              <label for="identifier">Магазин</label>
              <select class="select" id="identifier" name="identifier" required disabled>
                <option value="">Загрузка списка…</option>
              </select>
            </div>
            <div class="field">
              <label for="password">Пароль</label>
              <input class="input" id="password" name="password" type="password" autocomplete="current-password"
                placeholder="••••••" required />
            </div>
            <div class="field" id="login-error" style="display:none">
              <span class="error"></span>
            </div>
            <button class="btn btn-primary" type="submit" id="login-submit" disabled>Войти</button>
          </form>
          <div class="auth-hint">
            Пароли магазинов выдаёт администратор. Если вашего магазина нет в списке —
            обратитесь к администратору.
          </div>
          ${message ? `<div class="field" style="margin-top:14px"><span class="error">${esc(message)}</span></div>` : ''}
        </div>
      </section>
    </div>`

  const form = root.querySelector('#login-form')
  const errorBox = root.querySelector('#login-error')
  const submit = root.querySelector('#login-submit')
  const accountSelect = root.querySelector('#identifier')

  /* Список магазинов для выбора */
  api('/api/auth/accounts').then(({ items }) => {
    const stores = items.filter((item) => item.role !== 'admin')
      .sort((a, b) => a.name.localeCompare(b.name, 'ru'))
    const admins = items.filter((item) => item.role === 'admin')
    const options = ['<option value="" selected disabled>Выберите магазин</option>']
    if (stores.length > 0) {
      options.push(`<optgroup label="Магазины">${stores.map((item) =>
        `<option value="${esc(item.login)}">${esc(item.name)}</option>`).join('')}</optgroup>`)
    }
    if (admins.length > 0) {
      options.push(`<optgroup label="Администрирование">${admins.map((item) =>
        `<option value="${esc(item.login)}">${esc(item.name)}</option>`).join('')}</optgroup>`)
    }
    accountSelect.innerHTML = options.join('')
    accountSelect.disabled = false
    submit.disabled = false
    accountSelect.focus()
  }).catch(() => {
    accountSelect.innerHTML = '<option value="">Не удалось загрузить список</option>'
  })

  accountSelect.addEventListener('change', () => {
    if (accountSelect.value) form.querySelector('#password').focus()
  })

  form.addEventListener('submit', async (event) => {
    event.preventDefault()
    errorBox.style.display = 'none'
    submit.disabled = true
    submit.innerHTML = '<span class="spinner"></span> Проверяем…'
    try {
      const result = await api('/api/auth/login', {
        method: 'POST',
        body: { identifier: form.identifier.value, password: form.password.value },
      })
      state.user = result.user
      state.permissions = result.permissions
      toast(`Добро пожаловать, ${result.user.name.split(' ')[0]}!`)
      await bootApp()
    } catch (error) {
      errorBox.style.display = ''
      errorBox.querySelector('.error').textContent = error.message
      submit.disabled = false
      submit.textContent = 'Войти'
      form.querySelector('#password').select()
    }
  })
}

/* ── Оболочка приложения ─────────────────────────────────── */

const NAV = [
  { key: 'dashboard', label: 'Обзор', icon: 'grid', to: '/dashboard' },
  { key: 'avito', label: 'Авито', icon: 'message', to: '/avito' },
  { key: 'calls', label: 'Звонки', icon: 'phone', to: '/calls' },
  { key: 'tasks', label: 'Задачи на сегодня', icon: 'kanban', to: '/tasks', badge: 'tasks' },
  { key: 'calendar', label: 'Календарь', icon: 'calendar', to: '/calendar' },
  { key: 'companies', label: 'Постоянные клиенты', icon: 'users', to: '/companies' },
]

const ADMIN_NAV = [
  { key: 'avito-chats', label: 'Авито — все чаты', icon: 'message', to: '/avito-chats', adminOnly: true },
  { key: 'team', label: 'Команда', icon: 'shield', to: '/team' },
  { key: 'audit', label: 'Журнал действий', icon: 'history', to: '/audit', adminOnly: true },
]

function sidebarLink(item) {
  return `<button class="nav-item" data-nav="${esc(item.to)}" data-key="${item.key}" type="button">
    ${icon(item.icon, 18)}<span class="label">${esc(item.label)}</span>
    ${item.badge ? `<span class="count" data-badge="${item.badge}" hidden>0</span>` : ''}
  </button>`
}

function renderShell() {
  const isAdmin = Boolean(state.permissions?.manageUsers)
  root.innerHTML = `
    <div class="app">
      <aside class="sidebar">
        <div class="brand">
          <span class="brand-mark">${icon('bolt', 19)}</span>
          <div class="brand-text">
            <div class="brand-name">AMG-CRM</div>
              </div>
        </div>
        <nav class="nav-group" id="nav-main">
          <div class="nav-label">Работа</div>
          ${NAV.map(sidebarLink).join('')}
        </nav>
        <nav class="nav-group" id="nav-admin" ${isAdmin ? '' : 'hidden'}>
          <div class="nav-label">Администрирование</div>
          ${ADMIN_NAV.map(sidebarLink).join('')}
        </nav>
        <div class="sidebar-foot">
          <button class="user-chip" id="user-chip" type="button">
            ${avatar(state.user.name, { size: 'sm' })}
            <span class="meta">
              <span class="name">${esc(state.user.name)}</span>
              <span class="role">${esc(ROLE_LABELS[state.user.role] ?? state.user.role)}</span>
            </span>
          </button>
        </div>
      </aside>

      <div class="main">
        <header class="topbar">
          <div>
            <h1 id="page-title">Обзор</h1>
            <div class="sub" id="page-sub"></div>
          </div>
          <div class="topbar-spacer"></div>
          <div class="search">
            ${icon('search', 15)}
            <input id="global-search" type="search" placeholder="Поиск клиентов… ( / )" aria-label="Поиск клиентов" />
          </div>
          <button class="icon-btn" id="theme-toggle" type="button" title="Сменить тему">${icon('moon', 17)}</button>
          <button class="icon-btn" id="quick-add" type="button" title="Быстрое создание">${icon('plus', 18)}</button>
        </header>
        <main class="content" id="view"></main>
      </div>
    </div>`

  bindShell()
  updateThemeButton()
}

function updateThemeButton() {
  const button = document.getElementById('theme-toggle')
  if (button) button.innerHTML = icon(state.theme === 'dark' ? 'sun' : 'moon', 17)
}

function bindShell() {
  document.getElementById('nav-main').addEventListener('click', (event) => {
    const button = event.target.closest('[data-nav]')
    if (button) navigate(button.dataset.nav)
  })
  document.getElementById('nav-admin')?.addEventListener('click', (event) => {
    const button = event.target.closest('[data-nav]')
    if (button) navigate(button.dataset.nav)
  })

  document.getElementById('theme-toggle').addEventListener('click', () => {
    toggleTheme()
    updateThemeButton()
  })

  document.getElementById('user-chip').addEventListener('click', (event) => {
    dropdown(event.currentTarget, [
      { label: 'Мой профиль', icon: 'user', onClick: () => navigate('/profile') },
      ...(state.permissions?.manageUsers
        ? [{ label: 'Команда', icon: 'shield', onClick: () => navigate('/team') }]
        : []),
      { sep: true },
      {
        label: 'Выйти',
        icon: 'logout',
        danger: true,
        onClick: async () => {
          try { await api('/api/auth/logout', { method: 'POST' }) } catch { /* ignore */ }
          renderLogin()
        },
      },
    ])
  })

  document.getElementById('quick-add').addEventListener('click', (event) => {
    dropdown(event.currentTarget, [
      { label: 'Новый клиент', icon: 'building', onClick: () => quickCreate('company') },
      { label: 'Новый контакт', icon: 'users', onClick: () => quickCreate('contact') },
      { label: 'Новая задача', icon: 'kanban', onClick: () => quickCreate('task') },
    ])
  })

  const search = document.getElementById('global-search')
  search.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      const value = search.value.trim()
      navigate(`/companies?q=${encodeURIComponent(value)}`)
      search.blur()
    }
  })

  document.addEventListener('keydown', onGlobalKey)
}

function onGlobalKey(event) {
  const tag = document.activeElement?.tagName
  const typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT'
  if (event.key === '/' && !typing) {
    event.preventDefault()
    document.getElementById('global-search')?.focus()
  }
  if (event.key.toLowerCase() === 'n' && !typing && !event.metaKey && !event.ctrlKey) {
    event.preventDefault()
    quickCreate('task')
  }
}

async function quickCreate(kind) {
  const { openCompanyForm, openContactForm, openTaskForm } = await import('./views/forms.js')
  if (kind === 'company') openCompanyForm(null, () => renderRoute())
  if (kind === 'contact') openContactForm(null, () => renderRoute())
  if (kind === 'task') openTaskForm(null, () => renderRoute(), currentParams)
}

/* ── Роутер ──────────────────────────────────────────────── */

function closeOpenModals() {
  document.querySelectorAll('.modal-backdrop').forEach((node) => node.remove())
  document.body.style.overflow = ''
}

async function refreshNavBadge() {
  try {
    const data = await api('/api/dashboard')
    const badge = document.querySelector('[data-badge="tasks"]')
    if (badge) {
      const count = data.tasks.todayOpen ?? data.tasks.open ?? 0
      badge.textContent = String(count)
      badge.hidden = count === 0
    }
  } catch { /* не критично */ }
}

/** Любое изменение задач: обновляем счётчик в меню и текущий раздел. */
function onTasksChanged() {
  refreshNavBadge()
  const { path } = parseHash()
  if (path === '/calendar' || path === '/dashboard') renderRoute()
}

async function renderRoute() {
  if (!state.user) return
  closeOpenModals()
  try {
    window.__viewCleanup?.()
  } catch {
    /* смена раздела не должна падать */
  }
  window.__viewCleanup = null
  const { path, query } = parseHash()
  const matched = matchRoute(path)
  const view = document.getElementById('view')
  if (!matched || !view) return

  const { route, params } = matched
  currentParams = params
  const adminOnly = route.view.adminOnly
  if (adminOnly && state.user.role !== 'admin') {
    view.innerHTML = `<div class="card"><div class="empty">
      <div class="icon">${icon('shield', 24)}</div>
      <h4>Недостаточно прав</h4><p>Раздел доступен только администраторам.</p>
    </div></div>`
    return
  }

  document.getElementById('page-title').textContent = route.title
  document.getElementById('page-sub').textContent = route.view.subtitle?.(params) ?? ''
  document.querySelectorAll('.nav-item').forEach((item) => {
    const active = item.dataset.key === route.nav
    item.classList.toggle('active', active)
    if (active) item.setAttribute('aria-current', 'page')
    else item.removeAttribute('aria-current')
  })
  document.title = `${route.title} · AMG-CRM`

  const ctx = {
    root: view,
    params,
    query,
    navigate,
    refresh: () => renderRoute(),
    setSubtitle: (text) => { document.getElementById('page-sub').textContent = text },
    toast,
    openCompany: (id) => navigate(`/companies/${id}`),
  }

  view.innerHTML = `<div class="card card-pad">
    <div class="skeleton sk-line" style="width:30%;height:18px"></div>
    <div class="skeleton sk-line" style="width:60%"></div>
    <div class="skeleton sk-line" style="width:45%"></div>
  </div>`

  try {
    await route.view.render(ctx)
  } catch (error) {
    console.error(error)
    view.innerHTML = `<div class="card"><div class="empty">
      <div class="icon">${icon('alert', 24)}</div>
      <h4>Не удалось загрузить раздел</h4>
      <p>${esc(error.message ?? 'Неизвестная ошибка')}</p>
      <button class="btn" onclick="location.reload()">Обновить страницу</button>
    </div></div>`
  }
  refreshNavBadge()
}

/* ── Обновления ──────────────────────────────────────────── */

async function checkForUpdates() {
  // В режиме клиента (общий сервер) обновления ставит администратор на сервере
  if (!['127.0.0.1', 'localhost'].includes(location.hostname)) return
  try {
    const data = await api('/api/system/update')
    if (data.available) showUpdateDialog(data)
  } catch {
    /* проверка обновлений не должна мешать работе */
  }
}

function showUpdateDialog(data) {
  if (!data?.latest) return
  const seenKey = `amg-update-seen-${data.latest}`
  if (sessionStorage.getItem(seenKey)) return
  sessionStorage.setItem(seenKey, '1')

  const notes = String(data.notes ?? '').trim()
  const { el, close } = openModal({
    title: 'Доступно обновление',
    sub: `Версия ${data.latest}`,
    body: `
      <div class="row" style="gap:14px;align-items:flex-start">
        <span class="update-badge">${icon('refresh', 18)}</span>
        <div style="min-width:0">
          <div style="font-weight:600;margin-bottom:6px">Вышла новая версия программы</div>
          <div class="small muted">${notes ? esc(notes) : 'Улучшения и исправления.'}</div>
          <div class="small muted" style="margin-top:10px">
            Программа закроется, обновится и запустится сама. Клиенты, задачи и звонки сохранятся.
          </div>
        </div>
      </div>`,
    footer: '<button class="btn" data-later type="button">Позже</button>'
      + '<button class="btn btn-primary" data-now type="button">Обновить сейчас</button>',
  })

  el.querySelector('[data-later]').addEventListener('click', close)
  el.querySelector('[data-now]').addEventListener('click', async (event) => {
    const button = event.currentTarget
    button.disabled = true
    button.innerHTML = '<span class="spinner"></span> Обновляем…'
    el.querySelector('[data-later]').disabled = true
    try {
      await api('/api/system/update/apply', { method: 'POST' })
      el.querySelector('.modal-body').innerHTML = `
        <div class="row" style="gap:14px;align-items:center">
          <span class="spinner"></span>
          <div>
            <div style="font-weight:600">Устанавливаем обновление…</div>
            <div class="small muted">Программа перезапустится сама через несколько секунд.</div>
          </div>
        </div>`
      el.querySelector('.modal-foot').innerHTML = ''
    } catch (error) {
      toast(error.message, 'error')
      button.disabled = false
      button.textContent = 'Обновить сейчас'
      el.querySelector('[data-later]').disabled = false
    }
  })
}

/* ── Запуск ──────────────────────────────────────────────── */

async function bootApp() {
  applyTheme()
  state.onUnauthorized = () => {
    if (state.user) {
      state.user = null
      renderLogin('Сессия истекла — войдите снова.')
    }
  }
  renderShell()
  document.addEventListener('crm:tasks-changed', onTasksChanged)
  document.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && String(event.key).toLowerCase() === 'f') {
      event.preventDefault()
      openChatSearch()
    }
  })
  window.addEventListener('focus', () => refreshNavBadge())
  setInterval(() => refreshNavBadge(), 60000)
  await renderRoute()
  if (!location.hash) navigate('/dashboard')
  checkForUpdates()
  if (state.permissions?.manageUsers) {
    checkNewAvitoChats()
    setInterval(checkNewAvitoChats, 15000)
  }
}

async function init() {
  applyTheme()
  window.addEventListener('hashchange', () => renderRoute())
  try {
    const me = await api('/api/auth/me')
    if (me.user) {
      state.user = me.user
      state.permissions = me.permissions
      if (!location.hash) location.hash = '#/dashboard'
      await bootApp()
    } else {
      renderLogin()
    }
  } catch (error) {
    renderLogin(error.status === 401 ? '' : error.message)
  }
}

init()
