/** Очередь уведомлений о новых чатах: их показывает само окно программы. */
const events = []
let seq = 0

export function pushChatNotify(chat) {
  seq += 1
  events.push({
    seq,
    at: new Date().toISOString(),
    id: chat.id ?? null,
    buyer: chat.buyer ?? 'Клиент',
    title: chat.title ?? '',
    price: chat.price ?? 0,
    url: chat.url ?? '',
  })
  if (events.length > 200) events.splice(0, events.length - 200)
}

export function notifySince(after) {
  return events.filter((event) => event.seq > after)
}
