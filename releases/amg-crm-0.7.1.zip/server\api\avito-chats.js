/** Авито — все чаты: карточки обращений из чатов Авито. */
import { appendFile } from 'node:fs/promises'
import { join } from 'node:path'

import { db } from '../db.js'
import { pushChatNotify } from '../notify.js'
import { audit } from '../audit.js'
import { requirePermission } from '../auth.js'
import { HttpError } from '../http.js'
import { idOf, isoOrNull, oneOf, optionalText, text } from '../validate.js'

export const AVITO_STATUSES = ['in_work', 'done', 'postponed', 'refused', 'no_answer', 'not_target', 'opt']
export const AVITO_STORES = ['pargolovo', 'dunaysky-27k1', 'pushkino', 'krasnodar', 'kaliningrad-1', 'kaliningrad-2']

const SELECT = `SELECT * FROM avito_chats`

/** Имя не должно быть мусором: только осмысленный текст. */
const UI_WORDS = new Set([
  'сообщения', 'сообщение', 'чат', 'чаты', 'профиль', 'объявления', 'объявление', 'поиск',
  'меню', 'настройки', 'избранное', 'корзина', 'оплата', 'выход', 'войти', 'главная',
  'каталог', 'уведомления', 'авито', 'поддержка', 'доставка', 'клиент',
])

function cleanPerson(value) {
  const s = String(value ?? '').trim()
  if (!s) return null
  if (!/[A-Za-zА-Яа-яЁё0-9]/.test(s)) return null
  if (UI_WORDS.has(s.toLowerCase())) return null
  return s
}
const TITLE_STOP = [
  'отметить', 'отправить', 'позвонить', 'написать', 'показать', 'удалить', 'заблокировать',
  'пожаловаться', 'прочитанным', 'непрочитанным', 'поделиться', 'скопировать', 'переслать',
  'закрыть', 'открыть', 'выбрать', 'оплатить', 'заказать', 'видео', 'файл',
]

function cleanTitle(value) {
  const s = String(value ?? '').trim()
  if (!s) return null
  const lower = s.toLowerCase()
  if (TITLE_STOP.some((word) => lower.includes(word))) return null
  if (!/[A-Za-zА-Яа-яЁё0-9]/.test(s)) return null
  return s
}
function row(payload, existing = null) {
  const now = new Date().toISOString()
  const status = payload.status === undefined
    ? (existing?.status ?? 'in_work')
    : oneOf(payload.status, AVITO_STATUSES, 'статус')
  return {
    startedAt: payload.startedAt === undefined ? (existing?.started_at ?? now) : (isoOrNull(payload.startedAt, 'дата начала') ?? now),
    chatUrl: payload.chatUrl === undefined ? existing?.chat_url ?? null : optionalText(payload.chatUrl, 'ссылка на чат', { max: 500 }),
    buyerName: payload.buyerName === undefined ? existing?.buyer_name ?? null : cleanPerson(optionalText(payload.buyerName, 'имя собеседника', { max: 120 })),
    store: payload.store === undefined
      ? existing?.store ?? null
      : (payload.store ? oneOf(payload.store, AVITO_STORES, 'магазин') : null),
    listingPrice: payload.listingPrice === undefined ? Number(existing?.listing_price ?? 0) : Number(payload.listingPrice) || 0,
    listingTitle: payload.listingTitle === undefined ? existing?.listing_title ?? null : cleanTitle(optionalText(payload.listingTitle, 'название объявления', { max: 300 })),
    order1c: payload.order1c === undefined ? existing?.order_1c ?? null : optionalText(payload.order1c, 'номер заказа 1С', { max: 60 }),
    orderPrice: payload.orderPrice === undefined ? Number(existing?.order_price ?? 0) : Number(payload.orderPrice) || 0,
    status,
    refuseReason: payload.refuseReason === undefined ? existing?.refuse_reason ?? null : optionalText(payload.refuseReason, 'причина отказа', { max: 300 }),
    comment: payload.comment === undefined ? existing?.comment ?? null : optionalText(payload.comment, 'комментарий', { max: 2000 }),
    lastActivityAt: now,
  }
}

/** Устойчивый ключ чата: id канала из ссылки или переданный externalId. */
function chatKeyOf(chatUrl, externalId) {
  if (externalId) return String(externalId).trim().slice(0, 120)
  const match = String(chatUrl ?? '').match(/(?:channel\/|\/messages\/)([A-Za-z0-9_~-]+)/)
  return match ? match[1] : ''
}

/** Достаёт id чата из любой формы ссылки Авито. */
function extractChatId(text) {
  const s = String(text ?? '').trim()
  if (!s) return ''
  const patterns = [
    /channel\/([A-Za-z0-9_~%.=-]+)/,
    /\/messages\/([A-Za-z0-9_~%.=-]+)/,
    /[?&](?:chatId|chat_id|chat|id)=([A-Za-z0-9_~%.=-]+)/i,
  ]
  for (const pattern of patterns) {
    const match = s.match(pattern)
    if (match) return decodeURIComponent(match[1])
  }
  if (/^https?:\/\//i.test(s)) {
    try {
      const url = new URL(s)
      const segment = url.pathname.split('/').filter(Boolean).pop()
      if (segment && /^[A-Za-z0-9_~%.-]{4,}$/.test(segment)) return decodeURIComponent(segment)
    } catch {
      /* не ссылка */
    }
  }
  return ''
}
function findExisting(key, chatUrl) {
  if (key) {
    const byKey = db.prepare('SELECT * FROM avito_chats WHERE external_id = ?').get(key)
    if (byKey) return byKey
  }
  if (chatUrl) {
    const byUrl = db.prepare('SELECT * FROM avito_chats WHERE chat_url = ?').get(chatUrl)
    if (byUrl) return byUrl
  }
  return null
}

function changedActivity(payload) {
  return payload.status !== undefined || payload.comment !== undefined
}

export function registerAvitoChatRoutes(router) {
  const admin = (user) => requirePermission({ user }, 'manageUsers')

  router.get('/api/avito-chats/options', async ({ user }) => {
    admin(user)
    return { statuses: AVITO_STATUSES, stores: AVITO_STORES }
  })

  router.get('/api/avito-chats', async ({ query, user }) => {
    admin(user)
    const where = []
    const params = []
    const status = query.get('status')
    if (status && AVITO_STATUSES.includes(status)) {
      where.push('status = ?')
      params.push(status)
    }
    const store = query.get('store')
    if (store) {
      where.push('store = ?')
      params.push(store)
    }
    const onlyNew = query.get('new')
    if (onlyNew === '1') where.push('store IS NULL')
    const month = (query.get('month') ?? '').trim()
    if (/^\d{4}-\d{2}$/.test(month)) {
      where.push("strftime('%Y-%m', started_at, 'localtime') = ?")
      params.push(month)
    }
    const search = (query.get('q') ?? '').trim()
    if (search) {
      const byKey = extractChatId(search) || (/^[A-Za-z0-9_~-]{6,}$/.test(search) ? search : '')
      const like = `%${search}%`
      const plain = search
        .replace(/^https?:\/\//i, '')
        .replace(/^www\./i, '')
        .replace(/[?#].*$/, '')
        .replace(/\/+$/, '')
      const plainLike = `%${plain}%`
      const STOP_WORDS = new Set(['http', 'https', 'www', 'avito', 'profile', 'messenger', 'channel', 'messages', 'com', 'ru'])
      let tokens = (search.match(/[A-Za-z0-9_~-]{6,}/g) ?? []).filter((token) => !STOP_WORDS.has(token.toLowerCase())).slice(0, 4)
      if (byKey) tokens = [byKey]
      const parts = [
        'buyer_name LIKE ?', 'listing_title LIKE ?', 'order_1c LIKE ?', 'comment LIKE ?',
        'chat_url LIKE ?', 'chat_url LIKE ?', 'external_id LIKE ?',
      ]
      params.push(like, like, like, like, like, plainLike, plainLike)
      for (const token of tokens) {
        parts.push('external_id LIKE ?', 'chat_url LIKE ?')
        params.push(`%${token}%`, `%${token}%`)
      }
      if (byKey) {
        parts.push('external_id LIKE ?')
        params.push(byKey)
      }
      where.push('(' + parts.join(' OR ') + ')')
    }
    const sql = `${SELECT}${where.length ? ' WHERE ' + where.join(' AND ') : ''} ORDER BY started_at DESC LIMIT 5000`
    const items = db.prepare(sql).all(...params)
    const months = db.prepare(`SELECT strftime('%Y-%m', started_at, 'localtime') AS month, COUNT(*) AS count
      FROM avito_chats WHERE started_at IS NOT NULL
      GROUP BY month ORDER BY month DESC`).all()
    const stats = {
      total: items.length,
      newChats: items.filter((item) => !item.store).length,
      inWork: items.filter((item) => item.status === 'in_work').length,
      done: items.filter((item) => item.status === 'done').length,
      refused: items.filter((item) => item.status === 'refused').length,
      revenue: items.filter((item) => item.status === 'done').reduce((sum, item) => sum + (item.order_price || 0), 0),
    }
    return { items, stats, months }
  })

  router.get('/api/avito-chats/:id', async ({ params, user }) => {
    admin(user)
    const id = idOf(params.id)
    const item = db.prepare(`${SELECT} WHERE id = ?`).get(id)
    if (!item) throw new HttpError(404, 'Чат не найден', 'NOT_FOUND')
    return { item }
  })

  router.post('/api/avito-chats', async ({ body, user }) => {
    const actor = admin(user)
    const now = new Date().toISOString()
    const data = row({ ...body, startedAt: body.startedAt ?? now }, null)
    const key = chatKeyOf(data.chatUrl, body.externalId)

    // Дублей быть не должно: если такой чат уже есть — возвращаем его
    const existing = findExisting(key, data.chatUrl)
    if (existing) {
      return { item: existing, duplicate: true }
    }

    const res = db.prepare(`INSERT INTO avito_chats
      (external_id, started_at, chat_url, buyer_name, store, listing_price, listing_title, order_1c, order_price,
       status, refuse_reason, comment, last_activity_at, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(key || null, data.startedAt, data.chatUrl, data.buyerName, data.store, data.listingPrice,
        data.listingTitle, data.order1c, data.orderPrice, data.status, data.refuseReason, data.comment,
        data.lastActivityAt, now, now)
    const id = Number(res.lastInsertRowid)
    audit(actor.id, 'create', 'avito_chat', id, { buyer: data.buyerName })
    return { item: db.prepare(`${SELECT} WHERE id = ?`).get(id) }
  })

  router.patch('/api/avito-chats/:id', async ({ body, params, user }) => {
    const actor = admin(user)
    const id = idOf(params.id)
    const existing = db.prepare(`${SELECT} WHERE id = ?`).get(id)
    if (!existing) throw new HttpError(404, 'Чат не найден', 'NOT_FOUND')
    const data = row(body, existing)
    const activity = changedActivity(body) ? new Date().toISOString() : existing.last_activity_at
    db.prepare(`UPDATE avito_chats SET started_at = ?, chat_url = ?, buyer_name = ?, store = ?, listing_price = ?,
      listing_title = ?, order_1c = ?, order_price = ?, status = ?, refuse_reason = ?, comment = ?,
      last_activity_at = ?, updated_at = ? WHERE id = ?`)
      .run(data.startedAt, data.chatUrl, data.buyerName, data.store, data.listingPrice, data.listingTitle,
        data.order1c, data.orderPrice, data.status, data.refuseReason, data.comment, activity,
        new Date().toISOString(), id)
    audit(actor.id, 'update', 'avito_chat', id, { status: data.status })
    return { item: db.prepare(`${SELECT} WHERE id = ?`).get(id) }
  })

  router.delete('/api/avito-chats/:id', async ({ params, user }) => {
    const actor = admin(user)
    const id = idOf(params.id)
    const existing = db.prepare('SELECT buyer_name FROM avito_chats WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Чат не найден', 'NOT_FOUND')
    db.prepare('DELETE FROM avito_chats WHERE id = ?').run(id)
    audit(actor.id, 'delete', 'avito_chat', id, { buyer: existing.buyer_name })
    return { ok: true }
  })

  /**
   * Приём чатов из Авито (внешняя интеграция).
   * Токен задаётся в переменной окружения AVITO_IMPORT_TOKEN.
   */
  router.post('/api/avito-chats/import', async ({ body, headers }) => {
    const token = process.env.AVITO_IMPORT_TOKEN ?? ''
    if (token) {
      const given = headers['x-avito-token'] ?? ''
      if (given !== token) throw new HttpError(403, 'Неверный токен импорта', 'FORBIDDEN')
    }
    const items = Array.isArray(body.items) ? body.items : [body]
    try {
      const dir = process.env.CRM_DATA_DIR ?? join(process.env.LOCALAPPDATA ?? '', 'AMG-CRM', 'data')
      await appendFile(join(dir, 'avito-import.log'),
        new Date().toISOString() + '  ' + JSON.stringify(items).slice(0, 4000) + '\n')
    } catch {
      /* журнал не должен ломать импорт */
    }

    const created = []
    let skipped = 0
    for (const item of items) {
      const data = row({ ...item, startedAt: item.startedAt ?? new Date().toISOString() }, null)
      const key = chatKeyOf(data.chatUrl, item.externalId)
      if (!key) {
        skipped += 1
        continue
      }
      const existing = findExisting(key, data.chatUrl)
      if (existing) {
        skipped += 1
        // Дополняем карточку тем, чего в ней не хватает (название объявления, цена, имя)
        const patch = {}
        if (data.listingTitle && !existing.listing_title) patch.listing_title = data.listingTitle
        if (data.listingPrice && !existing.listing_price) patch.listing_price = data.listingPrice
        const badName = !existing.buyer_name || existing.buyer_name === 'Клиент' || !/[A-Za-zА-Яа-яЁё0-9]/.test(existing.buyer_name)
        if (data.buyerName && badName) patch.buyer_name = data.buyerName
        if (data.chatUrl && !existing.chat_url) patch.chat_url = data.chatUrl
        if (item.comment && !existing.comment) patch.comment = String(item.comment)
        if (data.store && !existing.store) patch.store = data.store
        if (data.refuseReason && !existing.refuse_reason) patch.refuse_reason = data.refuseReason
        const keys = Object.keys(patch)
        if (keys.length > 0) {
          patch.last_activity_at = new Date().toISOString()
          patch.updated_at = patch.last_activity_at
          const all = Object.keys(patch)
          const sql = `UPDATE avito_chats SET ${all.map((name) => `${name} = ?`).join(', ')} WHERE id = ?`
          db.prepare(sql).run(...all.map((name) => patch[name]), existing.id)
        }
        continue
      }
      const now = new Date().toISOString()
      const res = db.prepare(`INSERT INTO avito_chats
        (external_id, started_at, chat_url, buyer_name, store, listing_price, listing_title, order_1c, order_price,
         status, refuse_reason, comment, last_activity_at, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(key, data.startedAt, data.chatUrl, data.buyerName, data.store, data.listingPrice,
          data.listingTitle, data.order1c, data.orderPrice, data.status, data.refuseReason, data.comment, now, now, now)
      created.push(Number(res.lastInsertRowid))
      pushChatNotify({
        id: Number(res.lastInsertRowid),
        buyer: data.buyerName,
        title: data.listingTitle,
        price: data.listingPrice,
        url: data.chatUrl,
      })
    }
    return { ok: true, created: created.length, skipped, ids: created }
  })
}
