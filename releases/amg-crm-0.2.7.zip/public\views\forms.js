/* Формы создания и редактирования клиентов, контактов и задач. */
import {
  ROLE_LABELS, api, fromInputDateTime, state, toast, toInputDateTime, formModal, COMPANY_STATUS,
  TASK_PRIORITY, TASK_STATUS,
} from '../lib.js'

let usersCache = null
let companiesCache = null

export async function loadUsers(force = false) {
  if (!usersCache || force) {
    const data = await api('/api/users')
    usersCache = data.items
  }
  return usersCache
}

export async function loadCompanies(force = false) {
  if (!companiesCache || force) {
    const data = await api('/api/companies?pageSize=100&sort=name')
    companiesCache = data.items
  }
  return companiesCache
}

export function invalidateCaches() {
  usersCache = null
  companiesCache = null
}

const statusOptions = Object.entries(COMPANY_STATUS).map(([value, meta]) => ({ value, label: meta.label }))

function userOptions(users, placeholder = 'Не назначен') {
  return [{ value: '', label: placeholder }, ...users.filter((u) => u.isActive).map((u) => ({ value: u.id, label: u.name }))]
}

function companyOptions(companies) {
  return [{ value: '', label: 'Без клиента' }, ...companies.map((c) => ({ value: c.id, label: c.name }))]
}

export async function openCompanyForm(company, onDone) {
  const users = await loadUsers()
  const isEdit = Boolean(company)
  await formModal({
    title: isEdit ? 'Редактировать клиента' : 'Новый клиент',
    sub: isEdit ? company.name : 'Компания или частное лицо, с которым вы работаете',
    wide: true,
    submitLabel: isEdit ? 'Сохранить' : 'Создать клиента',
    fields: [
      { name: 'name', label: 'Название', required: true, placeholder: 'ООО «Ромашка»', value: company?.name },
      { name: 'status', label: 'Статус', type: 'select', options: statusOptions, value: company?.status ?? 'lead' },
      { name: 'industry', label: 'Сфера', placeholder: 'Логистика, IT, ритейл…', value: company?.industry },
      { name: 'ownerId', label: 'Ответственный', type: 'select', options: userOptions(users),
        value: company?.owner_id ?? state.user.id },
      { name: 'phone', label: 'Телефон', type: 'tel', placeholder: '+7 900 000-00-00', value: company?.phone },
      { name: 'email', label: 'E-mail', type: 'email', placeholder: 'info@company.ru', value: company?.email },
      { name: 'website', label: 'Сайт', placeholder: 'https://company.ru', value: company?.website },
      { name: 'address', label: 'Адрес', placeholder: 'Город, улица, дом', value: company?.address },
      { name: 'note', label: 'Заметка', type: 'textarea', span: 2, rows: 3,
        placeholder: 'Важный контекст: договорённости, особенности, история', value: company?.note },
    ],
    submit: async (values) => {
      const payload = { ...values, ownerId: values.ownerId ? Number(values.ownerId) : null }
      if (isEdit) await api(`/api/companies/${company.id}`, { method: 'PATCH', body: payload })
      else await api('/api/companies', { method: 'POST', body: payload })
      invalidateCaches()
      toast(isEdit ? 'Клиент обновлён' : 'Клиент создан')
      onDone?.()
    },
  })
}

export async function openContactForm(contact, onDone, preset = {}) {
  const companies = await loadCompanies()
  const isEdit = Boolean(contact)
  await formModal({
    title: isEdit ? 'Редактировать контакт' : 'Новый контакт',
    sub: isEdit ? [contact.first_name, contact.last_name].filter(Boolean).join(' ') : 'Человек, с которым вы общаетесь',
    wide: true,
    submitLabel: isEdit ? 'Сохранить' : 'Создать контакт',
    fields: [
      { name: 'firstName', label: 'Имя', required: true, value: contact?.first_name },
      { name: 'lastName', label: 'Фамилия', value: contact?.last_name },
      { name: 'companyId', label: 'Клиент', type: 'select', span: 2,
        options: companyOptions(companies),
        value: contact?.company_id ?? preset.companyId ?? '' },
      { name: 'position', label: 'Должность', value: contact?.position },
      { name: 'phone', label: 'Телефон', type: 'tel', value: contact?.phone },
      { name: 'email', label: 'E-mail', type: 'email', value: contact?.email },
      { name: 'telegram', label: 'Telegram', placeholder: '@username', value: contact?.telegram },
      { name: 'isPrimary', label: 'Основной контакт', type: 'checkbox', span: 2,
        checkboxLabel: 'Главный контакт по этому клиенту', value: Boolean(contact?.is_primary) },
      { name: 'note', label: 'Заметка', type: 'textarea', span: 2, rows: 3, value: contact?.note },
    ],
    submit: async (values) => {
      const payload = { ...values, companyId: values.companyId ? Number(values.companyId) : null }
      if (isEdit) await api(`/api/contacts/${contact.id}`, { method: 'PATCH', body: payload })
      else await api('/api/contacts', { method: 'POST', body: payload })
      invalidateCaches()
      toast(isEdit ? 'Контакт обновлён' : 'Контакт создан')
      onDone?.()
    },
  })
}

export async function openTaskForm(task, onDone, preset = {}) {
  const [users, companies] = await Promise.all([loadUsers(), loadCompanies()])
  const isEdit = Boolean(task)
  await formModal({
    title: isEdit ? 'Редактировать задачу' : 'Новая задача',
    sub: isEdit ? task.title : 'Что нужно сделать и когда',
    wide: true,
    submitLabel: isEdit ? 'Сохранить' : 'Создать задачу',
    fields: [
      { name: 'title', label: 'Название', required: true, span: 2, placeholder: 'Позвонить, подготовить КП, отправить счёт…', value: task?.title },
      { name: 'dueAt', label: 'Срок', type: 'datetime-local', value: toInputDateTime(task?.due_at ?? preset.dueAt) },
      { name: 'priority', label: 'Приоритет', type: 'select',
        options: Object.entries(TASK_PRIORITY).map(([value, label]) => ({ value, label })),
        value: task?.priority ?? 'normal' },
      { name: 'assigneeId', label: 'Исполнитель', type: 'select', options: userOptions(users),
        value: task?.assignee_id ?? state.user.id },
      { name: 'status', label: 'Статус', type: 'select',
        options: Object.entries(TASK_STATUS).map(([value, label]) => ({ value, label })),
        value: task?.status ?? 'todo' },
      { name: 'companyId', label: 'Клиент', type: 'select', span: 2, options: companyOptions(companies),
        value: task?.company_id ?? preset.companyId ?? '' },
      { name: 'description', label: 'Описание', type: 'textarea', span: 2, rows: 3, value: task?.description },
    ],
    submit: async (values) => {
      const payload = {
        ...values,
        dueAt: fromInputDateTime(values.dueAt),
        assigneeId: values.assigneeId ? Number(values.assigneeId) : null,
        companyId: values.companyId ? Number(values.companyId) : null,
      }
      if (isEdit) await api(`/api/tasks/${task.id}`, { method: 'PATCH', body: payload })
      else await api('/api/tasks', { method: 'POST', body: payload })
      toast(isEdit ? 'Задача обновлена' : 'Задача создана')
      onDone?.()
    },
  })
}

export async function openUserForm(member, onDone) {
  const isEdit = Boolean(member)
  await formModal({
    title: isEdit ? 'Редактировать сотрудника' : 'Новый сотрудник',
    sub: isEdit ? (member.login ? `Логин: ${member.login}` : member.email) : 'Логин для входа, роль и пароль',
    submitLabel: isEdit ? 'Сохранить' : 'Создать',
    fields: [
      { name: 'login', label: 'Логин', required: !isEdit, value: member?.login ?? '',
        placeholder: 'Парголово', hint: isEdit ? 'Можно изменить — вход будет по новому логину' : 'Например: Парголово, Калининград 1' },
      { name: 'name', label: 'Название / имя', required: true, value: member?.name },
      { name: 'email', label: 'E-mail', type: 'email', value: member?.email,
        hint: isEdit ? 'E-mail изменить нельзя' : 'Необязательно' },
      { name: 'role', label: 'Роль', type: 'select',
        options: Object.entries(ROLE_LABELS).map(([value, label]) => ({ value, label })),
        value: member?.role ?? 'manager' },
      { name: 'phone', label: 'Телефон', type: 'tel', value: member?.phone },
      { name: 'password', label: isEdit ? 'Новый пароль' : 'Пароль', type: 'password', span: 2,
        placeholder: 'Минимум 4 символа',
        hint: isEdit ? 'Оставьте пустым, чтобы не менять. При смене пароля все сессии сотрудника завершатся.' : '' },
      ...(isEdit ? [{ name: 'isActive', label: 'Доступ', type: 'checkbox', span: 2,
        checkboxLabel: 'Учётная запись активна', value: member.isActive }] : []),
    ],
    submit: async (values) => {
      if (!isEdit && String(values.password ?? '').length < 4) throw new Error('Пароль должен быть не короче 4 символов')
      const payload = {
        name: values.name,
        role: values.role,
        phone: values.phone,
        ...(values.login ? { login: values.login } : {}),
        ...(isEdit ? { isActive: Boolean(values.isActive) } : {}),
        ...(values.password ? { password: values.password } : {}),
      }
      if (isEdit) await api(`/api/users/${member.id}`, { method: 'PATCH', body: payload })
      else await api('/api/users', { method: 'POST', body: { ...payload, email: values.email } })
      invalidateCaches()
      toast(isEdit ? 'Сотрудник обновлён' : 'Сотрудник создан')
      onDone?.()
    },
  })
}
