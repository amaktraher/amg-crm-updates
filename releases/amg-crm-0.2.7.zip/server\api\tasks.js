import { db } from '../db.js'
import { audit, logActivity } from '../audit.js'
import { requirePermission, requireUser } from '../auth.js'
import { HttpError } from '../http.js'
import { idOf, idOrNull, isoOrNull, oneOf, optionalText, text } from '../validate.js'

const STATUSES = ['todo', 'doing', 'done']
const PRIORITIES = ['low', 'normal', 'high']

const SELECT = `
  SELECT t.*, c.name AS company_name, ct.first_name AS contact_first_name, ct.last_name AS contact_last_name,
         u.name AS assignee_name, cb.name AS creator_name
  FROM tasks t
  LEFT JOIN companies c ON c.id = t.company_id
  LEFT JOIN contacts ct ON ct.id = t.contact_id
  LEFT JOIN users u ON u.id = t.assignee_id
  LEFT JOIN users cb ON cb.id = t.created_by`

function priorityWeight(priority) {
  return { high: 0, normal: 1, low: 2 }[priority] ?? 3
}

export function registerTaskRoutes(router) {
  router.get('/api/tasks', async ({ query, user }) => {
    requireUser({ user })
    const scope = query.get('scope') ?? 'open'
    const status = query.get('status')
    const assigneeId = query.get('assigneeId')
    const companyId = query.get('companyId')
    const q = String(query.get('q') ?? '').trim()
    const from = query.get('from')
    const to = query.get('to')

    const where = []
    const params = []
    if (scope === 'mine') { where.push('t.assignee_id = ?'); params.push(user.id) }
    if (scope === 'open') where.push("t.status != 'done'")
    if (scope === 'overdue') { where.push("t.status != 'done' AND t.due_at IS NOT NULL AND t.due_at < ?"); params.push(new Date().toISOString()) }
    if (scope === 'today') {
      const start = new Date(); start.setHours(0, 0, 0, 0)
      const end = new Date(start); end.setDate(end.getDate() + 1)
      where.push('t.due_at >= ? AND t.due_at < ?')
      params.push(start.toISOString(), end.toISOString())
    }
    if (status && STATUSES.includes(status)) { where.push('t.status = ?'); params.push(status) }
    if (assigneeId && assigneeId !== 'all') { where.push('t.assignee_id = ?'); params.push(Number(assigneeId)) }
    if (companyId && companyId !== 'all') { where.push('t.company_id = ?'); params.push(Number(companyId)) }
    if (q) { where.push('(t.title LIKE ? OR t.description LIKE ?)'); params.push(`%${q}%`, `%${q}%`) }
    if (from) { where.push('t.due_at >= ?'); params.push(new Date(String(from)).toISOString()) }
    if (to) { where.push('t.due_at < ?'); params.push(new Date(String(to)).toISOString()) }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : ''
    const items = db.prepare(`${SELECT} ${whereSql}
      ORDER BY (t.status = 'done'), COALESCE(t.due_at, '9999-12-31') ASC, t.id DESC
      LIMIT 500`).all(...params)
    return { items }
  })

  router.get('/api/tasks/:id', async ({ params, user }) => {
    requireUser({ user })
    const id = idOf(params.id)
    const item = db.prepare(`${SELECT} WHERE t.id = ?`).get(id)
    if (!item) throw new HttpError(404, 'Задача не найдена', 'NOT_FOUND')
    const activities = db.prepare(`SELECT a.*, u.name AS user_name FROM activities a
      LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity_type = 'task' AND a.entity_id = ? ORDER BY a.created_at DESC LIMIT 50`).all(id)
    return { item, activities }
  })

  router.post('/api/tasks', async ({ body, user }) => {
    const actor = requirePermission({ user }, 'write')
    const stamp = new Date().toISOString()
    const title = text(body.title, 'Название', { max: 200 })
    const data = {
      description: optionalText(body.description, 'Описание', { max: 4000 }),
      status: oneOf(body.status ?? 'todo', STATUSES, 'статус'),
      priority: oneOf(body.priority ?? 'normal', PRIORITIES, 'приоритет'),
      dueAt: isoOrNull(body.dueAt, 'дата'),
      companyId: idOrNull(body.companyId, 'клиент'),
      contactId: idOrNull(body.contactId, 'контакт'),
      assigneeId: idOrNull(body.assigneeId, 'исполнитель'),
    }
    const res = db.prepare(`INSERT INTO tasks
      (title, description, status, priority, due_at, company_id, contact_id, assignee_id, created_by,
       completed_at, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(title, data.description, data.status, data.priority, data.dueAt, data.companyId, data.contactId,
        data.assigneeId, actor.id, data.status === 'done' ? stamp : null, stamp, stamp)
    const id = Number(res.lastInsertRowid)
    if (data.companyId) logActivity('company', data.companyId, 'system', `Новая задача: ${title}`, actor.id)
    audit(actor.id, 'create', 'task', id, { title })
    return { item: db.prepare(`${SELECT} WHERE t.id = ?`).get(id) }
  })

  router.patch('/api/tasks/:id', async ({ body, params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Задача не найдена', 'NOT_FOUND')

    const data = {
      title: body.title === undefined ? existing.title : text(body.title, 'Название', { max: 200 }),
      description: body.description === undefined ? existing.description : optionalText(body.description, 'Описание', { max: 4000 }),
      status: body.status === undefined ? existing.status : oneOf(body.status, STATUSES, 'статус'),
      priority: body.priority === undefined ? existing.priority : oneOf(body.priority, PRIORITIES, 'приоритет'),
      dueAt: body.dueAt === undefined ? existing.due_at : isoOrNull(body.dueAt, 'дата'),
      companyId: body.companyId === undefined ? existing.company_id : idOrNull(body.companyId, 'клиент'),
      contactId: body.contactId === undefined ? existing.contact_id : idOrNull(body.contactId, 'контакт'),
      assigneeId: body.assigneeId === undefined ? existing.assignee_id : idOrNull(body.assigneeId, 'исполнитель'),
    }
    const completedAt = data.status === 'done'
      ? (existing.status === 'done' ? existing.completed_at : new Date().toISOString())
      : null
    db.prepare(`UPDATE tasks SET title = ?, description = ?, status = ?, priority = ?, due_at = ?,
      company_id = ?, contact_id = ?, assignee_id = ?, completed_at = ?, updated_at = ? WHERE id = ?`)
      .run(data.title, data.description, data.status, data.priority, data.dueAt, data.companyId,
        data.contactId, data.assigneeId, completedAt, new Date().toISOString(), id)
    if (existing.status !== data.status) {
      audit(actor.id, 'status', 'task', id, { from: existing.status, to: data.status })
      if (data.companyId) {
        const label = data.status === 'done' ? 'Задача выполнена' : 'Статус задачи изменён'
        logActivity('company', data.companyId, 'system', `${label}: ${data.title}`, actor.id)
      }
    } else {
      audit(actor.id, 'update', 'task', id)
    }
    return { item: db.prepare(`${SELECT} WHERE t.id = ?`).get(id) }
  })

  router.post('/api/tasks/:id/toggle', async ({ params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Задача не найдена', 'NOT_FOUND')
    const done = existing.status === 'done'
    const status = done ? 'todo' : 'done'
    const stamp = new Date().toISOString()
    db.prepare('UPDATE tasks SET status = ?, completed_at = ?, updated_at = ? WHERE id = ?')
      .run(status, done ? null : stamp, stamp, id)
    audit(actor.id, 'status', 'task', id, { from: existing.status, to: status })
    return { item: db.prepare(`${SELECT} WHERE t.id = ?`).get(id) }
  })

  router.delete('/api/tasks/:id', async ({ params, user }) => {
    const actor = requirePermission({ user }, 'manageUsers')
    const id = idOf(params.id)
    const existing = db.prepare('SELECT title FROM tasks WHERE id = ?').get(id)
    if (!existing) throw new HttpError(404, 'Задача не найдена', 'NOT_FOUND')
    db.prepare('DELETE FROM tasks WHERE id = ?').run(id)
    audit(actor.id, 'delete', 'task', id, { title: existing.title })
    return { ok: true }
  })

  router.post('/api/tasks/:id/activities', async ({ body, params, user }) => {
    const actor = requirePermission({ user }, 'write')
    const id = idOf(params.id)
    if (!db.prepare('SELECT 1 FROM tasks WHERE id = ?').get(id)) {
      throw new HttpError(404, 'Задача не найдена', 'NOT_FOUND')
    }
    logActivity('task', id, 'note', text(body.body, 'Текст', { max: 4000 }), actor.id)
    return { ok: true }
  })
}
