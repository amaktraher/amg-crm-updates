import { createReadStream, statSync } from 'node:fs'
import { extname, join, normalize, resolve, sep } from 'node:path'

/** An error carrying the HTTP status a handler wants to report. */
export class HttpError extends Error {
  constructor(status, message, code = undefined) {
    super(message)
    this.status = status
    this.code = code
  }
}

export function sendJson(res, status, payload) {
  const body = JSON.stringify(payload)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  })
  res.end(body)
}

export function sendText(res, status, text, type = 'text/plain; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Content-Length': Buffer.byteLength(text) })
  res.end(text)
}

const MAX_BODY = 2 * 1024 * 1024

/** Read and parse a JSON request body. */
export async function readJson(req) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > MAX_BODY) throw new HttpError(413, 'Слишком большой запрос')
    chunks.push(chunk)
  }
  if (size === 0) return {}
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new HttpError(400, 'Ожидается JSON-объект')
    }
    return parsed
  } catch (error) {
    if (error instanceof HttpError) throw error
    throw new HttpError(400, 'Некорректный JSON')
  }
}

export function parseCookies(header = '') {
  const out = {}
  for (const part of String(header).split(';')) {
    const index = part.indexOf('=')
    if (index < 0) continue
    const name = part.slice(0, index).trim()
    if (!name) continue
    out[name] = decodeURIComponent(part.slice(index + 1).trim())
  }
  return out
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
}

/** Serve a file from `root`, falling back to index.html for the SPA shell. */
export function serveStatic(req, res, root, pathname) {
  const decoded = decodeURIComponent(pathname)
  const relative = normalize(decoded).replace(/^([/\\])+/, '')
  let target = resolve(join(root, relative))
  const rootResolved = resolve(root)
  if (target !== rootResolved && !target.startsWith(rootResolved + sep)) {
    sendText(res, 403, 'Forbidden')
    return true
  }
  let stat = null
  try { stat = statSync(target) } catch { stat = null }
  if (!stat || stat.isDirectory()) {
    if (extname(decoded) !== '') return false
    target = join(root, 'index.html')
    try { stat = statSync(target) } catch { return false }
  }
  res.writeHead(200, {
    'Content-Type': MIME[extname(target).toLowerCase()] ?? 'application/octet-stream',
    'Content-Length': stat.size,
    'Cache-Control': 'no-cache',
    'X-Content-Type-Options': 'nosniff',
  })
  createReadStream(target).pipe(res)
  return true
}

/** Minimal pattern router: `/api/companies/:id` style paths. */
export function createRouter() {
  const routes = []
  const add = (method, pattern, handler) => {
    const segments = pattern.split('/').filter(Boolean)
    routes.push({ method, segments, handler })
  }
  return {
    get: (pattern, handler) => add('GET', pattern, handler),
    post: (pattern, handler) => add('POST', pattern, handler),
    patch: (pattern, handler) => add('PATCH', pattern, handler),
    put: (pattern, handler) => add('PUT', pattern, handler),
    delete: (pattern, handler) => add('DELETE', pattern, handler),
    match(method, pathname) {
      const parts = pathname.split('/').filter(Boolean)
      for (const route of routes) {
        if (route.method !== method) continue
        if (route.segments.length !== parts.length) continue
        const params = {}
        let ok = true
        for (let i = 0; i < parts.length; i += 1) {
          const segment = route.segments[i]
          if (segment.startsWith(':')) params[segment.slice(1)] = decodeURIComponent(parts[i])
          else if (segment !== parts[i]) { ok = false; break }
        }
        if (ok) return { handler: route.handler, params }
      }
      return null
    },
  }
}
