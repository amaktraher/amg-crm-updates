/* Уведомление о новом чате Авито с выбором магазина. */
import { api, esc, openModal, toast } from '../lib.js'

const STORES = [
  ['pargolovo', 'Парголово'],
  ['dunaysky-27k1', 'Дунайский 27к1'],
  ['pushkino', 'Пушкино'],
  ['krasnodar', 'Краснодар'],
  ['kaliningrad-1', 'Калининград 1'],
  ['kaliningrad-2', 'Калининград 2'],
]

const shown = new Set()

export async function checkNewAvitoChats() {
  try {
    const data = await api('/api/avito-chats?new=1')
    const fresh = (data.items ?? []).filter((item) => !shown.has(item.id))
    if (fresh.length === 0) return
    shown.add(fresh[0].id)
    showNewAvitoChat(fresh[0])
  } catch {
    /* уведомления не должны мешать работе */
  }
}

export function showNewAvitoChat(item) {
  const started = item.started_at ? new Date(item.started_at).toLocaleString('ru-RU') : '—'
  const price = Number(item.listing_price ?? 0).toLocaleString('ru-RU') + ' ₽'
  const link = item.chat_url
    ? `<a class="link" href="${esc(item.chat_url)}" target="_blank" rel="noopener">Открыть чат в Авито</a>`
    : ''
  const { el, close } = openModal({
    title: 'Новый чат Авито',
    sub: item.buyer_name ?? '',
    body: `
      <div style="display:flex;flex-direction:column;gap:10px">
        <div><b>${esc(item.listing_title ?? 'Объявление')}</b></div>
        <div class="small muted">Цена объявления: ${price}</div>
        <div class="small muted">Начало чата: ${esc(started)}</div>
        ${link}
        <div class="field" style="margin-top:6px">
          <label for="avito-notice-store">Направьте чат в магазин</label>
          <select class="select" id="avito-notice-store">
            <option value="">— выберите магазин —</option>
            ${STORES.map(([value, label]) => `<option value="${value}">${label}</option>`).join('')}
          </select>
        </div>
      </div>`,
    footer: '<button class="btn" data-later type="button">Позже</button>'
      + '<button class="btn btn-primary" data-assign type="button">Назначить магазин</button>',
  })

  el.querySelector('[data-later]').addEventListener('click', close)
  el.querySelector('[data-assign]').addEventListener('click', async () => {
    const value = el.querySelector('#avito-notice-store').value
    if (!value) {
      toast('Выберите магазин', 'error')
      return
    }
    try {
      await api(`/api/avito-chats/${item.id}`, { method: 'PATCH', body: { store: value } })
      toast('Чат направлен в магазин')
      close()
    } catch (error) {
      toast(error.message, 'error')
    }
  })
}
