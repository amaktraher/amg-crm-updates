import { createServer } from 'node:http'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import { DB_PATH } from './db.js'
import { createRouter, HttpError, readJson, sendJson, sendText, serveStatic } from './http.js'
import { sessionUser } from './auth.js'
import { registerAuthRoutes } from './api/auth.js'
import { registerUserRoutes } from './api/users.js'
import { registerCompanyRoutes } from './api/companies.js'
import { registerContactRoutes } from './api/contacts.js'
import { registerAvitoRoutes } from './api/avito.js'
import { registerAvitoChatRoutes } from './api/avito-chats.js'
import { registerCallRoutes } from './api/calls.js'
import { registerSystemRoutes } from './api/system.js'
import { registerTaskRoutes } from './api/tasks.js'
import { registerDashboardRoutes } from './api/dashboard.js'
import { registerAuditRoutes } from './api/audit.js'

const HERE = dirname(fileURLToPath(import.meta.url))
const PUBLIC_DIR = resolve(HERE, '..', 'public')
const PORT = Number(process.env.CRM_PORT ?? 4599)
const HOST = process.env.CRM_HOST ?? '127.0.0.1'

const router = createRouter()
registerAuthRoutes(router)
registerUserRoutes(router)
registerCompanyRoutes(router)
registerContactRoutes(router)
registerAvitoRoutes(router)
registerAvitoChatRoutes(router)
registerCallRoutes(router)
registerSystemRoutes(router)
registerTaskRoutes(router)
registerDashboardRoutes(router)
registerAuditRoutes(router)

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
    + "script-src 'self'; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'self'",
}

const server = createServer(async (req, res) => {
  for (const [name, value] of Object.entries(SECURITY_HEADERS)) res.setHeader(name, value)

  let url
  try {
    url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`)
  } catch {
    sendText(res, 400, 'Bad request')
    return
  }
  const { pathname, searchParams } = url

  if (!pathname.startsWith('/api/')) {
    if (serveStatic(req, res, PUBLIC_DIR, pathname)) return
    sendText(res, 404, 'Not found')
    return
  }

  const match = router.match(req.method ?? 'GET', pathname)
  if (!match) {
    sendJson(res, 404, { error: 'Метод API не найден', code: 'NOT_FOUND' })
    return
  }

  try {
    const user = sessionUser(req)
    const body = ['POST', 'PATCH', 'PUT'].includes(req.method ?? '') ? await readJson(req) : {}
    const result = await match.handler({
      req,
      res,
      params: match.params,
      query: searchParams,
      body,
      user,
    })
    if (!res.writableEnded) sendJson(res, 200, result ?? { ok: true })
  } catch (error) {
    if (error instanceof HttpError) {
      sendJson(res, error.status, { error: error.message, code: error.code ?? 'ERROR' })
      return
    }
    if (String(error?.code ?? '').startsWith('SQLITE_CONSTRAINT')) {
      sendJson(res, 409, { error: 'Нарушено ограничение данных', code: 'CONFLICT' })
      return
    }
    console.error('[crm] error:', error)
    sendJson(res, 500, { error: 'Внутренняя ошибка сервера', code: 'INTERNAL' })
  }
})

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`[crm] порт ${PORT} уже занят. Задайте другой: CRM_PORT=4600 npm start`)
  } else {
    console.error('[crm] сервер не запустился:', error.message)
  }
  process.exit(1)
})

server.listen(PORT, HOST, () => {
  console.log('')
  console.log('  AMG-CRM')
  console.log(`  → http://${HOST}:${PORT}`)
  console.log(`  база: ${DB_PATH}`)
  console.log('')
})

const shutdown = () => {
  console.log('\n[crm] остановка…')
  server.close(() => process.exit(0))
  setTimeout(() => process.exit(0), 2000).unref()
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)
